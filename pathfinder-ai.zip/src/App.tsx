/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { Navbar } from './components/Navbar';
import { ProfileIntake } from './components/ProfileIntake';
import { CareerRecommendations } from './components/CareerRecommendations';
import { SkillGapAnalysis } from './components/SkillGapAnalysis';
import { RoadmapPlanner } from './components/RoadmapPlanner';
import { ResumeAnalyzer } from './components/ResumeAnalyzer';
import { CareerChatbot } from './components/CareerChatbot';
import { MarketInsights } from './components/MarketInsights';
import { ProgressDashboard } from './components/ProgressDashboard';
import { DocsViewer } from './components/DocsViewer';

import { PRESET_PERSONAS, PersonaMeta } from './data/personasData';
import { CAREERS_DATABASE } from './data/careersData';
import { 
  UserProfile, 
  Career, 
  CareerMatch, 
  CareerSkillGapAnalysis, 
  CareerRoadmap, 
  ResumeATSAnalysis, 
  ChatMessage 
} from './types/career';
import { 
  calculateCareerMatches, 
  calculateSkillGap, 
  generateRoadmap, 
  analyzeResumeATS 
} from './utils/scoringEngine';

export default function App() {
  // Active Persona & Profile
  const [profile, setProfile] = useState<UserProfile>(PRESET_PERSONAS[0].profile);
  const [selectedCareer, setSelectedCareer] = useState<Career>(CAREERS_DATABASE[0]);

  // Derived / Calculated System State
  const [matches, setMatches] = useState<CareerMatch[]>([]);
  const [gapAnalysis, setGapAnalysis] = useState<CareerSkillGapAnalysis | null>(null);
  const [roadmap, setRoadmap] = useState<CareerRoadmap | null>(null);
  const [atsAnalysis, setAtsAnalysis] = useState<ResumeATSAnalysis | null>(null);
  
  // Navigation & Loading State
  const [activeTab, setActiveTab] = useState<string>('intake');
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [aiPowered, setAiPowered] = useState<boolean>(true);

  // Chatbot Messages State
  const [chatMessages, setChatMessages] = useState<ChatMessage[]>([
    {
      id: 'msg-welcome',
      sender: 'assistant',
      content: `Hello Priya! I'm ForgeBot, your AI Career Mentor. I've analyzed your CS & Statistics background and calibrated your skills against the Bureau of Labor Statistics O*NET database.\n\nYour profile currently matches strongly with Machine Learning & AI Engineering (34% projected 10-year market growth). How can I help you navigate your journey today?`,
      timestamp: 'Just now'
    }
  ]);

  // Initial calculation on mount or profile change
  useEffect(() => {
    const calculatedMatches = calculateCareerMatches(profile, CAREERS_DATABASE);
    setMatches(calculatedMatches);

    // Default target career to #1 match if not set
    const topCareer = calculatedMatches[0]?.career || CAREERS_DATABASE[0];
    setSelectedCareer(topCareer);

    const gap = calculateSkillGap(profile, topCareer);
    setGapAnalysis(gap);

    const rmap = generateRoadmap(profile, topCareer, profile.goals.timelineMonths || 6);
    setRoadmap(rmap);

    const ats = analyzeResumeATS(
      `PRIYA SHARMA\nSeattle, WA | priya.sharma@example.com\nEDUCATION\nUniversity of Washington — BS Computer Science & Statistics\nSKILLS: Python, SQL, Algorithms, Git`,
      topCareer
    );
    setAtsAnalysis(ats);
  }, []);

  // Handler for Persona Switching
  const handleSelectPersona = (persona: PersonaMeta) => {
    setProfile(persona.profile);
    const newMatches = calculateCareerMatches(persona.profile, CAREERS_DATABASE);
    setMatches(newMatches);

    const target = newMatches[0]?.career || CAREERS_DATABASE[0];
    setSelectedCareer(target);

    setGapAnalysis(calculateSkillGap(persona.profile, target));
    setRoadmap(generateRoadmap(persona.profile, target, persona.profile.goals.timelineMonths || 6));
    
    // Update chat welcome message
    setChatMessages([
      {
        id: `msg-welcome-${persona.id}`,
        sender: 'assistant',
        content: `Loaded persona: ${persona.name} (${persona.tagline}).\nI've refreshed your O*NET match rankings and skill gap matrix. Your top recommended path is ${target.title} ($${target.medianSalaryUSD.toLocaleString()} median). What questions can I answer?`,
        timestamp: 'Just now'
      }
    ]);
  };

  // Handler for Career Target Selection
  const handleSelectCareer = (career: Career) => {
    setSelectedCareer(career);
    const gap = calculateSkillGap(profile, career);
    setGapAnalysis(gap);

    const rmap = generateRoadmap(profile, career, profile.goals.timelineMonths || 6);
    setRoadmap(rmap);

    const ats = analyzeResumeATS(
      `Resume for ${profile.fullName}\nSkills: ${profile.skills.join(', ')}`,
      career
    );
    setAtsAnalysis(ats);
  };

  // Trigger Recommendations API
  const handleGenerateMatches = async () => {
    setIsLoading(true);
    try {
      const res = await fetch('/api/recommendations', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ profile }),
      });

      if (res.ok) {
        const json = await res.json();
        if (json.data && Array.isArray(json.data)) {
          setMatches(json.data);
          setAiPowered(json.aiPowered ?? true);
          if (json.data[0]?.career) {
            handleSelectCareer(json.data[0].career);
          }
          setActiveTab('recommendations');
          return;
        }
      }
    } catch (err) {
      console.warn('API call fallback to local RAG engine:', err);
    } finally {
      setIsLoading(false);
    }

    // Local fallback
    const fallbackMatches = calculateCareerMatches(profile, CAREERS_DATABASE);
    setMatches(fallbackMatches);
    if (fallbackMatches[0]?.career) {
      handleSelectCareer(fallbackMatches[0].career);
    }
    setActiveTab('recommendations');
  };

  // Toggle Action item in Roadmap
  const handleToggleActionItem = (milestoneId: string, actionId: string) => {
    if (!roadmap) return;
    setRoadmap(prev => {
      if (!prev) return prev;
      return {
        ...prev,
        milestones: prev.milestones.map(m => {
          if (m.id !== milestoneId) return m;
          return {
            ...m,
            actionItems: m.actionItems.map(a => {
              if (a.id !== actionId) return a;
              return { ...a, completed: !a.completed };
            })
          };
        })
      };
    });
  };

  // Change Roadmap Duration (3, 6, 12 months)
  const handleChangeDuration = (months: 3 | 6 | 12) => {
    if (!selectedCareer) return;
    setProfile(prev => ({
      ...prev,
      goals: { ...prev.goals, timelineMonths: months }
    }));
    setRoadmap(generateRoadmap(profile, selectedCareer, months));
  };

  // Analyze Resume
  const handleAnalyzeResume = async (text: string) => {
    setIsLoading(true);
    try {
      const res = await fetch('/api/resume-analyzer', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ resumeText: text, targetCareerId: selectedCareer.id }),
      });

      if (res.ok) {
        const json = await res.json();
        if (json.data) {
          setAtsAnalysis(json.data);
          return;
        }
      }
    } catch (err) {
      console.warn('Resume API fallback:', err);
    } finally {
      setIsLoading(false);
    }

    // Local fallback
    setAtsAnalysis(analyzeResumeATS(text, selectedCareer));
  };

  // Send Chat Message
  const handleSendMessage = async (text: string) => {
    const userMsg: ChatMessage = {
      id: `user-${Date.now()}`,
      sender: 'user',
      content: text,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
    };

    setChatMessages(prev => [...prev, userMsg]);
    setIsLoading(true);

    try {
      const res = await fetch('/api/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          message: text,
          profile,
          targetCareerId: selectedCareer.id,
          history: chatMessages.slice(-6)
        }),
      });

      if (res.ok) {
        const json = await res.json();
        if (json.reply) {
          setChatMessages(prev => [
            ...prev,
            {
              id: `bot-${Date.now()}`,
              sender: 'assistant',
              content: json.reply,
              timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
            }
          ]);
          return;
        }
      }

      const errorJson = await res.json().catch(() => null);
      throw new Error(errorJson?.error || `Server error (HTTP ${res.status})`);
    } catch (err: any) {
      console.error('Chat API error:', err);
      setChatMessages(prev => [
        ...prev,
        {
          id: `bot-${Date.now()}`,
          sender: 'assistant',
          content: `Sorry, I hit a momentary connection hiccup (${err?.message || 'network timeout'}). Please ask your question again!`,
          timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
        }
      ]);
    } finally {
      setIsLoading(false);
    }
  };

  const handleClearChat = () => {
    setChatMessages([
      {
        id: 'msg-cleared',
        sender: 'assistant',
        content: `Chat session refreshed. How can I guide you on your roadmap for ${selectedCareer.title}?`,
        timestamp: 'Just now'
      }
    ]);
  };

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col font-sans selection:bg-indigo-500 selection:text-white">
      {/* Top Global Navigation */}
      <Navbar
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        activeProfile={profile}
        onSelectPersona={handleSelectPersona}
        selectedCareerTitle={selectedCareer?.title}
      />

      {/* Main Tab Content Canvas */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {activeTab === 'intake' && (
          <ProfileIntake
            profile={profile}
            setProfile={setProfile}
            onGenerateMatches={handleGenerateMatches}
            isLoading={isLoading}
          />
        )}

        {activeTab === 'recommendations' && (
          <CareerRecommendations
            matches={matches}
            selectedCareer={selectedCareer}
            onSelectCareer={handleSelectCareer}
            onNavigateToTab={setActiveTab}
            aiPowered={aiPowered}
          />
        )}

        {activeTab === 'skill-gap' && gapAnalysis && (
          <SkillGapAnalysis
            career={selectedCareer}
            gapAnalysis={gapAnalysis}
            onNavigateToTab={setActiveTab}
            isLoading={isLoading}
          />
        )}

        {activeTab === 'roadmap' && roadmap && (
          <RoadmapPlanner
            roadmap={roadmap}
            career={selectedCareer}
            onToggleActionItem={handleToggleActionItem}
            onChangeDuration={handleChangeDuration}
            onNavigateToTab={setActiveTab}
          />
        )}

        {activeTab === 'resume' && atsAnalysis && (
          <ResumeAnalyzer
            career={selectedCareer}
            analysis={atsAnalysis}
            onAnalyzeResume={handleAnalyzeResume}
            isLoading={isLoading}
          />
        )}

        {activeTab === 'chat' && (
          <CareerChatbot
            profile={profile}
            career={selectedCareer}
            messages={chatMessages}
            onSendMessage={handleSendMessage}
            isLoading={isLoading}
            onClearChat={handleClearChat}
          />
        )}

        {activeTab === 'market' && (
          <MarketInsights />
        )}

        {activeTab === 'tracker' && roadmap && gapAnalysis && atsAnalysis && (
          <ProgressDashboard
            profile={profile}
            career={selectedCareer}
            roadmap={roadmap}
            gapAnalysis={gapAnalysis}
            atsAnalysis={atsAnalysis}
            onToggleActionItem={handleToggleActionItem}
          />
        )}

        {activeTab === 'docs' && (
          <DocsViewer />
        )}
      </main>

      {/* System Footer */}
      <footer className="bg-slate-900 border-t border-slate-800/80 py-6 text-xs text-slate-400">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex flex-col sm:flex-row items-center justify-between gap-3">
          <div className="flex items-center gap-2">
            <span className="font-bold text-white">CareerForge AI</span>
            <span>•</span>
            <span>Grounded in Bureau of Labor Statistics & O*NET SOC Data</span>
          </div>
          <div className="flex items-center gap-4 text-[11px]">
            <span className="text-emerald-400">● Full-Stack Node + React Running</span>
            <button onClick={() => setActiveTab('docs')} className="text-indigo-400 hover:text-indigo-300 underline">
              View Phase 1-12 Architecture
            </button>
          </div>
        </div>
      </footer>
    </div>
  );
}
