import React from 'react';
import { Compass, Sparkles, BookOpen, User, CheckCircle2 } from 'lucide-react';
import { PRESET_PERSONAS, PersonaMeta } from '../data/personasData';
import { UserProfile } from '../types/career';

interface NavbarProps {
  activeTab: string;
  setActiveTab: (tab: string) => void;
  activeProfile: UserProfile;
  onSelectPersona: (persona: PersonaMeta) => void;
  selectedCareerTitle?: string;
}

export const Navbar: React.FC<NavbarProps> = ({
  activeTab,
  setActiveTab,
  activeProfile,
  onSelectPersona,
  selectedCareerTitle,
}) => {
  return (
    <header className="sticky top-0 z-40 bg-slate-900/90 backdrop-blur-md border-b border-slate-800 text-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          {/* Logo & Title */}
          <div className="flex items-center space-x-3 cursor-pointer" onClick={() => setActiveTab('intake')}>
            <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-indigo-600 via-blue-500 to-emerald-400 flex items-center justify-center shadow-lg shadow-indigo-500/20">
              <Compass className="w-6 h-6 text-white" />
            </div>
            <div>
              <div className="flex items-center space-x-2">
                <span className="font-bold text-lg tracking-tight bg-gradient-to-r from-white via-slate-100 to-slate-400 bg-clip-text text-transparent">
                  CareerForge
                </span>
                <span className="text-[10px] font-semibold uppercase tracking-widest px-2 py-0.5 rounded-full bg-indigo-500/20 text-indigo-300 border border-indigo-500/30">
                  AI + O*NET
                </span>
              </div>
              <p className="text-xs text-slate-400 hidden sm:block">Intelligent Occupational Guidance & Upskilling</p>
            </div>
          </div>

          {/* Quick Persona Selector */}
          <div className="hidden md:flex items-center space-x-2 bg-slate-800/80 p-1 rounded-xl border border-slate-700/60 text-xs">
            <span className="text-slate-400 px-2 flex items-center gap-1">
              <User className="w-3.5 h-3.5 text-indigo-400" />
              <span>Persona:</span>
            </span>
            {PRESET_PERSONAS.map(p => {
              const isSelected = activeProfile.id === p.profile.id;
              return (
                <button
                  key={p.id}
                  onClick={() => onSelectPersona(p)}
                  className={`px-2.5 py-1 rounded-lg font-medium transition-all flex items-center gap-1.5 ${
                    isSelected
                      ? 'bg-indigo-600 text-white shadow-sm'
                      : 'text-slate-300 hover:text-white hover:bg-slate-700/60'
                  }`}
                  title={p.tagline}
                >
                  <span className={`w-2 h-2 rounded-full ${isSelected ? 'bg-emerald-300' : 'bg-slate-500'}`} />
                  {p.name.split(' ')[0]}
                </button>
              );
            })}
          </div>

          {/* Right Action: Architecture / Deliverables Docs */}
          <div className="flex items-center space-x-3">
            {selectedCareerTitle && (
              <div className="hidden lg:flex items-center gap-1.5 px-3 py-1 bg-emerald-500/10 border border-emerald-500/20 rounded-full text-xs text-emerald-300">
                <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
                <span className="text-slate-400">Target:</span>
                <span className="font-semibold text-white truncate max-w-[150px]">{selectedCareerTitle}</span>
              </div>
            )}

            <button
              onClick={() => setActiveTab('docs')}
              className={`px-3 py-1.5 rounded-lg text-xs font-semibold flex items-center gap-1.5 transition-all ${
                activeTab === 'docs'
                  ? 'bg-amber-500 text-slate-950 font-bold shadow-lg shadow-amber-500/20'
                  : 'bg-slate-800 hover:bg-slate-700 text-amber-300 border border-amber-500/30'
              }`}
            >
              <BookOpen className="w-4 h-4" />
              <span>Phase 1-12 Specs & Architecture</span>
            </button>
          </div>
        </div>

        {/* Navigation Tabs */}
        <div className="flex space-x-1 overflow-x-auto py-2 border-t border-slate-800/80 text-xs scrollbar-none">
          {[
            { id: 'intake', label: '1. Profile & Quiz' },
            { id: 'recommendations', label: '2. Career Matches' },
            { id: 'skill-gap', label: '3. Skill-Gap Matrix' },
            { id: 'roadmap', label: '4. Phased Roadmap' },
            { id: 'resume', label: '5. ATS Resume Scanner' },
            { id: 'chat', label: '6. AI Career Mentor' },
            { id: 'market', label: '7. Market Insights' },
            { id: 'tracker', label: '8. Progress Tracker' },
            { id: 'docs', label: 'Architecture & Schemas (Phase 1-12)' },
          ].map(tab => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              className={`px-3 py-1.5 rounded-lg font-medium whitespace-nowrap transition-colors flex items-center gap-1.5 ${
                activeTab === tab.id
                  ? 'bg-indigo-600 text-white font-semibold shadow-sm'
                  : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800'
              }`}
            >
              {tab.id === 'docs' && <Sparkles className="w-3.5 h-3.5 text-amber-400" />}
              {tab.label}
            </button>
          ))}
        </div>
      </div>
    </header>
  );
};
