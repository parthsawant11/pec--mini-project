import React, { useState } from 'react';
import { CAREERS_DATABASE } from '../data/careersData';
import { 
  TrendingUp, 
  DollarSign, 
  Briefcase, 
  BarChart3, 
  ArrowUpRight, 
  ShieldCheck, 
  CheckCircle2,
  GitCompare
} from 'lucide-react';

export const MarketInsights: React.FC = () => {
  const [careerAId, setCareerAId] = useState<string>('ai-machine-learning-engineer');
  const [careerBId, setCareerBId] = useState<string>('full-stack-software-engineer');

  const careerA = CAREERS_DATABASE.find(c => c.id === careerAId) || CAREERS_DATABASE[0];
  const careerB = CAREERS_DATABASE.find(c => c.id === careerBId) || CAREERS_DATABASE[1];

  // Industry Categories aggregate
  const categories = Array.from(new Set(CAREERS_DATABASE.map(c => c.category)));
  const categoryStats = categories.map(cat => {
    const list = CAREERS_DATABASE.filter(c => c.category === cat);
    const avgSalary = Math.round(list.reduce((acc, c) => acc + c.medianSalaryUSD, 0) / list.length);
    const avgGrowth = Math.round((list.reduce((acc, c) => acc + c.tenYearGrowthRate, 0) / list.length) * 10) / 10;
    const totalOpenings = list.reduce((acc, c) => acc + c.projectedOpeningsAnnual, 0);

    return { category: cat, avgSalary, avgGrowth, totalOpenings, count: list.length };
  }).sort((a, b) => b.avgSalary - a.avgSalary);

  // Top Skills Frequency
  const skillCountMap: Record<string, number> = {};
  CAREERS_DATABASE.forEach(c => {
    c.requiredSkills.forEach(s => {
      skillCountMap[s.name] = (skillCountMap[s.name] || 0) + 1;
    });
  });

  const topSkills = Object.entries(skillCountMap)
    .sort((a, b) => b[1] - a[1])
    .slice(0, 10);

  return (
    <div className="space-y-6 max-w-6xl mx-auto">
      {/* Top Banner */}
      <div className="bg-gradient-to-r from-slate-900 via-indigo-950/70 to-slate-900 p-6 rounded-2xl border border-indigo-900/40 shadow-xl">
        <div className="flex items-center gap-2 mb-2">
          <span className="text-xs px-2.5 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 font-bold border border-emerald-500/30">
            Bureau of Labor Statistics (BLS) + O*NET
          </span>
          <span className="text-xs text-slate-400">2026-2036 Occupational Projections</span>
        </div>
        <h1 className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight">
          Job Market Economics & Salary Intelligence
        </h1>
        <p className="text-xs sm:text-sm text-slate-300 mt-1 max-w-2xl">
          Empirical salary distributions, annualized job opening velocity, and cross-sector growth benchmarks to ground your career decisions in economic reality.
        </p>

        {/* High-level Macro Stat Cards */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 mt-6 pt-6 border-t border-slate-800">
          <div className="bg-slate-800/60 p-4 rounded-xl border border-slate-700/60">
            <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block">Average Tech Sector Median</span>
            <div className="flex items-baseline gap-2 mt-1">
              <span className="text-2xl font-black text-emerald-400">$138,400</span>
              <span className="text-xs text-slate-400 font-mono">USD / yr</span>
            </div>
            <span className="text-[10px] text-slate-500">Based on 20+ tracked tech disciplines</span>
          </div>

          <div className="bg-slate-800/60 p-4 rounded-xl border border-slate-700/60">
            <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block">Average 10-Year Growth Rate</span>
            <div className="flex items-baseline gap-2 mt-1">
              <span className="text-2xl font-black text-blue-400">+25.8%</span>
              <span className="text-xs text-slate-400 font-mono">2026–2036</span>
            </div>
            <span className="text-[10px] text-slate-500">3.8x faster than overall US labor average</span>
          </div>

          <div className="bg-slate-800/60 p-4 rounded-xl border border-slate-700/60">
            <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block">Tracked Annual Openings</span>
            <div className="flex items-baseline gap-2 mt-1">
              <span className="text-2xl font-black text-purple-400">415,000+</span>
              <span className="text-xs text-slate-400 font-mono">openings/yr</span>
            </div>
            <span className="text-[10px] text-slate-500">Driven by retirement & cloud migration</span>
          </div>
        </div>
      </div>

      {/* Sector Comparison Table */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 shadow-xl">
        <div className="flex items-center justify-between pb-4 border-b border-slate-800 mb-4">
          <div>
            <h2 className="text-base font-bold text-white flex items-center gap-2">
              <BarChart3 className="w-4 h-4 text-indigo-400" />
              <span>Sector Compensation & Growth Landscape</span>
            </h2>
            <p className="text-xs text-slate-400 mt-0.5">Aggregated metrics across major modern industry categories.</p>
          </div>
        </div>

        <div className="space-y-3">
          {categoryStats.map(cat => (
            <div
              key={cat.category}
              className="p-4 rounded-xl bg-slate-800/40 border border-slate-800 hover:border-slate-700 transition-colors"
            >
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 mb-2">
                <div className="flex items-center gap-2">
                  <span className="text-sm font-bold text-white">{cat.category}</span>
                  <span className="text-[10px] px-2 py-0.5 rounded bg-slate-800 text-slate-400 border border-slate-700">
                    {cat.count} Roles
                  </span>
                </div>

                <div className="flex items-center gap-4 text-xs font-mono">
                  <span className="text-emerald-400 font-bold">${cat.avgSalary.toLocaleString()} avg</span>
                  <span className="text-blue-400 font-bold">+{cat.avgGrowth}% growth</span>
                  <span className="text-slate-400">~{cat.totalOpenings.toLocaleString()} openings/yr</span>
                </div>
              </div>

              {/* Progress bar visual */}
              <div className="w-full bg-slate-800 h-2 rounded-full overflow-hidden flex">
                <div 
                  className="bg-emerald-500 h-full" 
                  style={{ width: `${Math.min(100, (cat.avgSalary / 180000) * 100)}%` }} 
                />
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Top 10 Most In-Demand Skills Ranking */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 shadow-xl">
        <h2 className="text-base font-bold text-white mb-1">
          Top 10 Most Prevalent In-Demand Skills Across All 20+ Careers
        </h2>
        <p className="text-xs text-slate-400 mb-4">
          Skills that appear most frequently across high-paying technical job descriptions in 2026.
        </p>

        <div className="grid grid-cols-2 sm:grid-cols-5 gap-3">
          {topSkills.map(([skill, count], idx) => (
            <div
              key={skill}
              className="p-3 bg-slate-800/60 rounded-xl border border-slate-700/60 text-center relative overflow-hidden"
            >
              <span className="absolute top-1 left-2 text-[10px] font-bold text-slate-500">#{idx + 1}</span>
              <div className="text-xs font-bold text-white mt-2 truncate" title={skill}>
                {skill}
              </div>
              <span className="text-[11px] text-indigo-400 font-semibold block mt-1">
                Appears in {count} careers
              </span>
            </div>
          ))}
        </div>
      </div>

      {/* Side-by-Side Career Comparator */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 shadow-xl">
        <div className="flex items-center gap-2 mb-4 pb-3 border-b border-slate-800">
          <GitCompare className="w-4 h-4 text-indigo-400" />
          <h2 className="text-base font-bold text-white">Side-by-Side Career Comparator</h2>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {/* Career A Select & Card */}
          <div className="space-y-3">
            <label className="block text-xs font-semibold text-slate-400 uppercase tracking-wider">
              Select Career A:
            </label>
            <select
              value={careerAId}
              onChange={e => setCareerAId(e.target.value)}
              className="w-full bg-slate-800 border border-slate-700 rounded-xl px-4 py-2 text-xs text-white focus:outline-none focus:ring-2 focus:ring-indigo-500"
            >
              {CAREERS_DATABASE.map(c => (
                <option key={c.id} value={c.id}>{c.title}</option>
              ))}
            </select>

            <div className="p-4 bg-slate-800/40 rounded-xl border border-slate-800 space-y-3">
              <div className="flex justify-between items-start">
                <div>
                  <h3 className="text-sm font-bold text-white">{careerA.title}</h3>
                  <span className="text-[10px] text-slate-400 font-mono">SOC: {careerA.socCode}</span>
                </div>
                <span className="text-xs px-2 py-0.5 rounded bg-indigo-500/20 text-indigo-300 font-medium">
                  {careerA.category}
                </span>
              </div>

              <div className="space-y-1.5 text-xs">
                <div className="flex justify-between">
                  <span className="text-slate-400">Median Salary:</span>
                  <span className="font-bold text-emerald-400 font-mono">${careerA.medianSalaryUSD.toLocaleString()}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-400">Salary 10th - 90th:</span>
                  <span className="font-mono text-slate-300">
                    ${Math.round(careerA.salaryRange.p10/1000)}k - ${Math.round(careerA.salaryRange.p90/1000)}k
                  </span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-400">10-Yr Projected Growth:</span>
                  <span className="font-bold text-blue-400 font-mono">+{careerA.tenYearGrowthRate}%</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-400">Automation Vulnerability:</span>
                  <span className="text-emerald-400 font-semibold">{careerA.automationRisk}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-400">Remote Friendliness:</span>
                  <span className="text-white font-semibold">{careerA.remoteFriendliness}</span>
                </div>
              </div>

              <div className="pt-2 border-t border-slate-800">
                <span className="text-[10px] text-slate-500 block mb-1">Top Certifications:</span>
                <span className="text-[11px] text-slate-300">{careerA.topCertifications.slice(0, 2).join(', ')}</span>
              </div>
            </div>
          </div>

          {/* Career B Select & Card */}
          <div className="space-y-3">
            <label className="block text-xs font-semibold text-slate-400 uppercase tracking-wider">
              Select Career B:
            </label>
            <select
              value={careerBId}
              onChange={e => setCareerBId(e.target.value)}
              className="w-full bg-slate-800 border border-slate-700 rounded-xl px-4 py-2 text-xs text-white focus:outline-none focus:ring-2 focus:ring-indigo-500"
            >
              {CAREERS_DATABASE.map(c => (
                <option key={c.id} value={c.id}>{c.title}</option>
              ))}
            </select>

            <div className="p-4 bg-slate-800/40 rounded-xl border border-slate-800 space-y-3">
              <div className="flex justify-between items-start">
                <div>
                  <h3 className="text-sm font-bold text-white">{careerB.title}</h3>
                  <span className="text-[10px] text-slate-400 font-mono">SOC: {careerB.socCode}</span>
                </div>
                <span className="text-xs px-2 py-0.5 rounded bg-blue-500/20 text-blue-300 font-medium">
                  {careerB.category}
                </span>
              </div>

              <div className="space-y-1.5 text-xs">
                <div className="flex justify-between">
                  <span className="text-slate-400">Median Salary:</span>
                  <span className="font-bold text-emerald-400 font-mono">${careerB.medianSalaryUSD.toLocaleString()}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-400">Salary 10th - 90th:</span>
                  <span className="font-mono text-slate-300">
                    ${Math.round(careerB.salaryRange.p10/1000)}k - ${Math.round(careerB.salaryRange.p90/1000)}k
                  </span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-400">10-Yr Projected Growth:</span>
                  <span className="font-bold text-blue-400 font-mono">+{careerB.tenYearGrowthRate}%</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-400">Automation Vulnerability:</span>
                  <span className="text-emerald-400 font-semibold">{careerB.automationRisk}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-400">Remote Friendliness:</span>
                  <span className="text-white font-semibold">{careerB.remoteFriendliness}</span>
                </div>
              </div>

              <div className="pt-2 border-t border-slate-800">
                <span className="text-[10px] text-slate-500 block mb-1">Top Certifications:</span>
                <span className="text-[11px] text-slate-300">{careerB.topCertifications.slice(0, 2).join(', ')}</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
