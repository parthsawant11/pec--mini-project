import React, { useState } from 'react';
import { Career, ResumeATSAnalysis } from '../types/career';
import { 
  FileText, 
  Sparkles, 
  CheckCircle2, 
  AlertTriangle, 
  ArrowRight, 
  Copy, 
  Check, 
  Upload,
  RefreshCw
} from 'lucide-react';

interface ResumeAnalyzerProps {
  career: Career;
  analysis: ResumeATSAnalysis;
  onAnalyzeResume: (text: string) => void;
  isLoading: boolean;
}

const SAMPLE_RESUMES = {
  student: `PRIYA SHARMA
Seattle, WA | priya.sharma@example.com | github.com/priyasharma

EDUCATION
University of Washington — Bachelor of Science in Computer Science & Statistics (Graduation: June 2026)
Relevant Coursework: Data Structures & Algorithms, Linear Algebra, Multivariable Calculus, Database Systems, Artificial Intelligence Fundamentals.

PROJECTS & ACADEMICS
- Automated Image Classifier (PyTorch, Python): Developed a CNN model achieving 89% accuracy on CIFAR-10 dataset using data augmentation and early stopping.
- SQL Analytics Dashboard: Built an interactive reporting script querying 500k sales records using PostgreSQL and Python pandas.
- University Research Assistant: Prepared datasets and cleaned sensor readings for NLP statistical analysis.

TECHNICAL SKILLS
Languages: Python, SQL, Java, C++
Tools & Libraries: Git, pandas, numpy, scikit-learn, VS Code, Linux`,

  jobSeeker: `MARCUS VANCE
Chicago, IL | marcus.vance@example.com | linkedin.com/in/marcusvance

SUMMARY
Frontend Software Engineer with 3.5 years of experience developing responsive, accessible React applications. Looking to expand into full-stack and cloud microservices.

PROFESSIONAL EXPERIENCE
Frontend Developer — Apex Digital Agency (2022 – Present)
- Worked on customer-facing web apps in React, Next.js, and TypeScript.
- Converted Figma wireframes into responsive Tailwind CSS components.
- Integrated third-party REST APIs and managed client-side state with Redux.
- Participated in weekly agile sprints, daily standups, and pull request reviews.

Junior Web Developer — Brightline Media (2020 – 2022)
- Built interactive marketing landing pages using HTML, CSS, and modern JavaScript.
- Improved Google Lighthouse performance scores by optimizing image assets.

TECHNICAL SKILLS
Languages: JavaScript, TypeScript, HTML5, CSS3, SQL (Basic)
Frameworks: React, Next.js, Tailwind CSS, Redux, Express (Familiar)
Tools: Git, GitHub, Webpack, Figma, Jira`,

  switcher: `ELENA ROSTOVA
Austin, TX | elena.rostova@example.com

SUMMARY
Dynamic Marketing Lead with 6+ years orchestrating digital campaigns, customer user research, and cross-functional product launches. Pivoting into Product Design & AI Product Management.

EXPERIENCE
Senior Digital Strategist — Horizon Interactive (2021 – Present)
- Spearheaded quarterly product growth campaigns, collaborating closely with UX designers and software developers.
- Conducted 40+ user interviews to identify onboarding friction and customer pain points.
- Analyzed conversion funnel metrics in Google Analytics and synthesized weekly executive dashboards.
- Prototyped wireframe concepts in Figma for new landing page iterations.

Marketing Coordinator — NextEra Media (2018 – 2021)
- Managed email automation workflows and coordinated brand content schedules.
- Collaborated across sales, product, and creative departments.

SKILLS & CERTIFICATIONS
Tools: Figma, Google Analytics 4, Notion, Asana, Canva
Competencies: User Research, Customer Journey Mapping, Cross-Functional Alignment, Stakeholder Communication`
};

export const ResumeAnalyzer: React.FC<ResumeAnalyzerProps> = ({
  career,
  analysis,
  onAnalyzeResume,
  isLoading,
}) => {
  const [resumeText, setResumeText] = useState<string>(SAMPLE_RESUMES.student);
  const [copiedIdx, setCopiedIdx] = useState<number | null>(null);

  const handleCopyRewrite = (text: string, idx: number) => {
    navigator.clipboard.writeText(text);
    setCopiedIdx(idx);
    setTimeout(() => setCopiedIdx(null), 2000);
  };

  const handleSelectSample = (key: keyof typeof SAMPLE_RESUMES) => {
    setResumeText(SAMPLE_RESUMES[key]);
    onAnalyzeResume(SAMPLE_RESUMES[key]);
  };

  return (
    <div className="space-y-6 max-w-6xl mx-auto">
      {/* Header Banner */}
      <div className="bg-gradient-to-r from-slate-900 via-indigo-950/70 to-slate-900 p-6 rounded-2xl border border-indigo-900/40 shadow-xl">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2 mb-2">
              <span className="text-xs px-2.5 py-0.5 rounded-full bg-blue-500/20 text-blue-300 font-bold border border-blue-500/30">
                Enterprise ATS Engine
              </span>
              <span className="text-xs text-slate-400 font-mono">Target: {career.title}</span>
            </div>
            <h1 className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight">
              ATS Resume Scanner & Bullet Optimizer
            </h1>
            <p className="text-xs sm:text-sm text-slate-300 mt-1 max-w-2xl">
              Analyzes your resume against applicant tracking system parsers (Taleo, Greenhouse, Workday) and optimizes bullet points with the Google X-Y-Z formula.
            </p>
          </div>

          {/* Quick Sample Selector */}
          <div className="bg-slate-800/80 p-2.5 rounded-xl border border-slate-700/60 shrink-0">
            <span className="text-[11px] font-semibold text-slate-400 block mb-1.5">Load Sample Resume:</span>
            <div className="flex gap-1.5">
              <button
                onClick={() => handleSelectSample('student')}
                className="px-2.5 py-1 text-xs font-medium rounded-lg bg-slate-700 hover:bg-indigo-600 text-slate-200 hover:text-white transition-all"
              >
                Priya (Student)
              </button>
              <button
                onClick={() => handleSelectSample('jobSeeker')}
                className="px-2.5 py-1 text-xs font-medium rounded-lg bg-slate-700 hover:bg-indigo-600 text-slate-200 hover:text-white transition-all"
              >
                Marcus (Frontend)
              </button>
              <button
                onClick={() => handleSelectSample('switcher')}
                className="px-2.5 py-1 text-xs font-medium rounded-lg bg-slate-700 hover:bg-indigo-600 text-slate-200 hover:text-white transition-all"
              >
                Elena (Marketing)
              </button>
            </div>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left: Input Textarea */}
        <div className="lg:col-span-5 space-y-4">
          <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 shadow-xl flex flex-col h-full">
            <div className="flex items-center justify-between pb-3 border-b border-slate-800 mb-3">
              <span className="text-xs font-bold text-white flex items-center gap-1.5">
                <FileText className="w-4 h-4 text-indigo-400" />
                <span>Resume Text Content</span>
              </span>
              <span className="text-[10px] text-slate-400 font-mono">
                {resumeText.trim().split(/\s+/).filter(Boolean).length} words
              </span>
            </div>

            <textarea
              value={resumeText}
              onChange={e => setResumeText(e.target.value)}
              placeholder="Paste plain text resume here..."
              rows={16}
              className="w-full bg-slate-800/80 border border-slate-700 rounded-xl p-3.5 text-xs text-slate-200 font-mono leading-relaxed focus:outline-none focus:ring-2 focus:ring-indigo-500 resize-none flex-1"
            />

            <div className="mt-4 pt-3 border-t border-slate-800 flex items-center justify-between gap-3">
              <button
                onClick={() => setResumeText('')}
                className="text-xs text-slate-400 hover:text-slate-200"
              >
                Clear
              </button>
              <button
                onClick={() => onAnalyzeResume(resumeText)}
                disabled={isLoading || !resumeText.trim()}
                className="px-5 py-2.5 bg-gradient-to-r from-indigo-600 to-blue-600 hover:opacity-95 text-white rounded-xl text-xs font-bold transition-all flex items-center gap-2 shadow-lg shadow-indigo-600/20 disabled:opacity-50"
              >
                {isLoading ? (
                  <>
                    <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                    <span>Parsing ATS Syntax...</span>
                  </>
                ) : (
                  <>
                    <Sparkles className="w-3.5 h-3.5 text-emerald-300" />
                    <span>Run ATS Scan</span>
                  </>
                )}
              </button>
            </div>
          </div>
        </div>

        {/* Right: ATS Evaluation Dashboard */}
        <div className="lg:col-span-7 space-y-5">
          {/* Main Scorecard */}
          <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 shadow-xl">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-5 border-b border-slate-800">
              <div>
                <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block">
                  Overall ATS Pass Score
                </span>
                <div className="flex items-baseline gap-3 mt-1">
                  <span
                    className={`text-4xl font-black ${
                      analysis.overallScore >= 80
                        ? 'text-emerald-400'
                        : analysis.overallScore >= 65
                        ? 'text-amber-400'
                        : 'text-rose-400'
                    }`}
                  >
                    {analysis.overallScore}
                  </span>
                  <span className="text-xs text-slate-400">/ 100</span>
                  <span
                    className={`text-xs px-2.5 py-0.5 rounded-full font-bold ${
                      analysis.overallScore >= 80
                        ? 'bg-emerald-500/20 text-emerald-300'
                        : analysis.overallScore >= 65
                        ? 'bg-amber-500/20 text-amber-300'
                        : 'bg-rose-500/20 text-rose-300'
                    }`}
                  >
                    {analysis.overallScore >= 80
                      ? 'High Callback Potential'
                      : analysis.overallScore >= 65
                      ? 'Moderate Filter Risk'
                      : 'Likely Automated Rejection'}
                  </span>
                </div>
              </div>

              {/* Mini Sub-Scores */}
              <div className="grid grid-cols-3 gap-3 text-center sm:text-right">
                <div className="bg-slate-800/60 p-2.5 rounded-xl border border-slate-700/60">
                  <span className="text-[10px] text-slate-400 block">Keywords</span>
                  <span className="text-base font-bold text-indigo-400">{analysis.keywordMatchScore}%</span>
                </div>
                <div className="bg-slate-800/60 p-2.5 rounded-xl border border-slate-700/60">
                  <span className="text-[10px] text-slate-400 block">Readability</span>
                  <span className="text-base font-bold text-blue-400">{analysis.readabilityScore}%</span>
                </div>
                <div className="bg-slate-800/60 p-2.5 rounded-xl border border-slate-700/60">
                  <span className="text-[10px] text-slate-400 block">Structure</span>
                  <span className="text-base font-bold text-emerald-400">{analysis.formattingScore}%</span>
                </div>
              </div>
            </div>

            {/* Keyword Extraction Matrix */}
            <div className="mt-5 space-y-4">
              <div>
                <span className="text-xs font-bold text-emerald-400 flex items-center gap-1.5 mb-2">
                  <CheckCircle2 className="w-4 h-4" />
                  <span>Matched Target Keywords ({analysis.matchedKeywords.length}):</span>
                </span>
                <div className="flex flex-wrap gap-1.5">
                  {analysis.matchedKeywords.length === 0 ? (
                    <span className="text-xs text-slate-500 italic">No exact target keywords matched yet.</span>
                  ) : (
                    analysis.matchedKeywords.map(kw => (
                      <span
                        key={kw}
                        className="text-xs px-2.5 py-1 rounded-lg bg-emerald-950/40 border border-emerald-800/60 text-emerald-300 font-medium"
                      >
                        ✓ {kw}
                      </span>
                    ))
                  )}
                </div>
              </div>

              <div>
                <span className="text-xs font-bold text-rose-400 flex items-center gap-1.5 mb-2">
                  <AlertTriangle className="w-4 h-4" />
                  <span>Missing High-Impact ATS Keywords ({analysis.missingKeywords.length}):</span>
                </span>
                <div className="flex flex-wrap gap-1.5">
                  {analysis.missingKeywords.map(kw => (
                    <span
                      key={kw}
                      className="text-xs px-2.5 py-1 rounded-lg bg-rose-950/40 border border-rose-800/60 text-rose-300 font-medium"
                    >
                      + {kw}
                    </span>
                  ))}
                </div>
              </div>
            </div>

            {/* Critical Issues & Positive Highlights */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 mt-5 pt-4 border-t border-slate-800 text-xs">
              <div>
                <span className="text-[10px] font-bold text-rose-400 uppercase tracking-wider block mb-1.5">
                  Flagged Issues
                </span>
                <ul className="space-y-1.5 text-slate-300">
                  {analysis.criticalIssues.map((issue, idx) => (
                    <li key={idx} className="flex items-start gap-1.5">
                      <span className="text-rose-400">•</span>
                      <span>{issue}</span>
                    </li>
                  ))}
                </ul>
              </div>

              <div>
                <span className="text-[10px] font-bold text-emerald-400 uppercase tracking-wider block mb-1.5">
                  Positive Signals
                </span>
                <ul className="space-y-1.5 text-slate-300">
                  {analysis.positiveHighlights.map((hi, idx) => (
                    <li key={idx} className="flex items-start gap-1.5">
                      <span className="text-emerald-400">✓</span>
                      <span>{hi}</span>
                    </li>
                  ))}
                </ul>
              </div>
            </div>
          </div>

          {/* Google X-Y-Z Bullet Point Optimizer */}
          <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 shadow-xl">
            <div className="flex items-center gap-2 mb-2">
              <Sparkles className="w-4 h-4 text-indigo-400" />
              <h3 className="text-base font-bold text-white">
                Google X-Y-Z Bullet Point Optimizer
              </h3>
            </div>
            <p className="text-xs text-slate-400 mb-4">
              "Accomplished [X], as measured by [Y], by doing [Z]" — transforms passive descriptions into verifiable impact statements.
            </p>

            <div className="space-y-4">
              {analysis.bulletRewrites.map((item, idx) => (
                <div key={idx} className="bg-slate-800/50 rounded-xl p-4 border border-slate-700/60 space-y-2.5">
                  <div>
                    <span className="text-[10px] font-bold uppercase tracking-wider text-slate-500 block">
                      Before (Passive / Unquantified):
                    </span>
                    <p className="text-xs text-slate-400 line-through mt-0.5">{item.original}</p>
                  </div>

                  <div className="p-3 bg-emerald-950/20 border border-emerald-900/50 rounded-lg">
                    <div className="flex items-center justify-between mb-1">
                      <span className="text-[10px] font-bold uppercase tracking-wider text-emerald-400">
                        Optimized with Metrics (X-Y-Z Formula):
                      </span>
                      <button
                        onClick={() => handleCopyRewrite(item.improved, idx)}
                        className="text-[11px] text-emerald-300 hover:text-white flex items-center gap-1 font-semibold"
                      >
                        {copiedIdx === idx ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
                        <span>{copiedIdx === idx ? 'Copied' : 'Copy'}</span>
                      </button>
                    </div>
                    <p className="text-xs text-emerald-200 font-medium leading-relaxed">{item.improved}</p>
                  </div>

                  <p className="text-[11px] text-slate-400 italic">
                    💡 <strong>Recruiter Rationale:</strong> {item.explanation}
                  </p>
                </div>
              ))}
            </div>
          </div>

          {/* Action Plan */}
          <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 shadow-xl">
            <h3 className="text-sm font-bold text-white mb-2">Priority Action Checklist</h3>
            <ul className="space-y-2 text-xs text-slate-300">
              {analysis.actionPlan.map((step, idx) => (
                <li key={idx} className="flex items-start gap-2 bg-slate-800/40 p-2.5 rounded-lg border border-slate-800">
                  <span className="w-5 h-5 rounded-full bg-indigo-600 text-white font-bold text-[10px] flex items-center justify-center shrink-0 mt-0.5">
                    {idx + 1}
                  </span>
                  <span className="leading-relaxed">{step}</span>
                </li>
              ))}
            </ul>
          </div>
        </div>
      </div>
    </div>
  );
};
