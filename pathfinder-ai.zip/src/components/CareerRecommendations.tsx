import React, { useState } from 'react';
import { CareerMatch, Career } from '../types/career';
import { CAREERS_DATABASE } from '../data/careersData';
import { 
  CheckCircle2, 
  TrendingUp, 
  DollarSign, 
  Sparkles, 
  AlertTriangle, 
  Search, 
  Building2, 
  Award, 
  ArrowRight,
  Filter
} from 'lucide-react';

interface CareerRecommendationsProps {
  matches: CareerMatch[];
  selectedCareer: Career;
  onSelectCareer: (career: Career) => void;
  onNavigateToTab: (tab: string) => void;
  aiPowered?: boolean;
}

export const CareerRecommendations: React.FC<CareerRecommendationsProps> = ({
  matches,
  selectedCareer,
  onSelectCareer,
  onNavigateToTab,
  aiPowered = true,
}) => {
  const [viewMode, setViewMode] = useState<'top_matches' | 'all_careers'>('top_matches');
  const [sectorFilter, setSectorFilter] = useState<string>('All');
  const [searchQuery, setSearchQuery] = useState<string>('');

  const sectors = ['All', 'Data & AI', 'Engineering & Tech', 'Product & Design', 'Cybersecurity', 'Cloud & DevOps', 'Business & Finance Tech', 'Healthcare Tech'];

  const filteredAllCareers = CAREERS_DATABASE.filter(c => {
    const matchesSector = sectorFilter === 'All' || c.category === sectorFilter;
    const matchesSearch = !searchQuery || 
      c.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      c.description.toLowerCase().includes(searchQuery.toLowerCase()) ||
      c.requiredSkills.some(s => s.name.toLowerCase().includes(searchQuery.toLowerCase()));
    return matchesSector && matchesSearch;
  });

  return (
    <div className="space-y-6 max-w-6xl mx-auto">
      {/* Top Banner */}
      <div className="bg-gradient-to-r from-slate-900 via-indigo-950/80 to-slate-900 p-6 rounded-2xl border border-indigo-900/40 shadow-xl flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 mb-2">
            <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-emerald-500/20 text-emerald-300 text-xs font-semibold">
              <Sparkles className="w-3.5 h-3.5" />
              <span>{aiPowered ? 'Gemini 3.8 Flash + O*NET RAG Grounded' : 'O*NET Semantic Match Engine'}</span>
            </span>
            <span className="text-xs text-slate-400">SOC Taxonomy Calibrated</span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight">
            Personalized Career Matches
          </h1>
          <p className="text-xs sm:text-sm text-slate-300 mt-1 max-w-2xl">
            Calculated by intersecting your skills, education, and personality scores with official Bureau of Labor Statistics economic data.
          </p>
        </div>

        {/* View toggle */}
        <div className="flex items-center bg-slate-800 p-1 rounded-xl border border-slate-700/60 shrink-0">
          <button
            onClick={() => setViewMode('top_matches')}
            className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-all ${
              viewMode === 'top_matches'
                ? 'bg-indigo-600 text-white shadow-md'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            Top 5 Matches
          </button>
          <button
            onClick={() => setViewMode('all_careers')}
            className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-all ${
              viewMode === 'all_careers'
                ? 'bg-indigo-600 text-white shadow-md'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            Explore All 20+ O*NET ({CAREERS_DATABASE.length})
          </button>
        </div>
      </div>

      {/* TOP 5 MATCHES VIEW */}
      {viewMode === 'top_matches' && (
        <div className="space-y-5">
          {matches.map((match, idx) => {
            const isTarget = selectedCareer.id === match.career.id;
            return (
              <div
                key={match.careerId}
                className={`p-6 rounded-2xl border transition-all ${
                  isTarget
                    ? 'bg-slate-900 border-indigo-500 ring-2 ring-indigo-500/30 shadow-2xl shadow-indigo-500/10'
                    : 'bg-slate-900/90 border-slate-800 hover:border-slate-700 shadow-lg'
                }`}
              >
                <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4 pb-4 border-b border-slate-800">
                  <div className="flex items-start gap-3">
                    <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-indigo-600 to-blue-500 flex items-center justify-center text-white font-extrabold text-sm shrink-0 shadow-md">
                      #{idx + 1}
                    </div>
                    <div>
                      <div className="flex flex-wrap items-center gap-2">
                        <h2 className="text-xl font-bold text-white">{match.career.title}</h2>
                        <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-slate-800 text-slate-400 border border-slate-700">
                          SOC: {match.career.socCode}
                        </span>
                        <span className="text-xs px-2.5 py-0.5 rounded-full bg-indigo-500/10 text-indigo-300 border border-indigo-500/20 font-medium">
                          {match.career.category}
                        </span>
                        {isTarget && (
                          <span className="text-xs px-2.5 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 font-bold flex items-center gap-1">
                            <CheckCircle2 className="w-3.5 h-3.5" /> Active Target
                          </span>
                        )}
                      </div>
                      <p className="text-xs text-slate-400 mt-1 max-w-2xl">{match.career.description}</p>
                    </div>
                  </div>

                  {/* Match Score Badge */}
                  <div className="flex items-center gap-4 shrink-0">
                    <div className="text-right">
                      <div className="text-2xl font-black bg-gradient-to-r from-emerald-400 to-indigo-400 bg-clip-text text-transparent">
                        {match.matchScore}%
                      </div>
                      <div className="text-[10px] font-semibold text-slate-400 uppercase tracking-wider">
                        Composite Match
                      </div>
                    </div>

                    <button
                      onClick={() => {
                        onSelectCareer(match.career);
                        onNavigateToTab('skill-gap');
                      }}
                      className={`px-4 py-2.5 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 shadow-md ${
                        isTarget
                          ? 'bg-emerald-600 hover:bg-emerald-500 text-white'
                          : 'bg-indigo-600 hover:bg-indigo-500 text-white'
                      }`}
                    >
                      <span>{isTarget ? 'Inspect Skill Gaps' : 'Select As Target'}</span>
                      <ArrowRight className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>

                {/* Score Breakdown Bars & Market Cards */}
                <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mt-4 pt-2">
                  {/* Market Economic Numbers */}
                  <div className="bg-slate-800/40 p-3.5 rounded-xl border border-slate-800 space-y-2">
                    <div className="flex items-center justify-between text-xs text-slate-400">
                      <span className="flex items-center gap-1">
                        <DollarSign className="w-3.5 h-3.5 text-emerald-400" /> Median Salary
                      </span>
                      <span className="font-bold text-white text-sm font-mono">
                        ${match.career.medianSalaryUSD.toLocaleString()}
                      </span>
                    </div>
                    <div className="w-full bg-slate-700 h-1 rounded-full overflow-hidden">
                      <div className="bg-emerald-500 h-full w-3/4" />
                    </div>
                    <div className="flex justify-between text-[10px] text-slate-500">
                      <span>10th: ${Math.round(match.career.salaryRange.p10 / 1000)}k</span>
                      <span>90th: ${Math.round(match.career.salaryRange.p90 / 1000)}k</span>
                    </div>
                  </div>

                  <div className="bg-slate-800/40 p-3.5 rounded-xl border border-slate-800 space-y-2">
                    <div className="flex items-center justify-between text-xs text-slate-400">
                      <span className="flex items-center gap-1">
                        <TrendingUp className="w-3.5 h-3.5 text-blue-400" /> 10-Yr Growth
                      </span>
                      <span className="font-bold text-blue-300 text-sm font-mono">
                        +{match.career.tenYearGrowthRate}%
                      </span>
                    </div>
                    <p className="text-[11px] text-slate-400">
                      ~{match.career.projectedOpeningsAnnual.toLocaleString()} openings annually
                    </p>
                    <div className="text-[10px] text-slate-500">
                      Automation Risk: <span className="text-emerald-400 font-semibold">{match.career.automationRisk}</span>
                    </div>
                  </div>

                  {/* Factor Breakdown */}
                  <div className="md:col-span-2 bg-slate-800/40 p-3.5 rounded-xl border border-slate-800 space-y-2">
                    <div className="text-xs font-semibold text-slate-300 mb-1">Algorithmic Factor Breakdown</div>
                    <div className="grid grid-cols-2 gap-x-4 gap-y-1.5 text-xs">
                      <div>
                        <div className="flex justify-between text-[11px] text-slate-400 mb-0.5">
                          <span>Skills Overlap</span>
                          <span className="font-bold text-white">{match.scoreBreakdown.skillsMatch}%</span>
                        </div>
                        <div className="w-full bg-slate-700 h-1.5 rounded-full overflow-hidden">
                          <div className="bg-indigo-500 h-full" style={{ width: `${match.scoreBreakdown.skillsMatch}%` }} />
                        </div>
                      </div>

                      <div>
                        <div className="flex justify-between text-[11px] text-slate-400 mb-0.5">
                          <span>Personality Fit</span>
                          <span className="font-bold text-white">{match.scoreBreakdown.personalityMatch}%</span>
                        </div>
                        <div className="w-full bg-slate-700 h-1.5 rounded-full overflow-hidden">
                          <div className="bg-blue-500 h-full" style={{ width: `${match.scoreBreakdown.personalityMatch}%` }} />
                        </div>
                      </div>

                      <div>
                        <div className="flex justify-between text-[11px] text-slate-400 mb-0.5">
                          <span>Goal & Salary Fit</span>
                          <span className="font-bold text-white">{match.scoreBreakdown.goalAlignment}%</span>
                        </div>
                        <div className="w-full bg-slate-700 h-1.5 rounded-full overflow-hidden">
                          <div className="bg-emerald-500 h-full" style={{ width: `${match.scoreBreakdown.goalAlignment}%` }} />
                        </div>
                      </div>

                      <div>
                        <div className="flex justify-between text-[11px] text-slate-400 mb-0.5">
                          <span>Market Outlook</span>
                          <span className="font-bold text-white">{match.scoreBreakdown.marketOpportunity}%</span>
                        </div>
                        <div className="w-full bg-slate-700 h-1.5 rounded-full overflow-hidden">
                          <div className="bg-purple-500 h-full" style={{ width: `${match.scoreBreakdown.marketOpportunity}%` }} />
                        </div>
                      </div>
                    </div>
                  </div>
                </div>

                {/* Reasoning & Strengths / Challenges */}
                <div className="mt-4 pt-3 border-t border-slate-800/80 grid grid-cols-1 md:grid-cols-3 gap-3 text-xs">
                  <div className="md:col-span-2">
                    <span className="text-[10px] font-bold text-indigo-400 uppercase tracking-wider block mb-1">
                      AI Matching Reasoning
                    </span>
                    <p className="text-slate-300 leading-relaxed">{match.reasoning}</p>
                  </div>

                  <div>
                    <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block mb-1">
                      Key Strengths & Growth Areas
                    </span>
                    <div className="space-y-1 text-[11px]">
                      <div className="text-emerald-300 flex items-start gap-1">
                        <CheckCircle2 className="w-3.5 h-3.5 shrink-0 mt-0.5 text-emerald-400" />
                        <span>{match.keyStrengths.join(', ')}</span>
                      </div>
                      <div className="text-amber-300 flex items-start gap-1">
                        <AlertTriangle className="w-3.5 h-3.5 shrink-0 mt-0.5 text-amber-400" />
                        <span>{match.mainChallenges.join(', ')}</span>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* ALL O*NET CAREERS EXPLORER */}
      {viewMode === 'all_careers' && (
        <div className="space-y-4">
          {/* Filter Bar */}
          <div className="bg-slate-900 p-4 rounded-xl border border-slate-800 flex flex-col sm:flex-row items-center justify-between gap-3">
            <div className="flex items-center gap-2 overflow-x-auto w-full sm:w-auto scrollbar-none pb-1 sm:pb-0">
              <Filter className="w-4 h-4 text-slate-400 shrink-0" />
              {sectors.map(sec => (
                <button
                  key={sec}
                  onClick={() => setSectorFilter(sec)}
                  className={`px-3 py-1 rounded-lg text-xs font-semibold whitespace-nowrap transition-all ${
                    sectorFilter === sec
                      ? 'bg-indigo-600 text-white'
                      : 'bg-slate-800 text-slate-400 hover:text-white'
                  }`}
                >
                  {sec}
                </button>
              ))}
            </div>

            <div className="relative w-full sm:w-64">
              <Search className="w-4 h-4 absolute left-3 top-2.5 text-slate-400" />
              <input
                type="text"
                value={searchQuery}
                onChange={e => setSearchQuery(e.target.value)}
                placeholder="Search title or skills..."
                className="w-full bg-slate-800 border border-slate-700 rounded-xl pl-9 pr-3 py-1.5 text-xs text-white focus:outline-none focus:ring-2 focus:ring-indigo-500"
              />
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {filteredAllCareers.map(career => {
              const isSelected = selectedCareer.id === career.id;
              return (
                <div
                  key={career.id}
                  className={`p-5 rounded-xl border transition-all flex flex-col justify-between ${
                    isSelected
                      ? 'bg-slate-800/90 border-indigo-500 shadow-lg'
                      : 'bg-slate-900 border-slate-800 hover:border-slate-700'
                  }`}
                >
                  <div>
                    <div className="flex items-start justify-between gap-2 mb-2">
                      <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-slate-800 text-slate-400 border border-slate-700">
                        {career.socCode}
                      </span>
                      <span className="text-[10px] px-2 py-0.5 rounded-full bg-indigo-500/10 text-indigo-300 font-medium">
                        {career.category}
                      </span>
                    </div>

                    <h3 className="text-base font-bold text-white">{career.title}</h3>
                    <p className="text-xs text-slate-400 mt-1 line-clamp-2">{career.description}</p>

                    <div className="grid grid-cols-2 gap-2 mt-4 text-xs bg-slate-800/60 p-2.5 rounded-lg border border-slate-800">
                      <div>
                        <span className="text-[10px] text-slate-500 block">Median Salary</span>
                        <span className="font-bold text-emerald-400 font-mono">
                          ${career.medianSalaryUSD.toLocaleString()}
                        </span>
                      </div>
                      <div>
                        <span className="text-[10px] text-slate-500 block">10-Yr Growth</span>
                        <span className="font-bold text-blue-400 font-mono">
                          +{career.tenYearGrowthRate}%
                        </span>
                      </div>
                    </div>

                    <div className="mt-3">
                      <span className="text-[10px] text-slate-400 font-semibold block mb-1.5">Key Skills:</span>
                      <div className="flex flex-wrap gap-1">
                        {career.requiredSkills.slice(0, 4).map(s => (
                          <span
                            key={s.name}
                            className="text-[10px] px-2 py-0.5 rounded bg-slate-800 text-slate-300 border border-slate-700/60"
                          >
                            {s.name}
                          </span>
                        ))}
                      </div>
                    </div>
                  </div>

                  <div className="mt-5 pt-3 border-t border-slate-800/80 flex items-center justify-between">
                    <span className="text-[11px] text-slate-400">
                      Remote: <strong className="text-slate-200">{career.remoteFriendliness}</strong>
                    </span>
                    <button
                      onClick={() => {
                        onSelectCareer(career);
                        onNavigateToTab('skill-gap');
                      }}
                      className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-all ${
                        isSelected
                          ? 'bg-emerald-600 text-white'
                          : 'bg-indigo-600 hover:bg-indigo-500 text-white'
                      }`}
                    >
                      {isSelected ? 'Target Selected' : 'Set as Target'}
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}
    </div>
  );
};
