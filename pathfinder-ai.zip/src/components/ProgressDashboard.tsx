import React, { useState } from 'react';
import { UserProfile, Career, CareerRoadmap, CareerSkillGapAnalysis, ResumeATSAnalysis } from '../types/career';
import { 
  CheckCircle2, 
  Award, 
  Clock, 
  Calendar, 
  Download, 
  Sparkles, 
  Target, 
  Plus, 
  Trash2,
  FileCheck
} from 'lucide-react';

interface ProgressDashboardProps {
  profile: UserProfile;
  career: Career;
  roadmap: CareerRoadmap;
  gapAnalysis: CareerSkillGapAnalysis;
  atsAnalysis: ResumeATSAnalysis;
  onToggleActionItem: (milestoneId: string, actionId: string) => void;
}

export const ProgressDashboard: React.FC<ProgressDashboardProps> = ({
  profile,
  career,
  roadmap,
  gapAnalysis,
  atsAnalysis,
  onToggleActionItem,
}) => {
  const [customMilestones, setCustomMilestones] = useState<string[]>([
    'Schedule 2 informational coffee chats with senior engineers on LinkedIn',
    'Set up automated GitHub Actions CI/CD pipeline on capstone repo',
    'Review System Design interview fundamentals (Grokking System Design)'
  ]);
  const [newMilestoneText, setNewMilestoneText] = useState('');

  // Calculate overall career readiness score
  // Skills readiness (40%) + Roadmap completion (35%) + ATS score (25%)
  let totalRoadmapTasks = 0;
  let completedRoadmapTasks = 0;
  roadmap.milestones.forEach(m => {
    m.actionItems.forEach(a => {
      totalRoadmapTasks += 1;
      if (a.completed) completedRoadmapTasks += 1;
    });
  });

  const roadmapPercent = totalRoadmapTasks > 0 ? (completedRoadmapTasks / totalRoadmapTasks) * 100 : 0;
  const compositeReadiness = Math.round(
    (gapAnalysis.overallReadinessScore * 0.40) +
    (roadmapPercent * 0.35) +
    (atsAnalysis.overallScore * 0.25)
  );

  const addCustomMilestone = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newMilestoneText.trim()) return;
    setCustomMilestones([...customMilestones, newMilestoneText.trim()]);
    setNewMilestoneText('');
  };

  const removeCustomMilestone = (index: number) => {
    setCustomMilestones(customMilestones.filter((_, i) => i !== index));
  };

  const handleExportBrief = () => {
    const report = `=====================================================
CAREERFORGE AI - OCCUPATIONAL ROADMAP & READINESS DOSSIER
=====================================================
Generated For: ${profile.fullName}
Persona Segment: ${profile.personaType || 'Professional'}
Education: ${profile.education.level} in ${profile.education.field}
Current Experience: ${profile.experienceLevel}

TARGET OCCUPATION (O*NET BENCHMARKED):
Title: ${career.title} (SOC Code: ${career.socCode})
Sector: ${career.category}
Median Annual Compensation: $${career.medianSalaryUSD.toLocaleString()} USD
10-Year Projected Growth: +${career.tenYearGrowthRate}%

PROGRESS & READINESS SCORES:
- Composite Readiness Index: ${compositeReadiness}%
- Skill Competency Match: ${gapAnalysis.overallReadinessScore}%
- Phased Roadmap Progress: ${Math.round(roadmapPercent)}% (${completedRoadmapTasks}/${totalRoadmapTasks} tasks complete)
- Resume ATS Compatibility: ${atsAnalysis.overallScore}%

ACTIVE SKILL GAPS REQUIRING MASTERY:
${gapAnalysis.gaps.filter(g => g.status !== 'acquired').map(g => `- [${g.priority} Priority] ${g.skill} (~${g.estimatedHoursToLearn} hrs study)`).join('\n')}

CERTIFICATIONS TO PURSUE:
${career.topCertifications.map(c => `- ${c}`).join('\n')}

Generated automatically via CareerForge AI.
`;

    const blob = new Blob([report], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `CareerForge-Plan-${career.id}.txt`;
    a.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div className="space-y-6 max-w-6xl mx-auto">
      {/* Header Banner */}
      <div className="bg-gradient-to-r from-slate-900 via-indigo-950/70 to-slate-900 p-6 rounded-2xl border border-indigo-900/40 shadow-xl flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 mb-2">
            <span className="text-xs px-2.5 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 font-bold border border-emerald-500/30">
              Personal Command Center
            </span>
            <span className="text-xs text-slate-400 font-mono">Target: {career.title}</span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight">
            Milestone Progress & Readiness Dashboard
          </h1>
          <p className="text-xs sm:text-sm text-slate-300 mt-1 max-w-2xl">
            Live tracker synthesizing your skill gap remediation, weekly roadmap tasks, and resume ATS qualification.
          </p>
        </div>

        <button
          onClick={handleExportBrief}
          className="px-4 py-2.5 bg-slate-800 hover:bg-slate-700 text-slate-200 hover:text-white rounded-xl text-xs font-bold border border-slate-700 transition-all flex items-center gap-2 shrink-0 shadow-md"
        >
          <Download className="w-4 h-4 text-indigo-400" />
          <span>Export Career Brief (.txt)</span>
        </button>
      </div>

      {/* High-Level Scorecards */}
      <div className="grid grid-cols-1 sm:grid-cols-4 gap-4">
        <div className="bg-slate-900 border border-slate-800 p-5 rounded-2xl shadow-xl flex items-center justify-between">
          <div>
            <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block">
              Composite Readiness
            </span>
            <span className="text-3xl font-black text-white mt-1 block">
              {compositeReadiness}%
            </span>
            <span className="text-[10px] text-emerald-400 font-semibold">
              {compositeReadiness >= 75 ? 'Interview Ready' : 'On Track'}
            </span>
          </div>
          <div className="w-12 h-12 rounded-full bg-indigo-600/20 text-indigo-400 flex items-center justify-center">
            <Target className="w-6 h-6" />
          </div>
        </div>

        <div className="bg-slate-900 border border-slate-800 p-5 rounded-2xl shadow-xl">
          <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block">
            Skills Competency
          </span>
          <span className="text-3xl font-black text-emerald-400 mt-1 block">
            {gapAnalysis.overallReadinessScore}%
          </span>
          <span className="text-[10px] text-slate-400">
            {gapAnalysis.readySkillsCount} of {gapAnalysis.gaps.length} skills mastered
          </span>
        </div>

        <div className="bg-slate-900 border border-slate-800 p-5 rounded-2xl shadow-xl">
          <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block">
            Roadmap Execution
          </span>
          <span className="text-3xl font-black text-blue-400 mt-1 block">
            {Math.round(roadmapPercent)}%
          </span>
          <span className="text-[10px] text-slate-400">
            {completedRoadmapTasks} of {totalRoadmapTasks} action items complete
          </span>
        </div>

        <div className="bg-slate-900 border border-slate-800 p-5 rounded-2xl shadow-xl">
          <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block">
            ATS Resume Pass Rate
          </span>
          <span className="text-3xl font-black text-purple-400 mt-1 block">
            {atsAnalysis.overallScore}%
          </span>
          <span className="text-[10px] text-slate-400">
            {atsAnalysis.matchedKeywords.length} target keywords verified
          </span>
        </div>
      </div>

      {/* Earned Milestones & Badges */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 shadow-xl">
        <h2 className="text-base font-bold text-white mb-3 flex items-center gap-2">
          <Award className="w-4 h-4 text-amber-400" />
          <span>Career Milestone Badges</span>
        </h2>
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
          <div className="p-3 bg-slate-800/60 rounded-xl border border-slate-700/60 flex items-center gap-3">
            <div className="w-8 h-8 rounded-lg bg-emerald-500/20 text-emerald-400 flex items-center justify-center font-bold text-xs shrink-0">
              ✓
            </div>
            <div>
              <span className="text-xs font-bold text-white block">Profile Calibrated</span>
              <span className="text-[10px] text-slate-400">RIASEC traits scored</span>
            </div>
          </div>

          <div className="p-3 bg-slate-800/60 rounded-xl border border-slate-700/60 flex items-center gap-3">
            <div className="w-8 h-8 rounded-lg bg-indigo-500/20 text-indigo-400 flex items-center justify-center font-bold text-xs shrink-0">
              ✓
            </div>
            <div>
              <span className="text-xs font-bold text-white block">O*NET Target Set</span>
              <span className="text-[10px] text-slate-400">{career.title}</span>
            </div>
          </div>

          <div className="p-3 bg-slate-800/60 rounded-xl border border-slate-700/60 flex items-center gap-3">
            <div className="w-8 h-8 rounded-lg bg-blue-500/20 text-blue-400 flex items-center justify-center font-bold text-xs shrink-0">
              ✓
            </div>
            <div>
              <span className="text-xs font-bold text-white block">Roadmap Sequenced</span>
              <span className="text-[10px] text-slate-400">{roadmap.durationMonths} months active</span>
            </div>
          </div>

          <div className="p-3 bg-slate-800/60 rounded-xl border border-slate-700/60 flex items-center gap-3">
            <div className="w-8 h-8 rounded-lg bg-purple-500/20 text-purple-400 flex items-center justify-center font-bold text-xs shrink-0">
              ✓
            </div>
            <div>
              <span className="text-xs font-bold text-white block">ATS Optimized</span>
              <span className="text-[10px] text-slate-400">X-Y-Z rewrites ready</span>
            </div>
          </div>
        </div>
      </div>

      {/* Active Roadmap Tasks Checklist */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 shadow-xl">
        <h2 className="text-base font-bold text-white mb-1">
          Active Roadmap Action Items
        </h2>
        <p className="text-xs text-slate-400 mb-4">
          Click any task to toggle completion and dynamically update your readiness index.
        </p>

        <div className="space-y-2">
          {roadmap.milestones.map(m => (
            <div key={m.id} className="space-y-1.5 mb-4">
              <span className="text-[11px] font-bold text-indigo-400 uppercase tracking-wider block">
                Month {m.month}: {m.phaseTitle}
              </span>
              {m.actionItems.map(item => (
                <div
                  key={item.id}
                  onClick={() => onToggleActionItem(m.id, item.id)}
                  className={`p-3 rounded-xl border cursor-pointer transition-all flex items-center justify-between text-xs ${
                    item.completed
                      ? 'bg-emerald-950/20 border-emerald-900/40 text-emerald-200'
                      : 'bg-slate-800/40 hover:bg-slate-800 border-slate-700/50 text-slate-300'
                  }`}
                >
                  <div className="flex items-center gap-3">
                    <div
                      className={`w-4 h-4 rounded border flex items-center justify-center ${
                        item.completed ? 'bg-emerald-500 border-emerald-400 text-white' : 'border-slate-600'
                      }`}
                    >
                      {item.completed && <CheckCircle2 className="w-3.5 h-3.5" />}
                    </div>
                    <span className={item.completed ? 'line-through text-slate-500' : 'text-slate-200'}>
                      {item.title}
                    </span>
                  </div>
                  <span className="text-[10px] text-slate-400">~{item.estimatedHours}h</span>
                </div>
              ))}
            </div>
          ))}
        </div>
      </div>

      {/* Custom Goals & Accountability Notes */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 shadow-xl">
        <h2 className="text-base font-bold text-white mb-2">Custom Accountability Goals</h2>
        <form onSubmit={addCustomMilestone} className="flex gap-2 mb-4">
          <input
            type="text"
            value={newMilestoneText}
            onChange={e => setNewMilestoneText(e.target.value)}
            placeholder="Add a custom milestone (e.g. Apply to 5 target companies this Friday)..."
            className="flex-1 bg-slate-800 border border-slate-700 rounded-xl px-4 py-2 text-xs text-white focus:outline-none focus:ring-2 focus:ring-indigo-500"
          />
          <button
            type="submit"
            className="px-4 py-2 bg-indigo-600 hover:bg-indigo-500 text-white rounded-xl text-xs font-semibold flex items-center gap-1 shadow-md"
          >
            <Plus className="w-4 h-4" /> Add
          </button>
        </form>

        <ul className="space-y-2">
          {customMilestones.map((milestone, idx) => (
            <li
              key={idx}
              className="p-3 bg-slate-800/40 border border-slate-800 rounded-xl flex items-center justify-between text-xs text-slate-300"
            >
              <span>{milestone}</span>
              <button
                onClick={() => removeCustomMilestone(idx)}
                className="text-slate-500 hover:text-rose-400 p-1"
              >
                <Trash2 className="w-3.5 h-3.5" />
              </button>
            </li>
          ))}
        </ul>
      </div>
    </div>
  );
};
