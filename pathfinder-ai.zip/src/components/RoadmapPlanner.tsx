import React from 'react';
import { CareerRoadmap, Career } from '../types/career';
import { 
  Calendar, 
  Clock, 
  CheckCircle2, 
  Award, 
  FolderGit2, 
  Sparkles, 
  ShieldCheck, 
  ArrowRight,
  BookOpen
} from 'lucide-react';

interface RoadmapPlannerProps {
  roadmap: CareerRoadmap;
  career: Career;
  onToggleActionItem: (milestoneId: string, actionId: string) => void;
  onChangeDuration: (months: 3 | 6 | 12) => void;
  onNavigateToTab: (tab: string) => void;
}

export const RoadmapPlanner: React.FC<RoadmapPlannerProps> = ({
  roadmap,
  career,
  onToggleActionItem,
  onChangeDuration,
  onNavigateToTab,
}) => {
  // calculate total progress
  let totalTasks = 0;
  let completedTasks = 0;
  roadmap.milestones.forEach(m => {
    m.actionItems.forEach(a => {
      totalTasks += 1;
      if (a.completed) completedTasks += 1;
    });
  });

  const progressPercent = totalTasks > 0 ? Math.round((completedTasks / totalTasks) * 100) : 0;

  return (
    <div className="space-y-6 max-w-6xl mx-auto">
      {/* Header Banner */}
      <div className="bg-gradient-to-r from-slate-900 via-indigo-950/70 to-slate-900 p-6 rounded-2xl border border-indigo-900/40 shadow-xl">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2 mb-2">
              <span className="text-xs px-2.5 py-0.5 rounded-full bg-indigo-500/20 text-indigo-300 font-bold border border-indigo-500/30">
                Personalized Phased Roadmap
              </span>
              <span className="text-xs text-slate-400 font-mono">Target: {career.title}</span>
            </div>
            <h1 className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight">
              {roadmap.durationMonths}-Month Career Transition Plan
            </h1>
            <p className="text-xs sm:text-sm text-slate-300 mt-1 max-w-2xl">
              Sequenced milestones combining coursework, portfolio capstones, and certification targets calibrated to your weekly schedule.
            </p>
          </div>

          {/* Timeline Switcher */}
          <div className="flex items-center bg-slate-800 p-1 rounded-xl border border-slate-700/60 shrink-0">
            {[3, 6, 12].map(duration => (
              <button
                key={duration}
                onClick={() => onChangeDuration(duration as 3 | 6 | 12)}
                className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all ${
                  roadmap.durationMonths === duration
                    ? 'bg-indigo-600 text-white shadow-md'
                    : 'text-slate-400 hover:text-white'
                }`}
              >
                {duration} Months
              </button>
            ))}
          </div>
        </div>

        {/* Plan Overview Stats */}
        <div className="grid grid-cols-1 sm:grid-cols-4 gap-4 mt-6 pt-6 border-t border-slate-800">
          <div className="bg-slate-800/60 p-3.5 rounded-xl border border-slate-700/60">
            <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block">Overall Completion</span>
            <div className="flex items-baseline gap-2 mt-1">
              <span className="text-2xl font-black text-emerald-400">{progressPercent}%</span>
              <span className="text-xs text-slate-400">({completedTasks}/{totalTasks} tasks)</span>
            </div>
            <div className="w-full bg-slate-700 h-1.5 rounded-full mt-2 overflow-hidden">
              <div className="bg-emerald-500 h-full transition-all duration-300" style={{ width: `${progressPercent}%` }} />
            </div>
          </div>

          <div className="bg-slate-800/60 p-3.5 rounded-xl border border-slate-700/60">
            <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block">Weekly Cadence</span>
            <span className="text-xl font-black text-white mt-1 block flex items-center gap-1.5">
              <Clock className="w-4 h-4 text-indigo-400" /> {roadmap.weeklyHourCommitment} hrs / week
            </span>
            <span className="text-[10px] text-slate-500">Paced for sustainable retention</span>
          </div>

          <div className="bg-slate-800/60 p-3.5 rounded-xl border border-slate-700/60">
            <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block">Total Estimated Effort</span>
            <span className="text-xl font-black text-white mt-1 block flex items-center gap-1.5">
              <Calendar className="w-4 h-4 text-blue-400" /> ~{roadmap.totalEstimatedHours} hours
            </span>
            <span className="text-[10px] text-slate-500">Includes reading & projects</span>
          </div>

          <div className="bg-slate-800/60 p-3.5 rounded-xl border border-slate-700/60 flex items-center justify-between">
            <div>
              <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block">Target Milestone</span>
              <span className="text-sm font-bold text-white mt-1 block truncate max-w-[140px]">
                {career.topCertifications[0] || 'Portfolio Capstone'}
              </span>
              <span className="text-[10px] text-emerald-400">Industry Credential</span>
            </div>
            <Award className="w-7 h-7 text-amber-400 shrink-0" />
          </div>
        </div>
      </div>

      {/* Ethical Guardrail Disclaimer */}
      <div className="bg-slate-900/80 border border-slate-800 p-3.5 rounded-xl text-xs text-slate-400 flex items-center gap-2">
        <ShieldCheck className="w-4 h-4 text-emerald-400 shrink-0" />
        <span>
          <strong>Ethical AI Guardrail:</strong> This roadmap provides structured pedagogical pacing based on verified curriculum benchmarks. Hiring decisions depend on demonstrable problem solving, code quality, and market conditions; no employment outcome is guaranteed.
        </span>
      </div>

      {/* Milestones Phased Timeline */}
      <div className="space-y-6">
        {roadmap.milestones.map((m, mIdx) => (
          <div
            key={m.id}
            className="bg-slate-900 border border-slate-800 rounded-2xl p-6 shadow-xl relative overflow-hidden"
          >
            {/* Top Phase Header */}
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-4 border-b border-slate-800">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-indigo-600 text-white font-extrabold flex items-center justify-center shrink-0 shadow-md">
                  M{m.month}
                </div>
                <div>
                  <div className="flex items-center gap-2">
                    <h2 className="text-lg font-bold text-white">{m.phaseTitle}</h2>
                    <span className="text-[10px] px-2 py-0.5 rounded bg-indigo-500/10 text-indigo-300 font-medium border border-indigo-500/20">
                      Month {m.month} Milestone
                    </span>
                  </div>
                  <p className="text-xs text-slate-400 mt-0.5">Focus: {m.focusArea}</p>
                </div>
              </div>

              {m.certificationTarget && (
                <div className="flex items-center gap-1.5 px-3 py-1 bg-amber-500/10 border border-amber-500/20 rounded-lg text-xs text-amber-300 font-medium">
                  <Award className="w-3.5 h-3.5 text-amber-400" />
                  <span>Target: {m.certificationTarget}</span>
                </div>
              )}
            </div>

            {/* Core Objectives */}
            <div className="mt-4">
              <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400 block mb-2">
                Phase Learning Objectives:
              </span>
              <ul className="grid grid-cols-1 md:grid-cols-3 gap-2">
                {m.objectives.map((obj, oIdx) => (
                  <li
                    key={oIdx}
                    className="text-xs text-slate-300 bg-slate-800/40 p-2.5 rounded-xl border border-slate-800/80 flex items-start gap-2"
                  >
                    <CheckCircle2 className="w-3.5 h-3.5 text-indigo-400 shrink-0 mt-0.5" />
                    <span>{obj}</span>
                  </li>
                ))}
              </ul>
            </div>

            {/* Action Items with Interactive Checkboxes */}
            <div className="mt-5 pt-4 border-t border-slate-800">
              <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400 block mb-3">
                Actionable Tasks ({m.actionItems.filter(a => a.completed).length}/{m.actionItems.length} completed):
              </span>
              <div className="space-y-2">
                {m.actionItems.map(item => (
                  <div
                    key={item.id}
                    onClick={() => onToggleActionItem(m.id, item.id)}
                    className={`p-3 rounded-xl border cursor-pointer transition-all flex items-center justify-between ${
                      item.completed
                        ? 'bg-emerald-950/20 border-emerald-900/40 text-emerald-200'
                        : 'bg-slate-800/50 hover:bg-slate-800 border-slate-700/60 text-slate-300'
                    }`}
                  >
                    <div className="flex items-center gap-3">
                      <div
                        className={`w-5 h-5 rounded-md border flex items-center justify-center transition-all ${
                          item.completed
                            ? 'bg-emerald-500 border-emerald-400 text-white'
                            : 'border-slate-600 bg-slate-800'
                        }`}
                      >
                        {item.completed && <CheckCircle2 className="w-3.5 h-3.5" />}
                      </div>
                      <span className={`text-xs font-medium ${item.completed ? 'line-through text-slate-400' : 'text-white'}`}>
                        {item.title}
                      </span>
                    </div>

                    <div className="flex items-center gap-3 text-xs text-slate-400 shrink-0">
                      <span className="text-[10px] px-2 py-0.5 rounded bg-slate-800 text-slate-400 border border-slate-700 uppercase">
                        {item.type}
                      </span>
                      <span className="flex items-center gap-1 text-[11px] text-slate-400">
                        <Clock className="w-3 h-3 text-indigo-400" /> ~{item.estimatedHours}h
                      </span>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Capstone Project Showcase Box */}
            <div className="mt-5 p-4 rounded-xl bg-gradient-to-r from-slate-800/80 to-indigo-950/40 border border-indigo-900/40">
              <div className="flex items-start justify-between gap-3">
                <div>
                  <div className="flex items-center gap-1.5 text-xs font-bold text-indigo-300 uppercase tracking-wider mb-1">
                    <FolderGit2 className="w-4 h-4 text-indigo-400" />
                    <span>Capstone Project: {m.capstoneProject.title}</span>
                  </div>
                  <p className="text-xs text-slate-300 leading-relaxed">{m.capstoneProject.description}</p>

                  <div className="mt-3">
                    <span className="text-[10px] font-semibold text-slate-400 uppercase tracking-wider block mb-1">
                      Required Deliverables:
                    </span>
                    <div className="flex flex-wrap gap-2">
                      {m.capstoneProject.deliverables.map((deliv, dIdx) => (
                        <span
                          key={dIdx}
                          className="text-[11px] px-2.5 py-1 rounded-lg bg-slate-800/90 text-slate-300 border border-slate-700/60"
                        >
                          ✓ {deliv}
                        </span>
                      ))}
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Bottom CTA to Resume Analyzer */}
      <div className="bg-slate-900 border border-slate-800 p-6 rounded-2xl flex flex-col sm:flex-row items-center justify-between gap-4">
        <div>
          <h3 className="text-base font-bold text-white">Ready to test your resume against this career?</h3>
          <p className="text-xs text-slate-400 mt-1">Upload or paste your resume to get an instant ATS score and keyword gap analysis.</p>
        </div>
        <button
          onClick={() => onNavigateToTab('resume')}
          className="px-5 py-2.5 bg-indigo-600 hover:bg-indigo-500 text-white rounded-xl text-xs font-bold transition-all flex items-center gap-2 shadow-lg shadow-indigo-600/20 shrink-0"
        >
          <span>Scan Resume in ATS Analyzer</span>
          <ArrowRight className="w-4 h-4" />
        </button>
      </div>
    </div>
  );
};
