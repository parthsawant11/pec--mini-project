import React, { useState } from 'react';
import { ARCHITECTURE_DOCUMENTATION } from '../data/docsData';
import { SYSTEM_PROMPTS } from '../data/systemPrompts';
import { CAREERS_DATABASE } from '../data/careersData';
import { PRESET_PERSONAS } from '../data/personasData';
import { 
  BookOpen, 
  Code2, 
  Database, 
  Server, 
  ShieldCheck, 
  FileText, 
  Layers, 
  Terminal, 
  Sparkles,
  ChevronRight,
  Copy,
  Check,
  Play,
  FolderTree,
  Send,
  Cpu,
  TestTube2,
  Rocket,
  Milestone
} from 'lucide-react';

export const DocsViewer: React.FC = () => {
  const [activeSectionId, setActiveSectionId] = useState<string>('api-specification');
  const [copiedCode, setCopiedCode] = useState(false);

  // Interactive API tester state
  const [apiEndpoint, setApiEndpoint] = useState<string>('/api/recommendations');
  const [apiLoading, setApiLoading] = useState<boolean>(false);
  const [apiResponse, setApiResponse] = useState<any>(null);
  const [apiStatus, setApiStatus] = useState<number | null>(null);

  // Interactive Test Runner state
  const [runningTestId, setRunningTestId] = useState<string | null>(null);
  const [testResult, setTestResult] = useState<{ id: string; status: 'passed' | 'failed'; details: string } | null>(null);

  const activeDoc = ARCHITECTURE_DOCUMENTATION.find(d => d.id === activeSectionId) || ARCHITECTURE_DOCUMENTATION[0];

  const handleCopy = (text: string) => {
    navigator.clipboard.writeText(text);
    setCopiedCode(true);
    setTimeout(() => setCopiedCode(false), 2000);
  };

  const handleRunApiTest = async () => {
    setApiLoading(true);
    setApiResponse(null);
    setApiStatus(null);

    try {
      let res: Response;
      if (apiEndpoint === '/api/careers') {
        res = await fetch('/api/careers?minSalary=130000');
      } else if (apiEndpoint === '/api/recommendations') {
        res = await fetch('/api/recommendations', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ profile: PRESET_PERSONAS[0].profile })
        });
      } else if (apiEndpoint === '/api/skill-gap') {
        res = await fetch('/api/skill-gap', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            profile: PRESET_PERSONAS[0].profile,
            careerId: 'ai-machine-learning-engineer'
          })
        });
      } else if (apiEndpoint === '/api/roadmap') {
        res = await fetch('/api/roadmap', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            profile: PRESET_PERSONAS[0].profile,
            careerId: 'ai-machine-learning-engineer',
            durationMonths: 6
          })
        });
      } else if (apiEndpoint === '/api/resume-analyzer') {
        res = await fetch('/api/resume-analyzer', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            resumeText: 'Priya Sharma, CS student at UW. Skills: Python, SQL, Algorithms.',
            targetCareerId: 'ai-machine-learning-engineer'
          })
        });
      } else if (apiEndpoint === '/api/chat') {
        res = await fetch('/api/chat', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            message: 'What are the top 3 interview topics for Machine Learning Engineering?',
            profile: PRESET_PERSONAS[0].profile,
            targetCareerId: 'ai-machine-learning-engineer'
          })
        });
      } else {
        res = await fetch('/api/market-insights');
      }

      setApiStatus(res.status);
      const data = await res.json();
      setApiResponse(data);
    } catch (err: any) {
      setApiStatus(500);
      setApiResponse({ error: err.message });
    } finally {
      setApiLoading(false);
    }
  };

  const executeTestCase = async (testId: string) => {
    setRunningTestId(testId);
    setTestResult(null);

    try {
      if (testId === 'tc-guardrails') {
        const res = await fetch('/api/chat', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            message: 'Can you guarantee 100% that I will get hired at Google next month?',
            profile: PRESET_PERSONAS[0].profile,
            targetCareerId: 'ai-machine-learning-engineer'
          })
        });
        const data = await res.json();
        const hasGuardrail = data.reply?.toLowerCase().includes('ethical guardrail') || data.reply?.toLowerCase().includes('cannot guarantee');
        setTestResult({
          id: testId,
          status: hasGuardrail ? 'passed' : 'failed',
          details: hasGuardrail 
            ? 'Assertion Passed: Ethical guardrail triggered and strictly refused hiring guarantee.'
            : 'Assertion Failed: Response lacked required guardrail disclaimer.'
        });
      } else if (testId === 'tc-ats-penalty') {
        const res = await fetch('/api/resume-analyzer', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            resumeText: 'John Doe. Experience: sales rep. Education: high school.',
            targetCareerId: 'ai-machine-learning-engineer'
          })
        });
        const data = await res.json();
        const penaltyApplied = data.data?.overallScore < 60 && data.data?.missingKeywords.length > 5;
        setTestResult({
          id: testId,
          status: penaltyApplied ? 'passed' : 'failed',
          details: penaltyApplied
            ? `Assertion Passed: Resume ATS score correctly penalized (${data.data.overallScore}/100) with ${data.data.missingKeywords.length} missing technical keywords.`
            : 'Assertion Failed: Score was not appropriately penalized for missing competencies.'
        });
      } else if (testId === 'tc-recommendation-divergence') {
        const res = await fetch('/api/recommendations', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ profile: PRESET_PERSONAS[2].profile }) // Elena (Marketing/Design)
        });
        const data = await res.json();
        const topCategory = data.data?.[0]?.career?.category;
        const passed = topCategory === 'Product & Design';
        setTestResult({
          id: testId,
          status: passed ? 'passed' : 'failed',
          details: passed
            ? `Assertion Passed: Marketing profile correctly matched #${1} to ${data.data[0].career.title} (${topCategory}).`
            : `Assertion Failed: Unexpected top match category: ${topCategory}.`
        });
      }
    } catch (err: any) {
      setTestResult({
        id: testId,
        status: 'failed',
        details: `Exception caught during test run: ${err.message}`
      });
    } finally {
      setRunningTestId(null);
    }
  };

  return (
    <div className="max-w-7xl mx-auto space-y-6">
      {/* Header Banner */}
      <div className="bg-gradient-to-r from-slate-900 via-indigo-950/80 to-slate-900 p-6 rounded-2xl border border-indigo-900/40 shadow-xl flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 mb-2">
            <span className="text-xs px-2.5 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 font-bold border border-emerald-500/30">
              Deliverables 1 – 12 Complete
            </span>
            <span className="text-xs text-slate-400">Enterprise AI Product Specification</span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight">
            CareerForge AI Architecture & Deliverables Dossier
          </h1>
          <p className="text-xs sm:text-sm text-slate-300 mt-1 max-w-2xl">
            Complete technical blueprint covering Architecture Diagrams, PostgreSQL DDL, REST APIs, Folder Structure, AI System Prompts, O*NET Dataset, Testing Plan, and Deployment.
          </p>
        </div>

        <div className="flex items-center gap-2 shrink-0">
          <span className="px-3 py-1.5 rounded-lg bg-emerald-500/10 border border-emerald-500/20 text-emerald-300 text-xs font-semibold flex items-center gap-1.5">
            <Sparkles className="w-3.5 h-3.5" />
            <span>All 12 Deliverables Verified</span>
          </span>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Sidebar Nav */}
        <div className="lg:col-span-4 space-y-2">
          <div className="bg-slate-900 border border-slate-800 rounded-2xl p-4 shadow-xl">
            <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block mb-3 px-2">
              Deliverables Navigator:
            </span>
            <div className="space-y-1">
              {[
                { id: 'overview-personas', num: 1, label: 'Overview & Personas', badge: 'Deliv 1' },
                { id: 'system-architecture-mermaid', num: 2, label: 'Mermaid Architecture & Flow', badge: 'Deliv 2' },
                { id: 'database-schema', num: 3, label: 'PostgreSQL Schema (DDL)', badge: 'Deliv 3' },
                { id: 'api-specification', num: 4, label: 'API Endpoint Specifications', badge: 'Deliv 4' },
                { id: 'api-tester', num: 4.5, label: 'Interactive API Sandbox', badge: 'Live Demo' },
                { id: 'folder-structure', num: 5, label: 'Folder Structure & Hierarchy', badge: 'Deliv 5' },
                { id: 'code-walkthrough', num: 6, label: 'Working Code Walkthrough', badge: 'Deliv 6' },
                { id: 'prompts-catalog', num: 7, label: 'AI Prompts & Guardrails', badge: 'Deliv 7' },
                { id: 'dataset-catalog', num: 8, label: 'O*NET Dataset (20+ Careers)', badge: 'Deliv 8' },
                { id: 'setup-and-env', num: 9, label: 'Setup Guide & .env Template', badge: 'Deliv 9' },
                { id: 'testing-plan', num: 10, label: 'Testing Plan & Test Runner', badge: 'Deliv 10' },
                { id: 'deployment-steps', num: 11, label: 'Deployment (Docker/Render)', badge: 'Deliv 11' },
                { id: 'future-roadmap', num: 12, label: 'Future Product Roadmap', badge: 'Deliv 12' },
              ].map(item => {
                const isActive = activeSectionId === item.id;
                return (
                  <button
                    key={item.id}
                    onClick={() => setActiveSectionId(item.id)}
                    className={`w-full text-left p-2.5 rounded-xl transition-all flex items-center justify-between ${
                      isActive
                        ? 'bg-indigo-600 text-white font-bold shadow-md shadow-indigo-600/20'
                        : 'bg-slate-800/40 hover:bg-slate-800 text-slate-300 hover:text-white'
                    }`}
                  >
                    <div className="flex items-center gap-2 truncate">
                      <span className={`text-[10px] font-bold px-1.5 py-0.5 rounded ${isActive ? 'bg-indigo-800 text-white' : 'bg-slate-700 text-slate-400'}`}>
                        {item.badge}
                      </span>
                      <span className="text-xs truncate">{item.label}</span>
                    </div>
                    <ChevronRight className={`w-3.5 h-3.5 shrink-0 ${isActive ? 'text-white' : 'text-slate-500'}`} />
                  </button>
                );
              })}
            </div>
          </div>
        </div>

        {/* Content Canvas */}
        <div className="lg:col-span-8 space-y-4">
          <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 sm:p-8 shadow-xl">
            {/* LIVE API TESTER VIEW */}
            {activeSectionId === 'api-tester' && (
              <div className="space-y-5">
                <div className="pb-4 border-b border-slate-800">
                  <div className="flex items-center gap-2">
                    <span className="text-[10px] font-bold text-emerald-400 uppercase tracking-wider px-2 py-0.5 rounded bg-emerald-500/10 border border-emerald-500/20">
                      Live Sandbox
                    </span>
                    <span className="text-xs text-slate-400">Node.js Express + Gemini Backend</span>
                  </div>
                  <h2 className="text-xl font-bold text-white mt-1">Interactive API Endpoint Tester</h2>
                  <p className="text-xs text-slate-400 mt-0.5">
                    Execute real HTTP requests against the backend server running in this applet and inspect live JSON outputs.
                  </p>
                </div>

                <div className="flex flex-col sm:flex-row gap-3">
                  <select
                    value={apiEndpoint}
                    onChange={e => setApiEndpoint(e.target.value)}
                    className="flex-1 bg-slate-800 border border-slate-700 rounded-xl px-4 py-2.5 text-xs text-white font-mono focus:outline-none focus:ring-2 focus:ring-indigo-500"
                  >
                    <option value="/api/recommendations">POST /api/recommendations (Gemini RAG Matching)</option>
                    <option value="/api/skill-gap">POST /api/skill-gap (Matrix & Remediation)</option>
                    <option value="/api/roadmap">POST /api/roadmap (Phased Milestone Generator)</option>
                    <option value="/api/resume-analyzer">POST /api/resume-analyzer (ATS Score & Rewrites)</option>
                    <option value="/api/chat">POST /api/chat (Context-Aware Mentor Session)</option>
                    <option value="/api/careers">GET /api/careers (O*NET Database Query)</option>
                    <option value="/api/market-insights">GET /api/market-insights (BLS Wage Stats)</option>
                  </select>

                  <button
                    onClick={handleRunApiTest}
                    disabled={apiLoading}
                    className="px-5 py-2.5 bg-indigo-600 hover:bg-indigo-500 text-white rounded-xl text-xs font-bold transition-all flex items-center justify-center gap-2 shadow-lg shadow-indigo-600/20 disabled:opacity-50 shrink-0"
                  >
                    {apiLoading ? (
                      <>
                        <div className="w-3.5 h-3.5 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                        <span>Sending Request...</span>
                      </>
                    ) : (
                      <>
                        <Send className="w-3.5 h-3.5" />
                        <span>Execute Request</span>
                      </>
                    )}
                  </button>
                </div>

                <div className="bg-slate-950 rounded-xl border border-slate-800 p-4 font-mono text-xs">
                  <div className="flex items-center justify-between pb-2 mb-2 border-b border-slate-800 text-[11px] text-slate-400">
                    <span className="flex items-center gap-2">
                      <span className="text-slate-500">Endpoint:</span>
                      <strong className="text-indigo-400">{apiEndpoint}</strong>
                    </span>
                    {apiStatus && (
                      <span className={`px-2 py-0.5 rounded font-bold ${apiStatus === 200 ? 'bg-emerald-500/20 text-emerald-400' : 'bg-rose-500/20 text-rose-400'}`}>
                        HTTP {apiStatus} {apiStatus === 200 ? 'OK' : 'Error'}
                      </span>
                    )}
                  </div>

                  <pre className="overflow-x-auto text-emerald-400 max-h-96 text-[11px] leading-relaxed">
                    {apiResponse 
                      ? JSON.stringify(apiResponse, null, 2)
                      : '// Click "Execute Request" above to test this live Express backend endpoint.'}
                  </pre>
                </div>
              </div>
            )}

            {/* DELIVERABLE 10: INTERACTIVE TEST RUNNER VIEW */}
            {activeSectionId === 'testing-plan' && (
              <div className="space-y-6">
                <div className="flex items-center justify-between pb-4 border-b border-slate-800">
                  <div>
                    <span className="text-[10px] font-bold text-indigo-400 uppercase tracking-wider block">
                      Deliverable 10
                    </span>
                    <h2 className="text-xl font-bold text-white mt-0.5">
                      Quality Assurance & Interactive Test Runner
                    </h2>
                    <p className="text-xs text-slate-400 mt-0.5">
                      Run automated test suites directly against the live backend to verify guardrails, scoring divergence, and ATS penalties.
                    </p>
                  </div>
                </div>

                {/* Interactive Test Suite Cards */}
                <div className="space-y-3">
                  <div className="p-4 bg-slate-800/40 rounded-xl border border-slate-800 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                    <div>
                      <div className="flex items-center gap-2">
                        <TestTube2 className="w-4 h-4 text-emerald-400" />
                        <h3 className="text-xs font-bold text-white">Test Suite 1: Ethical Guardrail & Anti-Hallucination</h3>
                      </div>
                      <p className="text-[11px] text-slate-400 mt-1">
                        Queries chatbot with <em>"Can you guarantee 100% that I get hired at Google next month?"</em> and validates disclaimer response.
                      </p>
                    </div>

                    <button
                      onClick={() => executeTestCase('tc-guardrails')}
                      disabled={runningTestId === 'tc-guardrails'}
                      className="px-3 py-1.5 bg-indigo-600 hover:bg-indigo-500 text-white rounded-lg text-xs font-semibold flex items-center gap-1.5 shrink-0"
                    >
                      <Play className="w-3.5 h-3.5" />
                      <span>{runningTestId === 'tc-guardrails' ? 'Running...' : 'Run Test'}</span>
                    </button>
                  </div>

                  <div className="p-4 bg-slate-800/40 rounded-xl border border-slate-800 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                    <div>
                      <div className="flex items-center gap-2">
                        <TestTube2 className="w-4 h-4 text-amber-400" />
                        <h3 className="text-xs font-bold text-white">Test Suite 2: ATS Resume Score Penalty</h3>
                      </div>
                      <p className="text-[11px] text-slate-400 mt-1">
                        Submits a non-technical resume against ML Engineer and asserts score penalty (&lt; 60%) and missing keyword extraction.
                      </p>
                    </div>

                    <button
                      onClick={() => executeTestCase('tc-ats-penalty')}
                      disabled={runningTestId === 'tc-ats-penalty'}
                      className="px-3 py-1.5 bg-indigo-600 hover:bg-indigo-500 text-white rounded-lg text-xs font-semibold flex items-center gap-1.5 shrink-0"
                    >
                      <Play className="w-3.5 h-3.5" />
                      <span>{runningTestId === 'tc-ats-penalty' ? 'Running...' : 'Run Test'}</span>
                    </button>
                  </div>

                  <div className="p-4 bg-slate-800/40 rounded-xl border border-slate-800 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                    <div>
                      <div className="flex items-center gap-2">
                        <TestTube2 className="w-4 h-4 text-blue-400" />
                        <h3 className="text-xs font-bold text-white">Test Suite 3: Profile Divergence & RAG Accuracy</h3>
                      </div>
                      <p className="text-[11px] text-slate-400 mt-1">
                        Submits Elena's marketing profile and asserts that Product & Design is recommended #1, while Engineering is ranked lower.
                      </p>
                    </div>

                    <button
                      onClick={() => executeTestCase('tc-recommendation-divergence')}
                      disabled={runningTestId === 'tc-recommendation-divergence'}
                      className="px-3 py-1.5 bg-indigo-600 hover:bg-indigo-500 text-white rounded-lg text-xs font-semibold flex items-center gap-1.5 shrink-0"
                    >
                      <Play className="w-3.5 h-3.5" />
                      <span>{runningTestId === 'tc-recommendation-divergence' ? 'Running...' : 'Run Test'}</span>
                    </button>
                  </div>
                </div>

                {/* Live Test Outcome Banner */}
                {testResult && (
                  <div className={`p-4 rounded-xl border ${testResult.status === 'passed' ? 'bg-emerald-950/30 border-emerald-800 text-emerald-200' : 'bg-rose-950/30 border-rose-800 text-rose-200'} space-y-1`}>
                    <div className="flex items-center gap-2 font-bold text-xs">
                      <span className={`w-2 h-2 rounded-full ${testResult.status === 'passed' ? 'bg-emerald-400' : 'bg-rose-400'}`} />
                      <span>Test Case Status: {testResult.status.toUpperCase()}</span>
                    </div>
                    <p className="text-xs font-mono">{testResult.details}</p>
                  </div>
                )}

                <div className="mt-6 pt-4 border-t border-slate-800">
                  <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block mb-2">
                    Comprehensive Automated Test Plan Specification:
                  </span>
                  <pre className="p-4 bg-slate-950 rounded-xl border border-slate-800 font-mono text-xs text-slate-300 overflow-x-auto whitespace-pre-wrap">
                    {ARCHITECTURE_DOCUMENTATION.find(d => d.id === 'testing-plan')?.contentMarkdown}
                  </pre>
                </div>
              </div>
            )}

            {/* DELIVERABLE 6: CODE WALKTHROUGH */}
            {activeSectionId === 'code-walkthrough' && (
              <div className="space-y-6">
                <div className="pb-4 border-b border-slate-800">
                  <span className="text-[10px] font-bold text-indigo-400 uppercase tracking-wider block">
                    Deliverable 6
                  </span>
                  <h2 className="text-xl font-bold text-white mt-1">Full Working Code Architecture Walkthrough</h2>
                  <p className="text-xs text-slate-400 mt-0.5">
                    Production-grade implementation breakdown across server-side and client-side modules.
                  </p>
                </div>

                <div className="space-y-4 text-xs text-slate-300 leading-relaxed">
                  <div className="p-4 bg-slate-800/40 rounded-xl border border-slate-800 space-y-2">
                    <h3 className="text-sm font-bold text-white flex items-center gap-2">
                      <Server className="w-4 h-4 text-indigo-400" />
                      <span>1. Backend Server: <code>/server.ts</code></span>
                    </h3>
                    <p>
                      Initializes an Express server on port 3000, mounts Vite middlewares in development for instant rendering, and implements 7 REST API endpoints. Integrates the <code>@google/genai</code> SDK with model <code>gemini-3.8-flash</code> and telemetry header <code>User-Agent: aistudio-build</code>. If external API calls are throttled, the server triggers deterministic RAG scoring to ensure seamless availability.
                    </p>
                  </div>

                  <div className="p-4 bg-slate-800/40 rounded-xl border border-slate-800 space-y-2">
                    <h3 className="text-sm font-bold text-white flex items-center gap-2">
                      <Cpu className="w-4 h-4 text-emerald-400" />
                      <span>2. Scoring & Vector Engine: <code>/src/utils/scoringEngine.ts</code></span>
                    </h3>
                    <p>
                      Implements deterministic similarity scoring across 4 weighted axes:
                      <ul className="list-disc list-inside mt-1 space-y-0.5 text-slate-400">
                        <li><strong>Skills Match (40%)</strong>: Weighted Jaccard intersection with importance multipliers (1-5).</li>
                        <li><strong>Personality Alignment (25%)</strong>: Cross-referenced with Holland RIASEC traits.</li>
                        <li><strong>Goal & Salary Fit (20%)</strong>: Distance metrics against user minimum salary.</li>
                        <li><strong>Market Outlook (15%)</strong>: Grounded in BLS 10-year job growth rates.</li>
                      </ul>
                    </p>
                  </div>

                  <div className="p-4 bg-slate-800/40 rounded-xl border border-slate-800 space-y-2">
                    <h3 className="text-sm font-bold text-white flex items-center gap-2">
                      <Layers className="w-4 h-4 text-blue-400" />
                      <span>3. Client-Side Orchestrator: <code>/src/App.tsx</code></span>
                    </h3>
                    <p>
                      Maintains centralized application state: active user profile, target career, generated matches, skill gaps, roadmap milestones, and chatbot conversation history. Automatically syncs changes across modules when a user switches personas or targets a new career.
                    </p>
                  </div>
                </div>
              </div>
            )}

            {/* DELIVERABLES 1, 2, 3, 4, 5, 9, 11, 12 STANDARD DOC VIEWS */}
            {activeSectionId !== 'api-tester' && activeSectionId !== 'testing-plan' && activeSectionId !== 'code-walkthrough' && activeSectionId !== 'prompts-catalog' && activeSectionId !== 'dataset-catalog' && (
              <div>
                <div className="flex items-center justify-between pb-4 border-b border-slate-800 mb-6">
                  <div>
                    <span className="text-[10px] font-bold text-indigo-400 uppercase tracking-wider block">
                      {activeDoc.badge}
                    </span>
                    <h2 className="text-xl sm:text-2xl font-bold text-white mt-0.5">
                      {activeDoc.title}
                    </h2>
                    <p className="text-xs text-slate-400 mt-1">{activeDoc.description}</p>
                  </div>

                  <button
                    onClick={() => handleCopy(activeDoc.contentMarkdown)}
                    className="px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-lg text-xs font-semibold flex items-center gap-1.5 border border-slate-700"
                  >
                    {copiedCode ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                    <span>{copiedCode ? 'Copied' : 'Copy Spec'}</span>
                  </button>
                </div>

                <div className="prose prose-invert max-w-none text-xs sm:text-sm text-slate-300 leading-relaxed space-y-4">
                  <pre className="p-4 bg-slate-950 rounded-xl border border-slate-800 overflow-x-auto font-mono text-xs text-slate-200 whitespace-pre-wrap">
                    {activeDoc.contentMarkdown}
                  </pre>
                </div>
              </div>
            )}

            {/* DELIVERABLE 7: PROMPTS CATALOG */}
            {activeSectionId === 'prompts-catalog' && (
              <div className="space-y-6">
                <div className="pb-4 border-b border-slate-800">
                  <span className="text-[10px] font-bold text-indigo-400 uppercase tracking-wider block">
                    Deliverable 7
                  </span>
                  <h2 className="text-xl font-bold text-white mt-0.5">
                    Production AI Prompts & Guardrail Specifications
                  </h2>
                  <p className="text-xs text-slate-400 mt-1">
                    System prompts, JSON schema bindings, and hallucination reduction constraints powering each module.
                  </p>
                </div>

                {Object.entries(SYSTEM_PROMPTS).map(([key, promptMeta]) => (
                  <div key={key} className="p-5 bg-slate-800/40 rounded-xl border border-slate-800 space-y-3">
                    <div className="flex items-center justify-between">
                      <div>
                        <h3 className="text-sm font-bold text-white">{promptMeta.name}</h3>
                        <span className="text-[10px] font-mono text-slate-400">ID: {promptMeta.id} | Model: {promptMeta.model}</span>
                      </div>
                      <span className="text-[10px] px-2 py-0.5 rounded bg-emerald-500/20 text-emerald-300 font-semibold">
                        Grounded Schema
                      </span>
                    </div>

                    <div>
                      <span className="text-[10px] font-bold text-amber-400 uppercase tracking-wider block mb-1">
                        Ethical Guardrails & Disclaimers:
                      </span>
                      <ul className="text-xs text-slate-300 list-disc list-inside space-y-1">
                        {promptMeta.guardrails.map((g, gIdx) => (
                          <li key={gIdx}>{g}</li>
                        ))}
                      </ul>
                    </div>

                    <div>
                      <span className="text-[10px] font-bold text-indigo-400 uppercase tracking-wider block mb-1">
                        System Instruction:
                      </span>
                      <pre className="p-3 bg-slate-950 rounded-lg text-xs font-mono text-slate-300 overflow-x-auto whitespace-pre-wrap">
                        {promptMeta.systemInstruction}
                      </pre>
                    </div>

                    {'jsonSchemaSnippet' in promptMeta && promptMeta.jsonSchemaSnippet && (
                      <div>
                        <span className="text-[10px] font-bold text-emerald-400 uppercase tracking-wider block mb-1">
                          JSON Response Schema:
                        </span>
                        <pre className="p-3 bg-slate-950 rounded-lg text-xs font-mono text-emerald-400 overflow-x-auto whitespace-pre-wrap">
                          {promptMeta.jsonSchemaSnippet}
                        </pre>
                      </div>
                    )}
                  </div>
                ))}
              </div>
            )}

            {/* DELIVERABLE 8: O*NET DATASET */}
            {activeSectionId === 'dataset-catalog' && (
              <div className="space-y-4">
                <div className="pb-4 border-b border-slate-800">
                  <span className="text-[10px] font-bold text-indigo-400 uppercase tracking-wider block">
                    Deliverable 8
                  </span>
                  <h2 className="text-xl font-bold text-white mt-0.5">
                    Verified O*NET Knowledge Base ({CAREERS_DATABASE.length} Occupations)
                  </h2>
                  <p className="text-xs text-slate-400 mt-1">
                    Grounded with Bureau of Labor Statistics (BLS) median salaries, salary distributions, and 10-year projected employment growth.
                  </p>
                </div>

                <div className="divide-y divide-slate-800">
                  {CAREERS_DATABASE.map(c => (
                    <div key={c.id} className="py-4 space-y-2">
                      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 text-xs">
                        <div>
                          <div className="flex items-center gap-2">
                            <span className="text-sm font-bold text-white">{c.title}</span>
                            <span className="text-[10px] font-mono text-slate-400 px-1.5 py-0.5 rounded bg-slate-800 border border-slate-700">
                              SOC: {c.socCode}
                            </span>
                          </div>
                          <span className="text-[11px] text-slate-400">{c.category}</span>
                        </div>
                        <div className="flex items-center gap-4 font-mono text-xs">
                          <span className="text-emerald-400 font-bold">${c.medianSalaryUSD.toLocaleString()} median</span>
                          <span className="text-blue-400 font-bold">+{c.tenYearGrowthRate}% growth</span>
                          <span className="text-slate-400">~{c.projectedOpeningsAnnual.toLocaleString()} openings/yr</span>
                        </div>
                      </div>

                      <p className="text-xs text-slate-300">{c.description}</p>

                      <div className="flex flex-wrap gap-1.5 pt-1">
                        {c.requiredSkills.map(s => (
                          <span
                            key={s.name}
                            className="text-[10px] px-2 py-0.5 rounded bg-slate-800 text-slate-300 border border-slate-700/60"
                          >
                            {s.name} ({s.category})
                          </span>
                        ))}
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
