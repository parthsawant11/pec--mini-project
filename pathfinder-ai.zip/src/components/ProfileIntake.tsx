import React, { useState } from 'react';
import { UserProfile, EducationLevel, ExperienceLevel } from '../types/career';
import { CAREER_QUIZ_QUESTIONS } from '../data/quizQuestions';
import { PRESET_PERSONAS } from '../data/personasData';
import { 
  Sparkles, 
  GraduationCap, 
  BrainCircuit, 
  Sliders, 
  Briefcase, 
  Check, 
  Plus, 
  X, 
  ArrowRight,
  RotateCcw
} from 'lucide-react';

interface ProfileIntakeProps {
  profile: UserProfile;
  setProfile: React.Dispatch<React.SetStateAction<UserProfile>>;
  onGenerateMatches: () => void;
  isLoading: boolean;
}

const COMMON_SKILLS = [
  'Python', 'JavaScript / TypeScript', 'React / Next.js', 'SQL & PostgreSQL',
  'Git & Version Control', 'Data Structures & Algorithms', 'PyTorch / TensorFlow',
  'Docker & Kubernetes', 'Figma & Component Systems', 'Cloud Deployment (Docker, AWS/GCP)',
  'REST APIs & GraphQL', 'Product Discovery & User Research', 'Statistics & Probability',
  'Problem Solving & Critical Thinking', 'Business Stakeholder Communication',
  'SIEM & SOC Tools', 'Agile Team Collaboration'
];

const COMMON_INTERESTS = [
  'Machine Learning & AI', 'Full-Stack Web Systems', 'Cloud & DevOps Automation',
  'Cybersecurity & Threat Defense', 'Product Strategy & UX Design',
  'Big Data & Streaming Architectures', 'FinTech & Algorithmic Trading', 'Robotics & Hardware'
];

export const ProfileIntake: React.FC<ProfileIntakeProps> = ({
  profile,
  setProfile,
  onGenerateMatches,
  isLoading,
}) => {
  const [activeStep, setActiveStep] = useState<number>(1);
  const [customSkillInput, setCustomSkillInput] = useState('');

  const toggleSkill = (skill: string) => {
    setProfile(prev => {
      const exists = prev.skills.includes(skill);
      return {
        ...prev,
        skills: exists ? prev.skills.filter(s => s !== skill) : [...prev.skills, skill]
      };
    });
  };

  const addCustomSkill = (e: React.FormEvent) => {
    e.preventDefault();
    if (!customSkillInput.trim()) return;
    const trimmed = customSkillInput.trim();
    if (!profile.skills.includes(trimmed)) {
      setProfile(prev => ({ ...prev, skills: [...prev.skills, trimmed] }));
    }
    setCustomSkillInput('');
  };

  const removeSkill = (skill: string) => {
    setProfile(prev => ({ ...prev, skills: prev.skills.filter(s => s !== skill) }));
  };

  const toggleInterest = (interest: string) => {
    setProfile(prev => {
      const exists = prev.interests.includes(interest);
      return {
        ...prev,
        interests: exists ? prev.interests.filter(i => i !== interest) : [...prev.interests, interest]
      };
    });
  };

  const handleQuizAnswer = (questionId: string, optionId: string, traitWeights: Record<string, number>) => {
    setProfile(prev => {
      const updatedAnswers = { ...(prev.quizAnswers || {}), [questionId]: optionId };
      const updatedTraits = { ...(prev.personalityTraits || {}) };

      Object.entries(traitWeights).forEach(([key, val]) => {
        updatedTraits[key] = Math.min(100, (updatedTraits[key] || 50) + Math.round(val * 0.4));
      });

      return {
        ...prev,
        quizAnswers: updatedAnswers,
        personalityTraits: updatedTraits
      };
    });
  };

  const steps = [
    { num: 1, label: 'Education & Role', icon: GraduationCap },
    { num: 2, label: 'Skills & Passions', icon: BrainCircuit },
    { num: 3, label: 'Work Style Quiz', icon: Sliders },
    { num: 4, label: 'Goals & Constraints', icon: Briefcase },
  ];

  return (
    <div className="max-w-4xl mx-auto space-y-6">
      {/* Intro Header */}
      <div className="bg-gradient-to-r from-slate-900 via-indigo-950/60 to-slate-900 p-6 rounded-2xl border border-indigo-900/40 shadow-xl">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-indigo-500/20 text-indigo-300 text-xs font-semibold mb-2">
              <Sparkles className="w-3.5 h-3.5" />
              <span>Step 1 of 8: Comprehensive Intake</span>
            </div>
            <h1 className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight">
              AI Career Profile Intake & Discovery
            </h1>
            <p className="text-sm text-slate-300 mt-1 max-w-xl">
              Tell us about your background, skills, and work style. Our RAG engine evaluates your profile against 25+ verified O*NET occupational benchmarks.
            </p>
          </div>

          {/* Quick preset buttons */}
          <div className="bg-slate-800/80 p-3 rounded-xl border border-slate-700/60 shrink-0">
            <span className="text-xs font-medium text-slate-400 block mb-2">Load Pre-configured Persona:</span>
            <div className="flex flex-wrap gap-2">
              {PRESET_PERSONAS.map(p => (
                <button
                  key={p.id}
                  onClick={() => setProfile(p.profile)}
                  className="px-2.5 py-1 text-xs font-semibold rounded-lg bg-slate-700 hover:bg-indigo-600 text-slate-200 hover:text-white transition-all flex items-center gap-1"
                >
                  <span>{p.name.split(' ')[0]}</span>
                  <span className="text-[10px] text-slate-400 font-normal">({p.roleType.replace('_', ' ')})</span>
                </button>
              ))}
            </div>
          </div>
        </div>

        {/* Step Progress Pills */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 mt-6 pt-6 border-t border-slate-800">
          {steps.map(s => {
            const Icon = s.icon;
            const isCurrent = activeStep === s.num;
            const isDone = activeStep > s.num;
            return (
              <button
                key={s.num}
                onClick={() => setActiveStep(s.num)}
                className={`p-3 rounded-xl flex items-center space-x-3 text-left transition-all ${
                  isCurrent
                    ? 'bg-indigo-600/30 border border-indigo-500/60 text-white'
                    : isDone
                    ? 'bg-slate-800/60 border border-slate-700/40 text-emerald-400'
                    : 'bg-slate-800/30 border border-transparent text-slate-400 hover:text-slate-200'
                }`}
              >
                <div
                  className={`w-7 h-7 rounded-lg flex items-center justify-center text-xs font-bold ${
                    isCurrent ? 'bg-indigo-600 text-white' : isDone ? 'bg-emerald-600 text-white' : 'bg-slate-700 text-slate-300'
                  }`}
                >
                  {isDone ? <Check className="w-4 h-4" /> : s.num}
                </div>
                <div className="truncate">
                  <div className="text-xs font-semibold leading-tight">{s.label}</div>
                  <div className="text-[10px] text-slate-400">Step {s.num}</div>
                </div>
              </button>
            );
          })}
        </div>
      </div>

      {/* Main Step Container */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 sm:p-8 shadow-xl">
        {/* STEP 1: Education & Experience */}
        {activeStep === 1 && (
          <div className="space-y-6">
            <div className="border-b border-slate-800 pb-4">
              <h2 className="text-xl font-bold text-white flex items-center gap-2">
                <GraduationCap className="w-5 h-5 text-indigo-400" />
                <span>Education & Current Background</span>
              </h2>
              <p className="text-xs text-slate-400 mt-1">Grounds your educational level against O*NET degree requisites.</p>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
              <div>
                <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-2">
                  Full Name / Identifier
                </label>
                <input
                  type="text"
                  value={profile.fullName}
                  onChange={e => setProfile({ ...profile, fullName: e.target.value })}
                  placeholder="e.g. Alex Morgan"
                  className="w-full bg-slate-800 border border-slate-700 rounded-xl px-4 py-2.5 text-sm text-white focus:outline-none focus:ring-2 focus:ring-indigo-500"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-2">
                  Highest Degree / Educational Level
                </label>
                <select
                  value={profile.education.level}
                  onChange={e => setProfile({
                    ...profile,
                    education: { ...profile.education, level: e.target.value as EducationLevel }
                  })}
                  className="w-full bg-slate-800 border border-slate-700 rounded-xl px-4 py-2.5 text-sm text-white focus:outline-none focus:ring-2 focus:ring-indigo-500"
                >
                  <option value="High School">High School Diploma / GED</option>
                  <option value="Associate Degree">Associate Degree</option>
                  <option value="Bachelor's Degree">Bachelor's Degree (BS / BA)</option>
                  <option value="Master's Degree">Master's Degree (MS / MA / MBA)</option>
                  <option value="Doctorate / PhD">Doctorate / PhD</option>
                  <option value="Bootcamp / Self-Taught">Bootcamp / Self-Taught</option>
                </select>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-2">
                  Major / Field of Study
                </label>
                <input
                  type="text"
                  value={profile.education.field}
                  onChange={e => setProfile({
                    ...profile,
                    education: { ...profile.education, field: e.target.value }
                  })}
                  placeholder="e.g. Computer Science, Economics, Marketing"
                  className="w-full bg-slate-800 border border-slate-700 rounded-xl px-4 py-2.5 text-sm text-white focus:outline-none focus:ring-2 focus:ring-indigo-500"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-2">
                  Current Experience Tier
                </label>
                <select
                  value={profile.experienceLevel}
                  onChange={e => setProfile({ ...profile, experienceLevel: e.target.value as ExperienceLevel })}
                  className="w-full bg-slate-800 border border-slate-700 rounded-xl px-4 py-2.5 text-sm text-white focus:outline-none focus:ring-2 focus:ring-indigo-500"
                >
                  <option value="Entry-level (0-1 yrs)">Entry-level (0-1 yrs / Student / Graduate)</option>
                  <option value="Early Career (1-3 yrs)">Early Career (1-3 yrs experience)</option>
                  <option value="Mid-level (3-7 yrs)">Mid-level (3-7 yrs experience)</option>
                  <option value="Senior (7+ yrs)">Senior (7+ yrs experience)</option>
                </select>
              </div>

              <div className="sm:col-span-2">
                <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-2">
                  Current Job Title or Academic Status
                </label>
                <input
                  type="text"
                  value={profile.currentTitle || ''}
                  onChange={e => setProfile({ ...profile, currentTitle: e.target.value })}
                  placeholder="e.g. CS Student, Junior Frontend Developer, Retail Sales Lead"
                  className="w-full bg-slate-800 border border-slate-700 rounded-xl px-4 py-2.5 text-sm text-white focus:outline-none focus:ring-2 focus:ring-indigo-500"
                />
              </div>
            </div>
          </div>
        )}

        {/* STEP 2: Skills & Interests */}
        {activeStep === 2 && (
          <div className="space-y-6">
            <div className="border-b border-slate-800 pb-4">
              <h2 className="text-xl font-bold text-white flex items-center gap-2">
                <BrainCircuit className="w-5 h-5 text-indigo-400" />
                <span>Current Skills & Domain Interests</span>
              </h2>
              <p className="text-xs text-slate-400 mt-1">Select all tools and skills you currently understand or can demonstrate.</p>
            </div>

            {/* Currently Active Skills */}
            <div>
              <div className="flex items-center justify-between mb-2">
                <label className="text-xs font-semibold text-slate-300 uppercase tracking-wider">
                  Your Selected Skills ({profile.skills.length})
                </label>
                {profile.skills.length > 0 && (
                  <button
                    onClick={() => setProfile({ ...profile, skills: [] })}
                    className="text-xs text-rose-400 hover:text-rose-300 flex items-center gap-1"
                  >
                    <RotateCcw className="w-3 h-3" /> Clear All
                  </button>
                )}
              </div>
              <div className="flex flex-wrap gap-2 p-3 bg-slate-800/50 rounded-xl border border-slate-700/60 min-h-[56px]">
                {profile.skills.length === 0 ? (
                  <span className="text-xs text-slate-500 italic flex items-center">
                    No skills selected yet. Click any skill below or add custom skills.
                  </span>
                ) : (
                  profile.skills.map(skill => (
                    <span
                      key={skill}
                      className="inline-flex items-center gap-1.5 px-3 py-1 rounded-lg bg-indigo-600/30 border border-indigo-500/50 text-indigo-200 text-xs font-medium"
                    >
                      {skill}
                      <button
                        onClick={() => removeSkill(skill)}
                        className="hover:text-white hover:bg-indigo-600/50 rounded p-0.5"
                      >
                        <X className="w-3 h-3" />
                      </button>
                    </span>
                  ))
                )}
              </div>
            </div>

            {/* Custom Skill Input */}
            <form onSubmit={addCustomSkill} className="flex gap-2">
              <input
                type="text"
                value={customSkillInput}
                onChange={e => setCustomSkillInput(e.target.value)}
                placeholder="Type any other skill (e.g. Go, Kubernetes, Figma, Pandas) and press Enter"
                className="flex-1 bg-slate-800 border border-slate-700 rounded-xl px-4 py-2 text-xs text-white focus:outline-none focus:ring-2 focus:ring-indigo-500"
              />
              <button
                type="submit"
                className="px-4 py-2 bg-indigo-600 hover:bg-indigo-500 text-white rounded-xl text-xs font-semibold flex items-center gap-1 shadow-md"
              >
                <Plus className="w-4 h-4" /> Add Skill
              </button>
            </form>

            {/* Popular Quick-Select Skills */}
            <div>
              <label className="block text-xs font-semibold text-slate-400 uppercase tracking-wider mb-2">
                Recommended Technical & Workplace Competencies
              </label>
              <div className="flex flex-wrap gap-2">
                {COMMON_SKILLS.map(skill => {
                  const isSelected = profile.skills.includes(skill);
                  return (
                    <button
                      key={skill}
                      type="button"
                      onClick={() => toggleSkill(skill)}
                      className={`px-3 py-1.5 rounded-lg text-xs font-medium transition-all flex items-center gap-1.5 ${
                        isSelected
                          ? 'bg-indigo-600 text-white shadow-sm'
                          : 'bg-slate-800 hover:bg-slate-750 text-slate-300 border border-slate-700/60'
                      }`}
                    >
                      {isSelected ? <Check className="w-3 h-3" /> : <Plus className="w-3 h-3 text-slate-500" />}
                      {skill}
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Domain Interests */}
            <div className="pt-4 border-t border-slate-800">
              <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-2">
                Passions & Areas of High Interest
              </label>
              <div className="flex flex-wrap gap-2">
                {COMMON_INTERESTS.map(interest => {
                  const isSelected = profile.interests.includes(interest);
                  return (
                    <button
                      key={interest}
                      type="button"
                      onClick={() => toggleInterest(interest)}
                      className={`px-3 py-1.5 rounded-lg text-xs font-medium transition-all ${
                        isSelected
                          ? 'bg-emerald-600 text-white font-semibold shadow-sm'
                          : 'bg-slate-800 hover:bg-slate-750 text-slate-300 border border-slate-700/60'
                      }`}
                    >
                      {interest}
                    </button>
                  );
                })}
              </div>
            </div>
          </div>
        )}

        {/* STEP 3: Personality & Work Style Quiz */}
        {activeStep === 3 && (
          <div className="space-y-6">
            <div className="border-b border-slate-800 pb-4">
              <h2 className="text-xl font-bold text-white flex items-center gap-2">
                <Sliders className="w-5 h-5 text-indigo-400" />
                <span>Work Personality & RIASEC Trait Quiz</span>
              </h2>
              <p className="text-xs text-slate-400 mt-1">
                4 calibrated questions assessing your cognitive drive, team dynamics, and problem-solving instinct.
              </p>
            </div>

            <div className="space-y-6">
              {CAREER_QUIZ_QUESTIONS.map((q, idx) => {
                const currentAnswer = profile.quizAnswers?.[q.id];
                return (
                  <div key={q.id} className="bg-slate-800/40 p-4 sm:p-5 rounded-xl border border-slate-700/50">
                    <div className="flex items-start justify-between gap-2 mb-3">
                      <div>
                        <span className="text-[10px] font-bold uppercase tracking-wider text-indigo-400 px-2 py-0.5 rounded bg-indigo-500/10 border border-indigo-500/20 mr-2">
                          Question {idx + 1}
                        </span>
                        <h3 className="text-sm sm:text-base font-semibold text-white mt-1">{q.question}</h3>
                        <p className="text-xs text-slate-400 mt-0.5">{q.subtitle}</p>
                      </div>
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 mt-3">
                      {q.options.map(opt => {
                        const isChosen = currentAnswer === opt.id;
                        return (
                          <button
                            key={opt.id}
                            type="button"
                            onClick={() => handleQuizAnswer(q.id, opt.id, opt.traitWeights)}
                            className={`p-3.5 rounded-xl text-left transition-all border ${
                              isChosen
                                ? 'bg-indigo-600/20 border-indigo-500 text-white shadow-md'
                                : 'bg-slate-800/80 hover:bg-slate-800 border-slate-700/60 text-slate-300'
                            }`}
                          >
                            <div className="flex items-center justify-between mb-1">
                              <span className="text-xs font-bold text-white">{opt.label}</span>
                              <div
                                className={`w-4 h-4 rounded-full border flex items-center justify-center ${
                                  isChosen ? 'border-indigo-400 bg-indigo-500' : 'border-slate-600'
                                }`}
                              >
                                {isChosen && <Check className="w-3 h-3 text-white" />}
                              </div>
                            </div>
                            <p className="text-[11px] text-slate-400 leading-relaxed">{opt.description}</p>
                          </button>
                        );
                      })}
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        )}

        {/* STEP 4: Goals & Constraints */}
        {activeStep === 4 && (
          <div className="space-y-6">
            <div className="border-b border-slate-800 pb-4">
              <h2 className="text-xl font-bold text-white flex items-center gap-2">
                <Briefcase className="w-5 h-5 text-indigo-400" />
                <span>Goals, Timeline & Practical Constraints</span>
              </h2>
              <p className="text-xs text-slate-400 mt-1">Guarantees that recommended roadmaps fit your actual budget and weekly calendar.</p>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
              <div>
                <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-2">
                  Minimum Desired Salary (Annual USD)
                </label>
                <div className="relative">
                  <span className="absolute left-3 top-2.5 text-slate-400 text-sm">$</span>
                  <input
                    type="number"
                    step={5000}
                    value={profile.goals.desiredSalaryMin}
                    onChange={e => setProfile({
                      ...profile,
                      goals: { ...profile.goals, desiredSalaryMin: parseInt(e.target.value) || 0 }
                    })}
                    className="w-full bg-slate-800 border border-slate-700 rounded-xl pl-8 pr-4 py-2.5 text-sm text-white focus:outline-none focus:ring-2 focus:ring-indigo-500 font-mono"
                  />
                </div>
                <span className="text-[10px] text-slate-500 mt-1 block">O*NET median salaries will be evaluated against this threshold.</span>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-2">
                  Target Timeline to Upskill
                </label>
                <div className="grid grid-cols-3 gap-2">
                  {[3, 6, 12].map(months => (
                    <button
                      key={months}
                      type="button"
                      onClick={() => setProfile({
                        ...profile,
                        goals: { ...profile.goals, timelineMonths: months as 3 | 6 | 12 }
                      })}
                      className={`py-2.5 rounded-xl text-xs font-bold transition-all border ${
                        profile.goals.timelineMonths === months
                          ? 'bg-indigo-600 text-white border-indigo-500 shadow-md'
                          : 'bg-slate-800 text-slate-300 border-slate-700 hover:bg-slate-750'
                      }`}
                    >
                      {months} Months
                    </button>
                  ))}
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-2">
                  Primary Career Motivator
                </label>
                <select
                  value={profile.goals.primaryMotivator}
                  onChange={e => setProfile({
                    ...profile,
                    goals: { ...profile.goals, primaryMotivator: e.target.value as any }
                  })}
                  className="w-full bg-slate-800 border border-slate-700 rounded-xl px-4 py-2.5 text-sm text-white focus:outline-none focus:ring-2 focus:ring-indigo-500"
                >
                  <option value="Higher Salary">Higher Compensation / Financial Growth</option>
                  <option value="Tech Innovation">Tech Innovation & Frontier Mastery</option>
                  <option value="Work-Life Balance">Work-Life Balance & Sustainable Pace</option>
                  <option value="Remote Flexibility">Remote Flexibility & Nomad Autonomy</option>
                  <option value="Impact & Purpose">Social Impact & Purpose</option>
                </select>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-2">
                  Preferred Work Modality
                </label>
                <select
                  value={profile.constraints.preferredWorkType}
                  onChange={e => setProfile({
                    ...profile,
                    constraints: { ...profile.constraints, preferredWorkType: e.target.value as any }
                  })}
                  className="w-full bg-slate-800 border border-slate-700 rounded-xl px-4 py-2.5 text-sm text-white focus:outline-none focus:ring-2 focus:ring-indigo-500"
                >
                  <option value="Remote">Remote First (Work from Anywhere)</option>
                  <option value="Hybrid">Hybrid (1-3 days in office)</option>
                  <option value="On-site">On-site (Colocated team)</option>
                  <option value="Any">Flexible / Any</option>
                </select>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-2">
                  Study Hours Available Per Week: <span className="text-indigo-400 font-bold">{profile.constraints.hoursPerWeekAvailable} hrs</span>
                </label>
                <input
                  type="range"
                  min={5}
                  max={40}
                  step={1}
                  value={profile.constraints.hoursPerWeekAvailable}
                  onChange={e => setProfile({
                    ...profile,
                    constraints: { ...profile.constraints, hoursPerWeekAvailable: parseInt(e.target.value) }
                  })}
                  className="w-full accent-indigo-500 cursor-pointer"
                />
                <div className="flex justify-between text-[10px] text-slate-500">
                  <span>5 hrs (Casual)</span>
                  <span>15 hrs (Paced)</span>
                  <span>40 hrs (Full-time)</span>
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-2">
                  Total Learning / Cert Budget (USD)
                </label>
                <div className="relative">
                  <span className="absolute left-3 top-2.5 text-slate-400 text-sm">$</span>
                  <input
                    type="number"
                    step={100}
                    value={profile.constraints.learningBudgetUSD}
                    onChange={e => setProfile({
                      ...profile,
                      constraints: { ...profile.constraints, learningBudgetUSD: parseInt(e.target.value) || 0 }
                    })}
                    className="w-full bg-slate-800 border border-slate-700 rounded-xl pl-8 pr-4 py-2.5 text-sm text-white focus:outline-none focus:ring-2 focus:ring-indigo-500 font-mono"
                  />
                </div>
              </div>
            </div>
          </div>
        )}

        {/* Footer Navigation Buttons */}
        <div className="flex items-center justify-between mt-8 pt-6 border-t border-slate-800">
          {activeStep > 1 ? (
            <button
              onClick={() => setActiveStep(prev => prev - 1)}
              className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-xl text-xs font-semibold transition-all"
            >
              Back to Step {activeStep - 1}
            </button>
          ) : <div />}

          {activeStep < 4 ? (
            <button
              onClick={() => setActiveStep(prev => prev + 1)}
              className="px-5 py-2.5 bg-indigo-600 hover:bg-indigo-500 text-white rounded-xl text-xs font-bold transition-all flex items-center gap-2 shadow-lg shadow-indigo-600/20"
            >
              <span>Next: {steps[activeStep].label}</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          ) : (
            <button
              onClick={onGenerateMatches}
              disabled={isLoading}
              className="px-6 py-3 bg-gradient-to-r from-indigo-600 via-blue-600 to-emerald-500 hover:opacity-95 text-white rounded-xl text-sm font-bold transition-all flex items-center gap-2 shadow-xl shadow-indigo-600/30 disabled:opacity-50"
            >
              {isLoading ? (
                <>
                  <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                  <span>Evaluating O*NET RAG Matches...</span>
                </>
              ) : (
                <>
                  <Sparkles className="w-4 h-4 text-emerald-300" />
                  <span>Generate AI Career Recommendations</span>
                </>
              )}
            </button>
          )}
        </div>
      </div>
    </div>
  );
};
