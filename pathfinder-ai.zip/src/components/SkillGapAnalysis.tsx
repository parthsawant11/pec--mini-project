import React from 'react';
import { Career, CareerSkillGapAnalysis } from '../types/career';
import { 
  CheckCircle2, 
  AlertCircle, 
  Clock, 
  ExternalLink, 
  ArrowRight,
  BookOpen,
  Code2,
  Zap,
  Target
} from 'lucide-react';

interface SkillGapAnalysisProps {
  career: Career;
  gapAnalysis: CareerSkillGapAnalysis;
  onNavigateToTab: (tab: string) => void;
  isLoading: boolean;
}

export const SkillGapAnalysis: React.FC<SkillGapAnalysisProps> = ({
  career,
  gapAnalysis,
  onNavigateToTab,
  isLoading,
}) => {
  return (
    <div className="space-y-6 max-w-6xl mx-auto">
      {/* Target Career Header */}
      <div className="bg-gradient-to-r from-slate-900 via-indigo-950/70 to-slate-900 p-6 rounded-2xl border border-indigo-900/40 shadow-xl">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2 mb-2">
              <span className="text-xs px-2.5 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 font-bold border border-emerald-500/30">
                Active Target Career
              </span>
              <span className="text-xs text-slate-400 font-mono">SOC: {career.socCode}</span>
            </div>
            <h1 className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight">
              Skill-Gap Matrix: {career.title}
            </h1>
            <p className="text-xs sm:text-sm text-slate-300 mt-1 max-w-2xl">
              Comparative competency evaluation mapping your current profile against required industry qualifications.
            </p>
          </div>

          <div className="flex items-center gap-3 shrink-0">
            <button
              onClick={() => onNavigateToTab('recommendations')}
              className="px-3.5 py-2 rounded-xl text-xs font-semibold bg-slate-800 hover:bg-slate-700 text-slate-300 border border-slate-700 transition-all"
            >
              Switch Career
            </button>
            <button
              onClick={() => onNavigateToTab('roadmap')}
              className="px-4 py-2 bg-gradient-to-r from-indigo-600 to-emerald-500 hover:opacity-95 text-white rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 shadow-lg shadow-indigo-600/20"
            >
              <span>Build Phased Roadmap</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>

        {/* Readiness Meter & Stat Cards */}
        <div className="grid grid-cols-1 sm:grid-cols-4 gap-4 mt-6 pt-6 border-t border-slate-800">
          <div className="bg-slate-800/60 p-4 rounded-xl border border-slate-700/60 flex items-center justify-between">
            <div>
              <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400 block">
                Overall Readiness
              </span>
              <span className="text-2xl font-black text-white mt-1 block">
                {gapAnalysis.overallReadinessScore}%
              </span>
              <span className="text-[10px] text-slate-400">
                {gapAnalysis.overallReadinessScore >= 70 ? 'Strong Baseline' : 'Growth Plan Needed'}
              </span>
            </div>
            <div className="w-12 h-12 rounded-full border-4 border-slate-700 flex items-center justify-center relative">
              <div 
                className="w-12 h-12 rounded-full border-4 border-emerald-500 absolute -top-1 -left-1 border-t-transparent animate-spin-slow"
                style={{ clipPath: 'polygon(0 0, 100% 0, 100% 100%, 0 100%)' }}
              />
              <Target className="w-5 h-5 text-emerald-400" />
            </div>
          </div>

          <div className="bg-emerald-950/30 p-4 rounded-xl border border-emerald-900/40">
            <span className="text-[10px] font-bold uppercase tracking-wider text-emerald-400 block">
              Acquired Competencies
            </span>
            <span className="text-2xl font-black text-emerald-300 mt-1 block">
              {gapAnalysis.readySkillsCount} Skills
            </span>
            <span className="text-[10px] text-emerald-400/80">Immediately verified</span>
          </div>

          <div className="bg-amber-950/30 p-4 rounded-xl border border-amber-900/40">
            <span className="text-[10px] font-bold uppercase tracking-wider text-amber-400 block">
              Transferable / Partial
            </span>
            <span className="text-2xl font-black text-amber-300 mt-1 block">
              {gapAnalysis.partialSkillsCount} Skills
            </span>
            <span className="text-[10px] text-amber-400/80">Quick to upgrade</span>
          </div>

          <div className="bg-rose-950/30 p-4 rounded-xl border border-rose-900/40">
            <span className="text-[10px] font-bold uppercase tracking-wider text-rose-400 block">
              High-Priority Gaps
            </span>
            <span className="text-2xl font-black text-rose-300 mt-1 block">
              {gapAnalysis.missingSkillsCount} Skills
            </span>
            <span className="text-[10px] text-rose-400/80">Primary roadmap focus</span>
          </div>
        </div>
      </div>

      {/* AI Remediation Strategic Advice Box */}
      <div className="bg-slate-900 border border-indigo-500/30 p-5 rounded-2xl shadow-lg flex items-start gap-3">
        <div className="w-8 h-8 rounded-lg bg-indigo-500/20 text-indigo-400 flex items-center justify-center shrink-0 mt-0.5">
          <Zap className="w-4 h-4" />
        </div>
        <div>
          <h3 className="text-xs font-bold text-indigo-300 uppercase tracking-wider mb-1">
            AI Remediation Directive
          </h3>
          <p className="text-xs sm:text-sm text-slate-300 leading-relaxed">
            {gapAnalysis.personalizedAdvice}
          </p>
        </div>
      </div>

      {/* Competency Gap Breakdown Matrix */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl overflow-hidden shadow-xl">
        <div className="p-4 sm:p-5 border-b border-slate-800 flex items-center justify-between">
          <div>
            <h2 className="text-base font-bold text-white">Competency Matrix & Remediation Catalog</h2>
            <p className="text-xs text-slate-400 mt-0.5">Categorized by urgency and estimated hours to master.</p>
          </div>
          <span className="text-xs text-slate-400">Total Skills: {gapAnalysis.gaps.length}</span>
        </div>

        <div className="divide-y divide-slate-800">
          {gapAnalysis.gaps.map((item, idx) => {
            const isAcquired = item.status === 'acquired';
            const isPartial = item.status === 'partial';

            return (
              <div key={idx} className="p-4 sm:p-5 hover:bg-slate-800/40 transition-colors">
                <div className="flex flex-col md:flex-row md:items-center justify-between gap-3">
                  <div className="flex items-start gap-3">
                    <div className="mt-1">
                      {isAcquired ? (
                        <div className="w-6 h-6 rounded-full bg-emerald-500/20 text-emerald-400 flex items-center justify-center">
                          <CheckCircle2 className="w-4 h-4" />
                        </div>
                      ) : isPartial ? (
                        <div className="w-6 h-6 rounded-full bg-amber-500/20 text-amber-400 flex items-center justify-center">
                          <AlertCircle className="w-4 h-4" />
                        </div>
                      ) : (
                        <div className="w-6 h-6 rounded-full bg-rose-500/20 text-rose-400 flex items-center justify-center">
                          <AlertCircle className="w-4 h-4" />
                        </div>
                      )}
                    </div>

                    <div>
                      <div className="flex items-center gap-2">
                        <span className="text-sm font-bold text-white">{item.skill}</span>
                        <span className="text-[10px] px-2 py-0.5 rounded bg-slate-800 text-slate-400 border border-slate-700">
                          {item.category}
                        </span>
                      </div>
                      <div className="flex items-center gap-3 text-xs text-slate-400 mt-1">
                        <span>
                          Status:{' '}
                          <strong className={isAcquired ? 'text-emerald-400' : isPartial ? 'text-amber-400' : 'text-rose-400'}>
                            {isAcquired ? 'Proficient / Acquired' : isPartial ? 'Familiar / Transferable' : 'Skill Missing'}
                          </strong>
                        </span>
                        <span>•</span>
                        <span>
                          Priority:{' '}
                          <strong className={item.priority === 'High' ? 'text-rose-400' : 'text-slate-300'}>
                            {item.priority}
                          </strong>
                        </span>
                        {!isAcquired && (
                          <>
                            <span>•</span>
                            <span className="flex items-center gap-1 text-slate-300">
                              <Clock className="w-3.5 h-3.5 text-indigo-400" /> ~{item.estimatedHoursToLearn} hrs study
                            </span>
                          </>
                        )}
                      </div>
                    </div>
                  </div>

                  {/* Recommended Learning Resources */}
                  {!isAcquired && (
                    <div className="flex flex-wrap items-center gap-2">
                      {item.recommendedResources.map((res, rIdx) => (
                        <div
                          key={rIdx}
                          className="px-3 py-1.5 rounded-lg bg-slate-800/80 border border-slate-700 text-xs text-slate-300 flex items-center gap-1.5"
                        >
                          {res.type === 'Course' ? (
                            <BookOpen className="w-3.5 h-3.5 text-indigo-400" />
                          ) : (
                            <Code2 className="w-3.5 h-3.5 text-emerald-400" />
                          )}
                          <span className="font-medium text-white">{res.title}</span>
                          <span className="text-[10px] text-slate-500">({res.platform})</span>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};
