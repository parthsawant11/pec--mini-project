import React, { useState, useRef, useEffect } from 'react';
import { UserProfile, Career, ChatMessage } from '../types/career';
import { 
  Send, 
  Sparkles, 
  User, 
  Bot, 
  HelpCircle, 
  ShieldAlert, 
  RotateCcw,
  Compass
} from 'lucide-react';

interface CareerChatbotProps {
  profile: UserProfile;
  career: Career;
  messages: ChatMessage[];
  onSendMessage: (text: string) => void;
  isLoading: boolean;
  onClearChat: () => void;
}

const STARTER_PROMPTS = [
  'How do I crack technical interviews for this career?',
  'What portfolio project would prove senior-level competence?',
  'Is my target salary realistic given my timeline and location?',
  'What is the real 10-year automation risk for this role?',
  'How can I explain my non-traditional background to recruiters?'
];

function formatInline(text: string): React.ReactNode {
  // Split on bold **text** or inline `code`
  const parts = text.split(/(\*\*[^*]+\*\*|`[^`]+`)/g);
  return parts.map((part, idx) => {
    if (part.startsWith('**') && part.endsWith('**')) {
      return <strong key={idx} className="font-bold text-white">{part.slice(2, -2)}</strong>;
    }
    if (part.startsWith('`') && part.endsWith('`')) {
      return <code key={idx} className="px-1.5 py-0.5 rounded bg-slate-900 border border-slate-700 font-mono text-[11px] text-indigo-300">{part.slice(1, -1)}</code>;
    }
    return part;
  });
}

export const CareerChatbot: React.FC<CareerChatbotProps> = ({
  profile,
  career,
  messages,
  onSendMessage,
  isLoading,
  onClearChat,
}) => {
  const [inputText, setInputText] = useState('');
  const chatEndRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    chatEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages, isLoading]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!inputText.trim() || isLoading) return;
    onSendMessage(inputText.trim());
    setInputText('');
  };

  const handlePromptClick = (prompt: string) => {
    onSendMessage(prompt);
  };

  return (
    <div className="max-w-4xl mx-auto space-y-4">
      {/* Context Badge Header */}
      <div className="bg-gradient-to-r from-slate-900 via-indigo-950/70 to-slate-900 p-5 rounded-2xl border border-indigo-900/40 shadow-xl flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-indigo-600 to-blue-500 flex items-center justify-center text-white shadow-md">
            <Bot className="w-5 h-5" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h1 className="text-lg font-bold text-white">ForgeBot AI Career Mentor</h1>
              <span className="text-[10px] font-bold uppercase tracking-wider px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-500/30">
                Context-Aware Memory Active
              </span>
            </div>
            <p className="text-xs text-slate-300">
              Personalized guidance for <strong className="text-white">{profile.fullName}</strong> pursuing <strong className="text-indigo-300">{career.title}</strong>
            </p>
          </div>
        </div>

        <button
          onClick={onClearChat}
          className="px-3 py-1.5 rounded-lg text-xs text-slate-400 hover:text-white bg-slate-800 hover:bg-slate-700 border border-slate-700 transition-all flex items-center gap-1"
        >
          <RotateCcw className="w-3 h-3" /> Reset Chat
        </button>
      </div>

      {/* Main Chat Box */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl shadow-xl flex flex-col h-[520px] overflow-hidden">
        {/* Messages Stream */}
        <div className="flex-1 overflow-y-auto p-4 sm:p-6 space-y-4">
          {messages.map(msg => {
            const isUser = msg.sender === 'user';
            return (
              <div
                key={msg.id}
                className={`flex gap-3 ${isUser ? 'justify-end' : 'justify-start'}`}
              >
                {!isUser && (
                  <div className="w-8 h-8 rounded-lg bg-indigo-600/30 border border-indigo-500/40 text-indigo-300 flex items-center justify-center shrink-0 mt-1">
                    <Compass className="w-4 h-4" />
                  </div>
                )}

                <div
                  className={`max-w-[85%] rounded-2xl px-4 py-3 text-xs leading-relaxed ${
                    isUser
                      ? 'bg-indigo-600 text-white rounded-br-none shadow-md'
                      : 'bg-slate-800/90 border border-slate-700/70 text-slate-200 rounded-bl-none shadow-md'
                  }`}
                >
                  <div className="space-y-2">
                    {msg.content.split('\n\n').map((paragraph, pIdx) => {
                      if (paragraph.startsWith('### ') || paragraph.startsWith('## ')) {
                        const headingText = paragraph.replace(/^#+\s*/, '');
                        return (
                          <h4 key={pIdx} className="font-bold text-white text-xs mt-2 mb-1 border-b border-slate-700/50 pb-1">
                            {headingText}
                          </h4>
                        );
                      }
                      if (paragraph.startsWith('* ') || paragraph.startsWith('- ')) {
                        const items = paragraph.split('\n').filter(Boolean);
                        return (
                          <ul key={pIdx} className="space-y-1 my-1 pl-3 list-disc marker:text-indigo-400">
                            {items.map((it, iIdx) => {
                              const cleanItem = it.replace(/^[\*\-]\s*/, '');
                              return (
                                <li key={iIdx} className="text-slate-300">
                                  {formatInline(cleanItem)}
                                </li>
                              );
                            })}
                          </ul>
                        );
                      }
                      return (
                        <p key={pIdx} className="leading-relaxed">
                          {formatInline(paragraph)}
                        </p>
                      );
                    })}
                  </div>
                  <div
                    className={`text-[9px] mt-2 flex items-center justify-between ${
                      isUser ? 'text-indigo-200' : 'text-slate-500'
                    }`}
                  >
                    {!isUser && (
                      <span className="text-[9px] text-emerald-400 flex items-center gap-1 font-mono">
                        <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
                        Gemini 3.1 Flash Lite
                      </span>
                    )}
                    <span className="ml-auto">{msg.timestamp}</span>
                  </div>
                </div>

                {isUser && (
                  <div className="w-8 h-8 rounded-lg bg-slate-700 text-slate-300 flex items-center justify-center shrink-0 mt-1 text-xs font-bold">
                    <User className="w-4 h-4" />
                  </div>
                )}
              </div>
            );
          })}

          {isLoading && (
            <div className="flex gap-3 justify-start">
              <div className="w-8 h-8 rounded-lg bg-indigo-600/30 border border-indigo-500/40 text-indigo-300 flex items-center justify-center shrink-0 mt-1">
                <Sparkles className="w-4 h-4 animate-spin" />
              </div>
              <div className="bg-slate-800/80 border border-slate-700/60 rounded-2xl px-4 py-3 text-xs text-slate-400 rounded-bl-none flex items-center gap-2">
                <div className="w-2 h-2 rounded-full bg-indigo-400 animate-pulse" />
                <div className="w-2 h-2 rounded-full bg-indigo-400 animate-pulse delay-75" />
                <div className="w-2 h-2 rounded-full bg-indigo-400 animate-pulse delay-150" />
                <span>ForgeBot is synthesizing grounded career advice...</span>
              </div>
            </div>
          )}

          <div ref={chatEndRef} />
        </div>

        {/* Starter Prompts Carousel */}
        <div className="px-4 py-2 border-t border-slate-800/80 bg-slate-900/60 overflow-x-auto scrollbar-none flex gap-2">
          {STARTER_PROMPTS.map((p, idx) => (
            <button
              key={idx}
              onClick={() => handlePromptClick(p)}
              disabled={isLoading}
              className="text-[11px] px-3 py-1.5 rounded-full bg-slate-800 hover:bg-indigo-600 hover:text-white text-slate-300 border border-slate-700/60 whitespace-nowrap transition-all shrink-0"
            >
              {p}
            </button>
          ))}
        </div>

        {/* Chat Input Bar */}
        <form onSubmit={handleSubmit} className="p-3 sm:p-4 border-t border-slate-800 bg-slate-900 flex gap-2">
          <input
            type="text"
            value={inputText}
            onChange={e => setInputText(e.target.value)}
            placeholder={`Ask ForgeBot anything about ${career.title}, interview prep, or your roadmap...`}
            disabled={isLoading}
            className="flex-1 bg-slate-800 border border-slate-700 rounded-xl px-4 py-2.5 text-xs text-white placeholder-slate-500 focus:outline-none focus:ring-2 focus:ring-indigo-500"
          />
          <button
            type="submit"
            disabled={isLoading || !inputText.trim()}
            className="px-5 py-2.5 bg-indigo-600 hover:bg-indigo-500 text-white rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 shadow-md shadow-indigo-600/20 disabled:opacity-50"
          >
            <Send className="w-4 h-4" />
            <span className="hidden sm:inline">Send</span>
          </button>
        </form>
      </div>

      {/* Guardrail Disclaimer */}
      <div className="text-[11px] text-slate-500 flex items-center justify-center gap-1.5 text-center">
        <ShieldAlert className="w-3.5 h-3.5 text-amber-500 shrink-0" />
        <span>
          AI responses are grounded in O*NET occupational statistics and do not constitute legal, financial, or guaranteed hiring commitments.
        </span>
      </div>
    </div>
  );
};
