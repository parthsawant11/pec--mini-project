export type EducationLevel = 
  | 'High School'
  | 'Associate Degree'
  | "Bachelor's Degree"
  | "Master's Degree"
  | 'Doctorate / PhD'
  | 'Bootcamp / Self-Taught';

export type ExperienceLevel = 'Entry-level (0-1 yrs)' | 'Early Career (1-3 yrs)' | 'Mid-level (3-7 yrs)' | 'Senior (7+ yrs)';

export interface QuizQuestion {
  id: string;
  category: 'Realistic' | 'Investigative' | 'Artistic' | 'Social' | 'Enterprising' | 'Conventional';
  question: string;
  options: {
    label: string;
    scoreKey: string;
    weight: number;
  }[];
}

export interface UserProfile {
  id: string;
  fullName: string;
  personaType?: 'student' | 'job_seeker' | 'career_switcher' | 'custom';
  education: {
    level: EducationLevel;
    field: string;
    institution?: string;
    graduationYear?: number;
  };
  experienceLevel: ExperienceLevel;
  currentTitle?: string;
  skills: string[];
  interests: string[];
  personalityTraits: Record<string, number>; // e.g. analytical: 85, creative: 60, social: 40
  quizAnswers?: Record<string, string>;
  goals: {
    targetRoleCategory?: string;
    desiredSalaryMin: number;
    timelineMonths: 3 | 6 | 12;
    primaryMotivator: 'Higher Salary' | 'Work-Life Balance' | 'Impact & Purpose' | 'Remote Flexibility' | 'Tech Innovation';
  };
  constraints: {
    preferredWorkType: 'Remote' | 'Hybrid' | 'On-site' | 'Any';
    learningBudgetUSD: number;
    hoursPerWeekAvailable: number;
    location: string;
  };
}

export interface Career {
  id: string;
  socCode: string; // O*NET SOC code e.g. 15-1252.00
  title: string;
  category: 'Engineering & Tech' | 'Data & AI' | 'Product & Design' | 'Cybersecurity' | 'Cloud & DevOps' | 'Healthcare Tech' | 'Business & Finance Tech';
  description: string;
  medianSalaryUSD: number;
  salaryRange: {
    p10: number;
    p50: number;
    p90: number;
  };
  tenYearGrowthRate: number; // percentage e.g. 26%
  projectedOpeningsAnnual: number;
  automationRisk: 'Low' | 'Moderate' | 'High';
  remoteFriendliness: 'High' | 'Medium' | 'Low';
  educationTypical: EducationLevel;
  requiredSkills: {
    name: string;
    category: 'Core Technical' | 'Specialized Technical' | 'Tooling' | 'Soft Skills';
    importance: number; // 1 - 5
  }[];
  responsibilities: string[];
  topCertifications: string[];
  sampleDayInTheLife: string;
  benchmarkCompanies: string[];
}

export interface CareerMatch {
  careerId: string;
  career: Career;
  matchScore: number; // 0 - 100
  scoreBreakdown: {
    skillsMatch: number;
    personalityMatch: number;
    goalAlignment: number;
    marketOpportunity: number;
  };
  reasoning: string;
  keyStrengths: string[];
  mainChallenges: string[];
  recommendedTimelineMonths: number;
}

export interface SkillGapItem {
  skill: string;
  category: string;
  status: 'acquired' | 'partial' | 'missing';
  userProficiency?: 'Proficient' | 'Familiar' | 'None';
  priority: 'High' | 'Medium' | 'Low';
  estimatedHoursToLearn: number;
  recommendedResources: {
    type: 'Course' | 'Book' | 'Project' | 'Certification';
    title: string;
    platform: string;
    isFree: boolean;
  }[];
}

export interface CareerSkillGapAnalysis {
  careerId: string;
  careerTitle: string;
  overallReadinessScore: number; // 0 - 100
  readySkillsCount: number;
  partialSkillsCount: number;
  missingSkillsCount: number;
  criticalMissingSkills: string[];
  gaps: SkillGapItem[];
  personalizedAdvice: string;
}

export interface RoadmapMilestone {
  id: string;
  month: number;
  phaseTitle: string;
  focusArea: string;
  objectives: string[];
  actionItems: {
    id: string;
    title: string;
    type: 'course' | 'project' | 'reading' | 'certification' | 'networking';
    estimatedHours: number;
    completed: boolean;
  }[];
  capstoneProject: {
    title: string;
    description: string;
    deliverables: string[];
  };
  certificationTarget?: string;
  successMetric: string;
}

export interface CareerRoadmap {
  id: string;
  userId: string;
  careerId: string;
  careerTitle: string;
  durationMonths: 3 | 6 | 12;
  weeklyHourCommitment: number;
  totalEstimatedHours: number;
  milestones: RoadmapMilestone[];
  guardrailsDisclaimed: boolean;
}

export interface ResumeATSAnalysis {
  overallScore: number; // 0 - 100
  readabilityScore: number; // 0 - 100
  keywordMatchScore: number; // 0 - 100
  formattingScore: number; // 0 - 100
  targetCareerTitle: string;
  matchedKeywords: string[];
  missingKeywords: string[];
  criticalIssues: string[];
  positiveHighlights: string[];
  bulletRewrites: {
    original: string;
    improved: string;
    explanation: string;
  }[];
  actionPlan: string[];
}

export interface ChatMessage {
  id: string;
  sender: 'user' | 'assistant' | 'system';
  content: string;
  timestamp: string;
  contextPointers?: {
    careerId?: string;
    skillGaps?: string[];
  };
}

export interface MilestoneProgressItem {
  id: string;
  title: string;
  phase: string;
  completed: boolean;
  dueDate?: string;
  category: 'Skill' | 'Project' | 'Cert' | 'Resume' | 'Network';
}
