import { UserProfile, Career, CareerMatch, CareerSkillGapAnalysis, SkillGapItem, CareerRoadmap, ResumeATSAnalysis } from '../types/career';
import { CAREERS_DATABASE } from '../data/careersData';

/**
 * Normalizes text for keyword matching
 */
function normalize(str: string): string {
  return str.toLowerCase().replace(/[^a-z0-9]/g, ' ').replace(/\s+/g, ' ').trim();
}

/**
 * Computes deterministic RAG match scores between a UserProfile and all Careers
 */
export function calculateCareerMatches(profile: UserProfile, careers: Career[] = CAREERS_DATABASE): CareerMatch[] {
  const userSkillNorms = new Set(profile.skills.map(s => normalize(s)));

  const matches: CareerMatch[] = careers.map(career => {
    // 1. Skills match (40% weight)
    const totalSkills = career.requiredSkills.length;
    let matchedSkillsWeight = 0;
    let totalWeight = 0;
    const matchedSkillNames: string[] = [];
    const missingSkillNames: string[] = [];

    career.requiredSkills.forEach(req => {
      const reqNorm = normalize(req.name);
      totalWeight += req.importance;

      // check exact or substring match
      const hasSkill = Array.from(userSkillNorms).some(uSkill => 
        uSkill.includes(reqNorm) || reqNorm.includes(uSkill) || 
        reqNorm.split(' ').some(w => w.length > 3 && uSkill.includes(w))
      );

      if (hasSkill) {
        matchedSkillsWeight += req.importance;
        matchedSkillNames.push(req.name);
      } else {
        missingSkillNames.push(req.name);
      }
    });

    const skillsScore = totalWeight > 0 ? Math.round((matchedSkillsWeight / totalWeight) * 100) : 50;

    // 2. Personality & Interest match (25% weight)
    let personalityScore = 65; // base default
    const traits = profile.personalityTraits || {};

    if (career.category === 'Data & AI' || career.category === 'Engineering & Tech') {
      const analytical = traits.analytical ?? 70;
      const curiosity = traits.curiosity ?? 70;
      personalityScore = Math.min(100, Math.round((analytical * 0.6) + (curiosity * 0.4)));
    } else if (career.category === 'Product & Design') {
      const creative = traits.creative ?? 75;
      const social = traits.social ?? 75;
      personalityScore = Math.min(100, Math.round((creative * 0.5) + (social * 0.5)));
    } else if (career.category === 'Cybersecurity') {
      const structured = traits.structured ?? 80;
      const analytical = traits.analytical ?? 70;
      personalityScore = Math.min(100, Math.round((structured * 0.6) + (analytical * 0.4)));
    } else if (career.category === 'Business & Finance Tech') {
      const leadership = traits.leadership ?? 70;
      const analytical = traits.analytical ?? 70;
      personalityScore = Math.min(100, Math.round((leadership * 0.5) + (analytical * 0.5)));
    }

    // 3. Goal Alignment: Desired salary & timeline (20% weight)
    let goalScore = 70;
    const desiredSal = profile.goals.desiredSalaryMin || 80000;
    if (career.medianSalaryUSD >= desiredSal) {
      goalScore = Math.min(100, 85 + Math.round(((career.medianSalaryUSD - desiredSal) / 30000) * 15));
    } else {
      const diffRatio = (desiredSal - career.medianSalaryUSD) / desiredSal;
      goalScore = Math.max(30, Math.round(75 - (diffRatio * 50)));
    }

    // Work type alignment
    if (profile.constraints.preferredWorkType === 'Remote' && career.remoteFriendliness === 'High') {
      goalScore = Math.min(100, goalScore + 5);
    }

    // 4. Market Opportunity & Growth (15% weight)
    const marketScore = Math.min(100, Math.round(50 + (career.tenYearGrowthRate * 1.3)));

    // Composite Weighted Score
    const compositeScore = Math.round(
      (skillsScore * 0.40) +
      (personalityScore * 0.25) +
      (goalScore * 0.20) +
      (marketScore * 0.15)
    );

    // Dynamic reasoning generation
    const reasoning = `${profile.fullName || 'Candidate'} aligns strongly with ${career.title} with a ${skillsScore}% skills overlap and high affinity for ${career.category}. Projected 10-year market growth of +${career.tenYearGrowthRate}% ensures robust employment outlook.`;

    return {
      careerId: career.id,
      career,
      matchScore: Math.min(99, Math.max(45, compositeScore)),
      scoreBreakdown: {
        skillsMatch: skillsScore,
        personalityMatch: personalityScore,
        goalAlignment: goalScore,
        marketOpportunity: marketScore
      },
      reasoning,
      keyStrengths: matchedSkillNames.slice(0, 3).length > 0 
        ? matchedSkillNames.slice(0, 3) 
        : ['Strong analytical foundation', 'Relevant educational background', 'Transferable domain mindset'],
      mainChallenges: missingSkillNames.slice(0, 3).length > 0 
        ? missingSkillNames.slice(0, 3) 
        : ['Production experience scale', 'Specialized tool certification'],
      recommendedTimelineMonths: profile.goals.timelineMonths || 6
    };
  });

  return matches.sort((a, b) => b.matchScore - a.matchScore);
}

/**
 * Computes deep Skill-Gap Analysis
 */
export function calculateSkillGap(profile: UserProfile, career: Career): CareerSkillGapAnalysis {
  const userSkillNorms = profile.skills.map(s => normalize(s));

  const gaps: SkillGapItem[] = career.requiredSkills.map(req => {
    const reqNorm = normalize(req.name);
    const hasExact = userSkillNorms.some(u => u === reqNorm);
    const hasPartial = !hasExact && userSkillNorms.some(u => 
      u.includes(reqNorm) || reqNorm.includes(u) ||
      reqNorm.split(' ').some(w => w.length > 3 && u.includes(w))
    );

    let status: 'acquired' | 'partial' | 'missing' = 'missing';
    let userProficiency: 'Proficient' | 'Familiar' | 'None' = 'None';
    let priority: 'High' | 'Medium' | 'Low' = req.importance >= 5 ? 'High' : req.importance >= 4 ? 'Medium' : 'Low';
    let hours = req.importance * 12;

    if (hasExact) {
      status = 'acquired';
      userProficiency = 'Proficient';
      hours = 0;
    } else if (hasPartial) {
      status = 'partial';
      userProficiency = 'Familiar';
      hours = Math.round(hours * 0.4);
    }

    return {
      skill: req.name,
      category: req.category,
      status,
      userProficiency,
      priority,
      estimatedHoursToLearn: hours,
      recommendedResources: [
        {
          type: 'Course',
          title: `Mastering ${req.name} in Production`,
          platform: 'Coursera / edX',
          isFree: false
        },
        {
          type: 'Project',
          title: `Hands-on Portfolio Showcase using ${req.name}`,
          platform: 'GitHub Real-World Repo',
          isFree: true
        }
      ]
    };
  });

  const readyCount = gaps.filter(g => g.status === 'acquired').length;
  const partialCount = gaps.filter(g => g.status === 'partial').length;
  const missingCount = gaps.filter(g => g.status === 'missing').length;

  const totalPoints = gaps.length * 2;
  const earnedPoints = (readyCount * 2) + (partialCount * 1);
  const readinessScore = Math.round((earnedPoints / totalPoints) * 100);

  const criticalMissing = gaps
    .filter(g => g.status === 'missing' && g.priority === 'High')
    .map(g => g.skill);

  const advice = readyCount > 5 
    ? `You have a strong direct competency foundation for ${career.title}. Prioritize closing the gap on ${criticalMissing.slice(0, 2).join(' and ') || 'specialized toolchains'} to achieve senior interview readiness.`
    : `You bring useful foundational skills. Focus your first 90 days on core prerequisites (${criticalMissing.slice(0, 2).join(', ')}) before tackling advanced portfolio capstones.`;

  return {
    careerId: career.id,
    careerTitle: career.title,
    overallReadinessScore: readinessScore,
    readySkillsCount: readyCount,
    partialSkillsCount: partialCount,
    missingSkillsCount: missingCount,
    criticalMissingSkills: criticalMissing,
    gaps,
    personalizedAdvice: advice
  };
}

/**
 * Generates a phased 3/6/12 month Roadmap
 */
export function generateRoadmap(profile: UserProfile, career: Career, durationMonths: 3 | 6 | 12 = 6): CareerRoadmap {
  const hoursPerWeek = profile.constraints.hoursPerWeekAvailable || 15;
  const totalHours = hoursPerWeek * durationMonths * 4.2;

  const milestoneCount = durationMonths === 3 ? 3 : durationMonths === 6 ? 4 : 6;
  const milestones = [];

  for (let i = 1; i <= milestoneCount; i++) {
    const monthLabel = durationMonths === 3 ? i : durationMonths === 6 ? i * 1.5 : i * 2;
    let phaseTitle = 'Phase 1: Core Foundation & Technical Prereqs';
    let focusArea = 'Foundational toolchains, fundamentals, and dev environment';
    let projectTitle = 'Interactive CLI & Data Pipeline Prototype';

    if (i === 2) {
      phaseTitle = 'Phase 2: Intermediate Implementation & Systems';
      focusArea = 'Framework depth, architectural patterns, and API integration';
      projectTitle = 'Full-featured Production Service with REST/gRPC & Database';
    } else if (i === 3) {
      phaseTitle = 'Phase 3: Production Hardening, Testing & CI/CD';
      focusArea = 'Test coverage, cloud deployment, and performance profiling';
      projectTitle = 'Cloud-Deployed Microservice with Telemetry & Monitoring';
    } else if (i >= 4) {
      phaseTitle = `Phase ${i}: Capstone Mastery & Interview Readiness`;
      focusArea = 'System design, portfolio capstone launch, and mock technical reviews';
      projectTitle = `${career.title} Enterprise End-to-End Capstone Showcase`;
    }

    milestones.push({
      id: `milestone-${i}`,
      month: Math.round(monthLabel),
      phaseTitle,
      focusArea,
      objectives: [
        `Master high-priority competencies: ${career.requiredSkills[i % career.requiredSkills.length].name}`,
        `Complete 2 real-world code assignments with automated test suites`,
        `Document architecture decision records (ADRs) in GitHub repository`
      ],
      actionItems: [
        {
          id: `act-${i}-1`,
          title: `Complete specialized curriculum modules for ${career.requiredSkills[(i * 2) % career.requiredSkills.length]?.name || 'System Architecture'}`,
          type: 'course' as const,
          estimatedHours: Math.round(totalHours / (milestoneCount * 3)),
          completed: i === 1
        },
        {
          id: `act-${i}-2`,
          title: `Build and document ${projectTitle}`,
          type: 'project' as const,
          estimatedHours: Math.round(totalHours / (milestoneCount * 2.5)),
          completed: false
        },
        {
          id: `act-${i}-3`,
          title: `Study key topics for ${career.topCertifications[0] || 'Industry Accreditation'}`,
          type: 'certification' as const,
          estimatedHours: Math.round(totalHours / (milestoneCount * 4)),
          completed: false
        }
      ],
      capstoneProject: {
        title: projectTitle,
        description: `Architect and open-source a comprehensive repository solving realistic industry challenges in ${career.category}.`,
        deliverables: [
          'GitHub repository with production README, architectural diagrams, and license',
          'Automated CI/CD workflow testing and packaging with Docker',
          'Live interactive demo URL or benchmark latency report'
        ]
      },
      certificationTarget: career.topCertifications[i % career.topCertifications.length],
      successMetric: `Passed benchmark technical assessments and pushed clean code with >= 80% test coverage.`
    });
  }

  return {
    id: `roadmap-${career.id}-${durationMonths}`,
    userId: profile.id,
    careerId: career.id,
    careerTitle: career.title,
    durationMonths,
    weeklyHourCommitment: hoursPerWeek,
    totalEstimatedHours: Math.round(totalHours),
    milestones,
    guardrailsDisclaimed: true
  };
}

/**
 * Evaluates Resume ATS score, keyword match, and provides X-Y-Z rewrites
 */
export function analyzeResumeATS(resumeText: string, targetCareer: Career): ResumeATSAnalysis {
  const normText = normalize(resumeText);
  
  const matchedKeywords: string[] = [];
  const missingKeywords: string[] = [];

  targetCareer.requiredSkills.forEach(skill => {
    const sNorm = normalize(skill.name);
    if (normText.includes(sNorm) || sNorm.split(' ').some(part => part.length > 3 && normText.includes(part))) {
      matchedKeywords.push(skill.name);
    } else {
      missingKeywords.push(skill.name);
    }
  });

  const keywordMatchRate = targetCareer.requiredSkills.length > 0 
    ? matchedKeywords.length / targetCareer.requiredSkills.length 
    : 0.5;

  const keywordMatchScore = Math.min(98, Math.round(keywordMatchRate * 100));

  // Check section headers
  const hasExperience = /experience|employment|work history/i.test(resumeText);
  const hasEducation = /education|university|degree|bachelor|master/i.test(resumeText);
  const hasSkills = /skills|technologies|proficiencies/i.test(resumeText);
  const hasProjects = /projects|portfolio|open source/i.test(resumeText);

  let formattingScore = 70;
  if (hasExperience) formattingScore += 8;
  if (hasEducation) formattingScore += 8;
  if (hasSkills) formattingScore += 8;
  if (hasProjects) formattingScore += 6;
  formattingScore = Math.min(100, formattingScore);

  // Readability heuristics (action verbs, quantifiable metrics)
  const metricMatches = resumeText.match(/\d+(\.\d+)?%|\$\d+|\d+\+?\s*(users|clients|rps|ms|hours|requests)/gi) || [];
  const actionVerbs = resumeText.match(/\b(architected|engineered|spearheaded|optimized|implemented|deployed|reduced|scaled|increased|refactored)\b/gi) || [];
  
  const readabilityScore = Math.min(95, Math.round(60 + (metricMatches.length * 4) + (actionVerbs.length * 3)));
  
  const overallScore = Math.round(
    (keywordMatchScore * 0.45) + 
    (formattingScore * 0.25) + 
    (readabilityScore * 0.30)
  );

  const criticalIssues: string[] = [];
  if (missingKeywords.length > 3) {
    criticalIssues.push(`Missing core high-frequency ATS keywords: ${missingKeywords.slice(0, 3).join(', ')}.`);
  }
  if (metricMatches.length < 3) {
    criticalIssues.push('Low density of quantifiable impact metrics (e.g., percentages, dollar amounts, latency figures).');
  }
  if (!hasSkills) {
    criticalIssues.push('Missing explicit "Technical Skills" section for automated ATS taxonomy parsers.');
  }

  const positiveHighlights: string[] = [];
  if (matchedKeywords.length >= 3) {
    positiveHighlights.push(`Direct alignment on ${matchedKeywords.slice(0, 3).join(', ')}.`);
  }
  if (actionVerbs.length >= 3) {
    positiveHighlights.push(`Strong active action verbs (${actionVerbs.slice(0, 3).join(', ')}) demonstrating ownership.`);
  }
  if (hasExperience && hasEducation) {
    positiveHighlights.push('Clear chronological structure with standard parseable headings.');
  }

  return {
    overallScore,
    readabilityScore,
    keywordMatchScore,
    formattingScore,
    targetCareerTitle: targetCareer.title,
    matchedKeywords,
    missingKeywords,
    criticalIssues: criticalIssues.length > 0 ? criticalIssues : ['Ensure consistent reverse chronological date formatting (MM/YYYY).'],
    positiveHighlights: positiveHighlights.length > 0 ? positiveHighlights : ['Resume has readable text encoding with standard character sets.'],
    bulletRewrites: [
      {
        original: 'Worked on backend APIs and helped the team improve system performance.',
        improved: `Architected 8 RESTful microservice endpoints in ${matchedKeywords[0] || 'Node.js/Go'}, reducing p95 API response latency by 34% across 120k daily active requests.`,
        explanation: 'Transforms passive wording into Google X-Y-Z formula (Accomplished [X], as measured by [Y], by doing [Z]).'
      },
      {
        original: 'Responsible for machine learning experiments and data pipelines.',
        improved: `Engineered end-to-end data pipelines and automated retraining workflows, improving model inference throughput by 2.4x while lowering cloud GPU compute spend by $18,000/year.`,
        explanation: 'Adds commercial scope, quantifiable throughput numbers, and financial impact.'
      }
    ],
    actionPlan: [
      `Inject missing target keywords (${missingKeywords.slice(0, 3).join(', ')}) naturally into work bullets and your skills table.`,
      'Replace all generic verbs ("worked on", "helped") with high-impact power verbs ("engineered", "orchestrated", "streamlined").',
      'Add at least 1 quantifiable numeric outcome to every major experience bullet.'
    ]
  };
}
