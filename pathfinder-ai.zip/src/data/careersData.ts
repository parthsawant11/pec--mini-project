import { Career } from '../types/career';

export const CAREERS_DATABASE: Career[] = [
  {
    id: 'ai-machine-learning-engineer',
    socCode: '15-1299.08',
    title: 'Machine Learning & AI Engineer',
    category: 'Data & AI',
    description: 'Designs, builds, and deploys scalable machine learning algorithms, deep neural networks, and LLM applications into production environments.',
    medianSalaryUSD: 162500,
    salaryRange: { p10: 108000, p50: 162500, p90: 228000 },
    tenYearGrowthRate: 34,
    projectedOpeningsAnnual: 22500,
    automationRisk: 'Low',
    remoteFriendliness: 'High',
    educationTypical: "Bachelor's Degree",
    requiredSkills: [
      { name: 'Python', category: 'Core Technical', importance: 5 },
      { name: 'PyTorch / TensorFlow', category: 'Specialized Technical', importance: 5 },
      { name: 'LLMs & Prompt Engineering', category: 'Specialized Technical', importance: 5 },
      { name: 'MLOps (MLflow, Kubeflow)', category: 'Tooling', importance: 4 },
      { name: 'Data Structures & Algorithms', category: 'Core Technical', importance: 4 },
      { name: 'Docker & Kubernetes', category: 'Tooling', importance: 4 },
      { name: 'SQL & Vector Databases', category: 'Core Technical', importance: 4 },
      { name: 'Mathematics & Linear Algebra', category: 'Core Technical', importance: 4 },
      { name: 'System Design', category: 'Specialized Technical', importance: 4 },
      { name: 'Problem Solving & Critical Thinking', category: 'Soft Skills', importance: 5 }
    ],
    responsibilities: [
      'Design and deploy retrieval-augmented generation (RAG) and predictive ML models',
      'Optimize model latency, token throughput, and GPU/TPU memory consumption',
      'Build automated CI/CD pipelines for model validation and retraining',
      'Collaborate with product and data engineering to ensure data governance and ethics'
    ],
    topCertifications: [
      'Google Professional Machine Learning Engineer',
      'AWS Certified Machine Learning - Specialty',
      'DeepLearning.AI TensorFlow Developer'
    ],
    sampleDayInTheLife: 'Fine-tuning an open-weights model on proprietary embeddings, reviewing Triton inference benchmarks, and pairing with backend engineers to integrate REST/gRPC endpoints.',
    benchmarkCompanies: ['Google', 'Anthropic', 'OpenAI', 'Meta', 'Databricks', 'Snowflake']
  },
  {
    id: 'full-stack-software-engineer',
    socCode: '15-1252.00',
    title: 'Full Stack Software Engineer',
    category: 'Engineering & Tech',
    description: 'Develops client-side user interfaces and server-side business logic, APIs, and persistent databases for modern web and mobile platforms.',
    medianSalaryUSD: 132200,
    salaryRange: { p10: 82000, p50: 132200, p90: 195000 },
    tenYearGrowthRate: 25,
    projectedOpeningsAnnual: 153900,
    automationRisk: 'Low',
    remoteFriendliness: 'High',
    educationTypical: "Bachelor's Degree",
    requiredSkills: [
      { name: 'JavaScript / TypeScript', category: 'Core Technical', importance: 5 },
      { name: 'React / Next.js', category: 'Specialized Technical', importance: 5 },
      { name: 'Node.js / Express / Fastify', category: 'Core Technical', importance: 5 },
      { name: 'SQL & PostgreSQL', category: 'Core Technical', importance: 4 },
      { name: 'REST APIs & GraphQL', category: 'Core Technical', importance: 4 },
      { name: 'Git & Version Control', category: 'Tooling', importance: 5 },
      { name: 'Tailwind CSS / UI Styling', category: 'Tooling', importance: 4 },
      { name: 'Unit & Integration Testing (Jest, Vitest)', category: 'Tooling', importance: 3 },
      { name: 'Cloud Deployment (Docker, AWS/GCP)', category: 'Tooling', importance: 4 },
      { name: 'Agile Team Collaboration', category: 'Soft Skills', importance: 4 }
    ],
    responsibilities: [
      'Architect, develop, and maintain responsive React web applications',
      'Design modular microservices and RESTful API endpoints in Node.js or Go',
      'Implement database schema migrations, indexes, and queries',
      'Participate in code reviews, sprint planning, and architectural retrospectives'
    ],
    topCertifications: [
      'AWS Certified Solutions Architect - Associate',
      'Meta Front-End & Back-End Professional Certificates',
      'MongoDB Certified Developer Associate'
    ],
    sampleDayInTheLife: 'Morning standup with product squad, implementing an OAuth session middleware, optimizing React re-renders, and reviewing pull requests for the staging release.',
    benchmarkCompanies: ['Stripe', 'Vercel', 'Shopify', 'Airbnb', 'HubSpot']
  },
  {
    id: 'data-scientist',
    socCode: '15-2051.00',
    title: 'Data Scientist & Quantitative Analyst',
    category: 'Data & AI',
    description: 'Applies statistical modeling, exploratory data analysis, and predictive modeling to extract actionable business insights from complex datasets.',
    medianSalaryUSD: 139500,
    salaryRange: { p10: 89000, p50: 139500, p90: 198000 },
    tenYearGrowthRate: 35,
    projectedOpeningsAnnual: 20800,
    automationRisk: 'Low',
    remoteFriendliness: 'High',
    educationTypical: "Master's Degree",
    requiredSkills: [
      { name: 'Python (pandas, numpy, scikit-learn)', category: 'Core Technical', importance: 5 },
      { name: 'SQL & Data Warehousing (BigQuery, Snowflake)', category: 'Core Technical', importance: 5 },
      { name: 'Hypothesis Testing & A/B Testing', category: 'Specialized Technical', importance: 5 },
      { name: 'Data Visualization (Tableau, PowerBI, Seaborn)', category: 'Tooling', importance: 4 },
      { name: 'Statistics & Probability', category: 'Core Technical', importance: 5 },
      { name: 'Machine Learning Modeling', category: 'Specialized Technical', importance: 4 },
      { name: 'Business Stakeholder Communication', category: 'Soft Skills', importance: 5 }
    ],
    responsibilities: [
      'Design and analyze statistical experiment metrics for product feature rollouts',
      'Formulate predictive retention and churn models',
      'Synthesize big data findings into executive dashboard narratives'
    ],
    topCertifications: [
      'Google Advanced Data Analytics Professional',
      'IBM Data Science Professional',
      'SAS Certified Data Scientist'
    ],
    sampleDayInTheLife: 'Evaluating statistical significance of a checkout funnel experiment, querying user behavior in BigQuery, and building a Jupyter notebook model presentation.',
    benchmarkCompanies: ['Netflix', 'Uber', 'Spotify', 'Amazon', 'McKinsey & Co.']
  },
  {
    id: 'cloud-devops-architect',
    socCode: '15-1251.00',
    title: 'Cloud DevOps & Site Reliability Engineer',
    category: 'Cloud & DevOps',
    description: 'Builds and maintains resilient cloud infrastructure, CI/CD automation pipelines, telemetry observability, and zero-downtime release architectures.',
    medianSalaryUSD: 147800,
    salaryRange: { p10: 95000, p50: 147800, p90: 215000 },
    tenYearGrowthRate: 28,
    projectedOpeningsAnnual: 34100,
    automationRisk: 'Low',
    remoteFriendliness: 'High',
    educationTypical: "Bachelor's Degree",
    requiredSkills: [
      { name: 'Infrastructure as Code (Terraform, Pulumi)', category: 'Specialized Technical', importance: 5 },
      { name: 'Kubernetes & Container Orchestration', category: 'Specialized Technical', importance: 5 },
      { name: 'AWS / GCP / Azure Cloud Platforms', category: 'Core Technical', importance: 5 },
      { name: 'CI/CD Pipelines (GitHub Actions, GitLab)', category: 'Tooling', importance: 5 },
      { name: 'Linux System Administration & Bash', category: 'Core Technical', importance: 5 },
      { name: 'Observability (Prometheus, Grafana, Datadog)', category: 'Tooling', importance: 4 },
      { name: 'Incident Response & Post-Mortems', category: 'Soft Skills', importance: 4 }
    ],
    responsibilities: [
      'Provision multi-region immutable cloud infrastructure via Terraform',
      'Design zero-downtime canary and blue-green deployment pipelines',
      'Monitor error budgets, p99 latency SLAs, and infrastructure cloud spend'
    ],
    topCertifications: [
      'AWS Certified DevOps Engineer - Professional',
      'Certified Kubernetes Administrator (CKA)',
      'Google Cloud Professional Cloud Architect'
    ],
    sampleDayInTheLife: 'Authoring Helm charts for microservices cluster upgrade, analyzing high CPU alerts on Grafana, and automating AWS cost optimization policies.',
    benchmarkCompanies: ['Cloudflare', 'HashiCorp', 'Red Hat', 'AWS', 'Google Cloud']
  },
  {
    id: 'cybersecurity-analyst',
    socCode: '15-1212.00',
    title: 'Cybersecurity Analyst & Threat Hunter',
    category: 'Cybersecurity',
    description: 'Monitors, protects, and defends network perimeters, endpoints, and corporate cloud assets from malicious threat actors and data breaches.',
    medianSalaryUSD: 120360,
    salaryRange: { p10: 74000, p50: 120360, p90: 182000 },
    tenYearGrowthRate: 32,
    projectedOpeningsAnnual: 17800,
    automationRisk: 'Low',
    remoteFriendliness: 'Medium',
    educationTypical: "Bachelor's Degree",
    requiredSkills: [
      { name: 'SIEM & SOC Tools (Splunk, Sentinel)', category: 'Tooling', importance: 5 },
      { name: 'Network Protocols & Packet Analysis (Wireshark)', category: 'Core Technical', importance: 5 },
      { name: 'Vulnerability Assessment & Pen Testing', category: 'Specialized Technical', importance: 4 },
      { name: 'Identity & Access Management (IAM)', category: 'Core Technical', importance: 4 },
      { name: 'Incident Response & Forensics', category: 'Specialized Technical', importance: 5 },
      { name: 'Security Compliance (SOC2, ISO27001, HIPAA)', category: 'Core Technical', importance: 3 },
      { name: 'Calm Under Pressure', category: 'Soft Skills', importance: 5 }
    ],
    responsibilities: [
      'Investigate alerts flagged by endpoint detection and response (EDR) agents',
      'Lead incident containment and root cause post-mortems for security anomalies',
      'Conduct regular phishing simulations and vulnerability scans'
    ],
    topCertifications: [
      'CompTIA Security+',
      'Certified Information Systems Security Professional (CISSP)',
      'Certified Ethical Hacker (CEH)'
    ],
    sampleDayInTheLife: 'Triage SIEM alert notifications, sandbox a suspicious executable received via email, and update firewall ingress rules for vulnerable ports.',
    benchmarkCompanies: ['CrowdStrike', 'Palo Alto Networks', 'Mandiant', 'Cisco', 'Cloudflare']
  },
  {
    id: 'ai-product-manager',
    socCode: '11-1021.00',
    title: 'AI Product Manager',
    category: 'Product & Design',
    description: 'Leads cross-functional squads to define product visions, user journeys, model validation metrics, and commercial launch strategies for AI products.',
    medianSalaryUSD: 154000,
    salaryRange: { p10: 102000, p50: 154000, p90: 220000 },
    tenYearGrowthRate: 20,
    projectedOpeningsAnnual: 18500,
    automationRisk: 'Low',
    remoteFriendliness: 'High',
    educationTypical: "Bachelor's Degree",
    requiredSkills: [
      { name: 'Product Discovery & User Research', category: 'Core Technical', importance: 5 },
      { name: 'AI/LLM Capabilities & Limitations', category: 'Specialized Technical', importance: 5 },
      { name: 'Roadmap Planning & PRDs', category: 'Core Technical', importance: 5 },
      { name: 'Metrics & OKRs (ROI, Retention, Guardrail Rates)', category: 'Core Technical', importance: 5 },
      { name: 'Cross-functional Leadership & Negotiation', category: 'Soft Skills', importance: 5 },
      { name: 'UX Prototyping (Figma)', category: 'Tooling', importance: 3 },
      { name: 'Agile & Scrum Execution', category: 'Tooling', importance: 4 }
    ],
    responsibilities: [
      'Author Product Requirement Documents (PRDs) detailing model evaluation thresholds',
      'Conduct customer discovery interviews and prioritize product backlog items',
      'Align engineering, legal, marketing, and sales on go-to-market milestones'
    ],
    topCertifications: [
      'Product School Certified Product Manager (CPM)',
      'Reforge Product Strategy',
      'Google Project Management Professional'
    ],
    sampleDayInTheLife: 'Reviewing user feedback on a generative search preview, refining acceptance criteria for next sprint, and presenting quarter OKR outcomes to executives.',
    benchmarkCompanies: ['Microsoft', 'Google', 'Notion', 'Salesforce', 'Figma']
  },
  {
    id: 'ui-ux-product-designer',
    socCode: '27-1024.00',
    title: 'UI/UX & Product Designer',
    category: 'Product & Design',
    description: 'Creates intuitive user flows, high-fidelity wireframes, interaction systems, and design tokens that elevate user experience across digital applications.',
    medianSalaryUSD: 114500,
    salaryRange: { p10: 71000, p50: 114500, p90: 168000 },
    tenYearGrowthRate: 16,
    projectedOpeningsAnnual: 24700,
    automationRisk: 'Low',
    remoteFriendliness: 'High',
    educationTypical: "Bachelor's Degree",
    requiredSkills: [
      { name: 'Figma & Component Systems', category: 'Tooling', importance: 5 },
      { name: 'User Journey Mapping & Wireframing', category: 'Core Technical', importance: 5 },
      { name: 'Usability Testing & User Interviews', category: 'Core Technical', importance: 4 },
      { name: 'Visual Design, Color Theory & Typography', category: 'Core Technical', importance: 5 },
      { name: 'Design Tokens & Design Systems', category: 'Specialized Technical', importance: 4 },
      { name: 'Accessibility Standards (WCAG 2.1 AA)', category: 'Specialized Technical', importance: 4 },
      { name: 'Empathy & Active Listening', category: 'Soft Skills', importance: 5 }
    ],
    responsibilities: [
      'Synthesize user research into wireframes, interactive prototypes, and specs',
      'Maintain design system component libraries aligned with frontend engineering',
      'Run unmoderated usability tests to measure cognitive friction and task completion'
    ],
    topCertifications: [
      'Google UX Design Professional Certificate',
      'Nielsen Norman Group UX Master Certified',
      'Interaction Design Foundation (IxDF)'
    ],
    sampleDayInTheLife: 'Conducting user tests on a mobile navigation prototype, updating Figma token variables, and doing QA pairing with React engineers.',
    benchmarkCompanies: ['Apple', 'Airbnb', 'Figma', 'Duolingo', 'Spotify']
  },
  {
    id: 'data-engineer',
    socCode: '15-1252.00',
    title: 'Modern Data Platform Engineer',
    category: 'Data & AI',
    description: 'Constructs reliable data pipelines, automated ETL/ELT workflows, data lakehouses, and real-time streaming architectures for analytics and ML.',
    medianSalaryUSD: 142000,
    salaryRange: { p10: 92000, p50: 142000, p90: 205000 },
    tenYearGrowthRate: 30,
    projectedOpeningsAnnual: 27500,
    automationRisk: 'Low',
    remoteFriendliness: 'High',
    educationTypical: "Bachelor's Degree",
    requiredSkills: [
      { name: 'Python & SQL', category: 'Core Technical', importance: 5 },
      { name: 'dbt (data build tool)', category: 'Specialized Technical', importance: 5 },
      { name: 'Apache Spark / Kafka / Flink', category: 'Specialized Technical', importance: 4 },
      { name: 'Snowflake / BigQuery / Databricks', category: 'Tooling', importance: 5 },
      { name: 'Airflow / Prefect Orchestration', category: 'Tooling', importance: 4 },
      { name: 'Data Modeling (Kimball, Star Schema)', category: 'Core Technical', importance: 4 },
      { name: 'Data Quality & Testing (Great Expectations)', category: 'Tooling', importance: 4 }
    ],
    responsibilities: [
      'Build robust ELT pipelines ingesting transactional databases into Snowflake',
      'Implement data transformation models and automated unit tests with dbt',
      'Ensure GDPR/CCPA data lineage, anonymization, and access governance'
    ],
    topCertifications: [
      'dbt Certified Developer',
      'Databricks Certified Data Engineer Associate',
      'Snowflake SnowPro Core Certification'
    ],
    sampleDayInTheLife: 'Refactoring a high-latency dbt transformation model, monitoring Airflow DAG run completions, and provisioning a new CDC connector.',
    benchmarkCompanies: ['Databricks', 'Snowflake', 'Twilio', 'Uber', 'Block']
  },
  {
    id: 'blockchain-web3-developer',
    socCode: '15-1252.00',
    title: 'Smart Contract & Web3 Systems Engineer',
    category: 'Engineering & Tech',
    description: 'Develops deterministic decentralized applications (dApps), cryptographic protocols, and audited smart contracts across modern blockchain networks.',
    medianSalaryUSD: 149000,
    salaryRange: { p10: 95000, p50: 149000, p90: 218000 },
    tenYearGrowthRate: 18,
    projectedOpeningsAnnual: 8200,
    automationRisk: 'Low',
    remoteFriendliness: 'High',
    educationTypical: "Bachelor's Degree",
    requiredSkills: [
      { name: 'Solidity / Rust', category: 'Specialized Technical', importance: 5 },
      { name: 'EVM Architecture & Gas Optimization', category: 'Specialized Technical', importance: 5 },
      { name: 'Hardhat / Foundry Testing Frameworks', category: 'Tooling', importance: 4 },
      { name: 'Web3.js / Ethers.js / viem', category: 'Core Technical', importance: 4 },
      { name: 'Cryptographic Primitives & Security Audits', category: 'Core Technical', importance: 5 },
      { name: 'TypeScript & Frontend Integration', category: 'Core Technical', importance: 4 }
    ],
    responsibilities: [
      'Author secure, gas-efficient smart contracts in Solidity and Foundry',
      'Perform formal verification and fuzz testing prior to mainnet deployments',
      'Integrate frontend wallets and transaction state hooks using Wagmi and Viem'
    ],
    topCertifications: [
      'ConsenSys Academy Blockchain Developer',
      'Certified Blockchain Solutions Architect'
    ],
    sampleDayInTheLife: 'Running Foundry invariance fuzz testing on a liquidity vault contract, optimizing gas opcodes, and coordinating security audit responses.',
    benchmarkCompanies: ['Uniswap Labs', 'ConsenSys', 'Chainlink Labs', 'Polygon', 'Coinbase']
  },
  {
    id: 'health-informatics-specialist',
    socCode: '15-1211.00',
    title: 'Health Informatics & Clinical Data Specialist',
    category: 'Healthcare Tech',
    description: 'Integrates electronic health record (EHR) systems, clinical data pipelines, and healthcare analytics to improve patient care outcomes and HIPAA compliance.',
    medianSalaryUSD: 104500,
    salaryRange: { p10: 68000, p50: 104500, p90: 152000 },
    tenYearGrowthRate: 22,
    projectedOpeningsAnnual: 14500,
    automationRisk: 'Low',
    remoteFriendliness: 'Medium',
    educationTypical: "Bachelor's Degree",
    requiredSkills: [
      { name: 'HL7 & FHIR Standards', category: 'Specialized Technical', importance: 5 },
      { name: 'Electronic Health Records (Epic, Cerner)', category: 'Tooling', importance: 5 },
      { name: 'SQL & Health Data Analytics', category: 'Core Technical', importance: 4 },
      { name: 'HIPAA & Healthcare Compliance', category: 'Core Technical', importance: 5 },
      { name: 'Python / R for Biostatistics', category: 'Specialized Technical', importance: 3 },
      { name: 'Clinical Workflow Empathy', category: 'Soft Skills', importance: 5 }
    ],
    responsibilities: [
      'Standardize and map clinical vocabularies (SNOMED, LOINC, ICD-10)',
      'Build FHIR REST interfaces for hospital patient portal interoperability',
      'Audit clinical data access logs for HIPAA safeguard compliance'
    ],
    topCertifications: [
      'Certified Health Data Analyst (CHDA)',
      'CAHIMS / CPHIMS (HIMSS)',
      'Epic Clarity Data Model Certification'
    ],
    sampleDayInTheLife: 'Mapping legacy lab feed feeds into FHIR JSON resources, attending clinical committee briefings, and validating oncology registry metrics.',
    benchmarkCompanies: ['Epic Systems', 'Mayo Clinic', 'UnitedHealth Group', 'Verily', 'Tempus']
  },
  {
    id: 'fintech-quantitative-developer',
    socCode: '15-1252.00',
    title: 'FinTech Quantitative Systems Developer',
    category: 'Business & Finance Tech',
    description: 'Engineers high-frequency execution infrastructure, financial risk models, algorithmic trading engines, and payment clearing microservices.',
    medianSalaryUSD: 175000,
    salaryRange: { p10: 115000, p50: 175000, p90: 255000 },
    tenYearGrowthRate: 24,
    projectedOpeningsAnnual: 11200,
    automationRisk: 'Low',
    remoteFriendliness: 'Medium',
    educationTypical: "Bachelor's Degree",
    requiredSkills: [
      { name: 'C++ or Low-Latency Python', category: 'Specialized Technical', importance: 5 },
      { name: 'Financial Markets & Derivatives Mechanics', category: 'Core Technical', importance: 4 },
      { name: 'Microsecond Latency Optimization', category: 'Specialized Technical', importance: 5 },
      { name: 'SQL & Time-Series DBs (kdb+, QuestDB)', category: 'Tooling', importance: 4 },
      { name: 'Multithreading & Lock-Free Data Structures', category: 'Specialized Technical', importance: 5 },
      { name: 'Risk Analytics & Value at Risk (VaR)', category: 'Core Technical', importance: 4 }
    ],
    responsibilities: [
      'Develop market-making order routing engines with sub-millisecond execution',
      'Write unit and backtesting suites for historical trade simulation',
      'Optimize network TCP socket stack configurations on bare-metal servers'
    ],
    topCertifications: [
      'CFA Institute Financial Modeling',
      'FRM (Financial Risk Manager)',
      'CQF (Certificate in Quantitative Finance)'
    ],
    sampleDayInTheLife: 'Profiling memory allocation bottlenecks on market data feed parsers, backtesting a mean-reversion strategy, and participating in risk limits review.',
    benchmarkCompanies: ['Jane Street', 'Two Sigma', 'Citadel', 'Stripe', 'Robinhood']
  },
  {
    id: 'ai-robotics-automation-engineer',
    socCode: '17-2199.08',
    title: 'Robotics & Autonomous Systems Engineer',
    category: 'Engineering & Tech',
    description: 'Designs control algorithms, ROS2 robotic pipelines, computer vision sensors, and path planning for autonomous drones, warehouse AGVs, and manipulators.',
    medianSalaryUSD: 145000,
    salaryRange: { p10: 95000, p50: 145000, p90: 205000 },
    tenYearGrowthRate: 26,
    projectedOpeningsAnnual: 9400,
    automationRisk: 'Low',
    remoteFriendliness: 'Low',
    educationTypical: "Bachelor's Degree",
    requiredSkills: [
      { name: 'ROS / ROS 2 (Robot Operating System)', category: 'Specialized Technical', importance: 5 },
      { name: 'C++ & Python', category: 'Core Technical', importance: 5 },
      { name: 'Computer Vision & OpenCV', category: 'Specialized Technical', importance: 5 },
      { name: 'Path Planning & SLAM Algorithms', category: 'Specialized Technical', importance: 4 },
      { name: 'Kinematics & Control Systems (PID, Kalman Filter)', category: 'Core Technical', importance: 5 },
      { name: 'Hardware-in-the-Loop (HIL) Testing', category: 'Tooling', importance: 4 }
    ],
    responsibilities: [
      'Implement sensor fusion combining LiDAR, IMU, and stereo camera streams',
      'Program trajectory generation and obstacle avoidance routines in ROS 2',
      'Simulate physical robot dynamics in Gazebo and Isaac Sim environments'
    ],
    topCertifications: [
      'NVIDIA Isaac Robotics Certification',
      'Udacity Robotics Software Engineer Nanodegree'
    ],
    sampleDayInTheLife: 'Simulating collision avoidance for a 6-axis robotic arm in Isaac Sim, flashing new firmware onto microcontrollers, and tuning PID controllers.',
    benchmarkCompanies: ['Boston Dynamics', 'Amazon Robotics', 'Tesla', 'Waymo', 'Zoox']
  },
  {
    id: 'information-security-manager',
    socCode: '11-3021.00',
    title: 'Information Security & GRC Manager',
    category: 'Cybersecurity',
    description: 'Leads security governance, enterprise risk management, vendor assessments, compliance frameworks, and organizational security policies.',
    medianSalaryUSD: 169000,
    salaryRange: { p10: 108000, p50: 169000, p90: 235000 },
    tenYearGrowthRate: 21,
    projectedOpeningsAnnual: 16200,
    automationRisk: 'Low',
    remoteFriendliness: 'High',
    educationTypical: "Bachelor's Degree",
    requiredSkills: [
      { name: 'GRC Frameworks (NIST CSF, SOC2, ISO 27001)', category: 'Core Technical', importance: 5 },
      { name: 'Third-Party Vendor Risk Assessment', category: 'Core Technical', importance: 5 },
      { name: 'Executive Security Reporting & Risk Registers', category: 'Soft Skills', importance: 5 },
      { name: 'Disaster Recovery & Business Continuity', category: 'Specialized Technical', importance: 4 },
      { name: 'Data Privacy Regulations (GDPR, CCPA)', category: 'Core Technical', importance: 4 }
    ],
    responsibilities: [
      'Direct annual SOC 2 Type II and ISO 27001 third-party surveillance audits',
      'Maintain enterprise risk registry and brief Audit Committee on residual risks',
      'Lead cross-department security awareness simulations'
    ],
    topCertifications: [
      'CISM (Certified Information Security Manager)',
      'CRISC (Certified in Risk and Information Systems Control)',
      'CISA (Certified Information Systems Auditor)'
    ],
    sampleDayInTheLife: 'Reviewing SaaS vendor security postures, presenting security roadmap progress to the Board, and evaluating penetration test remediation tickets.',
    benchmarkCompanies: ['PwC', 'Deloitte', 'Salesforce', 'JPMorgan Chase', 'Okta']
  },
  {
    id: 'mobile-app-developer',
    socCode: '15-1252.00',
    title: 'Mobile Applications Engineer (iOS & Android)',
    category: 'Engineering & Tech',
    description: 'Engineers performant, visually fluid native and cross-platform mobile experiences leveraging React Native, Swift, Kotlin, and offline-first storage.',
    medianSalaryUSD: 128500,
    salaryRange: { p10: 80000, p50: 128500, p90: 188000 },
    tenYearGrowthRate: 22,
    projectedOpeningsAnnual: 42000,
    automationRisk: 'Low',
    remoteFriendliness: 'High',
    educationTypical: "Bachelor's Degree",
    requiredSkills: [
      { name: 'React Native / Swift / Kotlin', category: 'Specialized Technical', importance: 5 },
      { name: 'Mobile UI/UX Patterns & Guidelines', category: 'Core Technical', importance: 4 },
      { name: 'State Management (Redux, Zustand)', category: 'Core Technical', importance: 4 },
      { name: 'Offline Storage & Sync (SQLite, WatermelonDB)', category: 'Core Technical', importance: 4 },
      { name: 'App Store & Google Play Submission Pipelines', category: 'Tooling', importance: 4 },
      { name: 'Performance Profiling & Memory Leaks', category: 'Tooling', importance: 4 }
    ],
    responsibilities: [
      'Develop 60fps gesture-driven interfaces in React Native and Swift',
      'Implement biometric authentication and push notification handlers',
      'Optimize bundle size and memory usage across diverse mobile chipsets'
    ],
    topCertifications: [
      'Meta React Native Specialization',
      'Google Associate Android Developer'
    ],
    sampleDayInTheLife: 'Profiling frame drops in Xcode Instruments, rolling out a phased TestFlight build, and integrating Apple Pay checkout flow.',
    benchmarkCompanies: ['Snap', 'DoorDash', 'Uber', 'Duolingo', 'Instagram']
  },
  {
    id: 'business-intelligence-architect',
    socCode: '15-2051.01',
    title: 'Business Intelligence & Analytics Architect',
    category: 'Business & Finance Tech',
    description: 'Transforms raw operational records into governed semantic data layers, predictive forecasting dashboards, and enterprise executive reports.',
    medianSalaryUSD: 125000,
    salaryRange: { p10: 82000, p50: 125000, p90: 176000 },
    tenYearGrowthRate: 27,
    projectedOpeningsAnnual: 19800,
    automationRisk: 'Low',
    remoteFriendliness: 'High',
    educationTypical: "Bachelor's Degree",
    requiredSkills: [
      { name: 'SQL & Advanced Window Functions', category: 'Core Technical', importance: 5 },
      { name: 'Power BI & DAX / Tableau Server', category: 'Tooling', importance: 5 },
      { name: 'Dimensional Modeling (Star / Snowflake Schema)', category: 'Core Technical', importance: 5 },
      { name: 'Data Pipeline Integration (Fivetran, dbt)', category: 'Tooling', importance: 4 },
      { name: 'Stakeholder Relationship Management', category: 'Soft Skills', importance: 5 }
    ],
    responsibilities: [
      'Design corporate dimensional models supporting executive KPI dashboards',
      'Author automated data freshness monitors and anomaly detection alerts',
      'Conduct training seminars empowering business units to self-serve insights'
    ],
    topCertifications: [
      'Microsoft Certified: Power BI Data Analyst Associate',
      'Tableau Desktop Certified Professional'
    ],
    sampleDayInTheLife: 'Optimizing DAX calculated tables for faster dashboard renders, meeting with the Chief Revenue Officer to define ARR churn metrics.',
    benchmarkCompanies: ['Workday', 'Nike', 'Target', 'Microsoft', 'Gartner']
  },
  {
    id: 'backend-distributed-systems-engineer',
    socCode: '15-1252.00',
    title: 'Distributed Systems & Backend Engineer',
    category: 'Engineering & Tech',
    description: 'Constructs fault-tolerant, high-concurrency microservices, consensus protocols, message brokers, and persistent storage layers.',
    medianSalaryUSD: 148000,
    salaryRange: { p10: 98000, p50: 148000, p90: 215000 },
    tenYearGrowthRate: 26,
    projectedOpeningsAnnual: 31000,
    automationRisk: 'Low',
    remoteFriendliness: 'High',
    educationTypical: "Bachelor's Degree",
    requiredSkills: [
      { name: 'Go / Java / Rust / Node.js', category: 'Core Technical', importance: 5 },
      { name: 'Distributed Consensus & CAP Theorem', category: 'Specialized Technical', importance: 5 },
      { name: 'gRPC & Protocol Buffers', category: 'Specialized Technical', importance: 4 },
      { name: 'Distributed Caching (Redis, Memcached)', category: 'Tooling', importance: 4 },
      { name: 'Event Streaming (Kafka, RabbitMQ)', category: 'Specialized Technical', importance: 5 },
      { name: 'PostgreSQL & Database Partitioning', category: 'Core Technical', importance: 5 },
      { name: 'System Architecture & High Availability', category: 'Core Technical', importance: 5 }
    ],
    responsibilities: [
      'Engineer horizontal autoscaling services processing 50k+ transactions/sec',
      'Design idempotent event consumers and dead-letter queue recovery procedures',
      'Partition relational database tables and tune connection pooling limits'
    ],
    topCertifications: [
      'AWS Certified Solutions Architect - Professional',
      'Confluent Certified Developer for Apache Kafka'
    ],
    sampleDayInTheLife: 'Investigating split-brain failover logic in a Redis cluster, refactoring gRPC schemas, and load testing database sharding with k6.',
    benchmarkCompanies: ['Discord', 'Twitch', 'Cloudflare', 'Stripe', 'Netflix']
  },
  {
    id: 'technical-program-manager',
    socCode: '11-3021.00',
    title: 'Technical Program Manager (TPM)',
    category: 'Product & Design',
    description: 'Drives large-scale, multi-team engineering programs from concept through launch, managing cross-system dependencies, risks, and technical milestones.',
    medianSalaryUSD: 152000,
    salaryRange: { p10: 104000, p50: 152000, p90: 212000 },
    tenYearGrowthRate: 18,
    projectedOpeningsAnnual: 17300,
    automationRisk: 'Low',
    remoteFriendliness: 'High',
    educationTypical: "Bachelor's Degree",
    requiredSkills: [
      { name: 'Technical Systems Literacy', category: 'Core Technical', importance: 5 },
      { name: 'Risk Management & Dependency Tracking', category: 'Specialized Technical', importance: 5 },
      { name: 'Executive Communication & Alignment', category: 'Soft Skills', importance: 5 },
      { name: 'Agile at Scale (SAFe, LeSS)', category: 'Core Technical', importance: 4 },
      { name: 'Jira, Confluence & Tracking Tooling', category: 'Tooling', importance: 4 }
    ],
    responsibilities: [
      'Map critical path dependencies across 8 hardware and software engineering squads',
      'Facilitate architectural milestone reviews and sign-off criteria',
      'Unblock delivery blockers and communicate status updates to executive VPs'
    ],
    topCertifications: [
      'PMP (Project Management Professional)',
      'Scrum Alliance Certified Scrum Master (CSM)',
      'AWS Certified Cloud Practitioner'
    ],
    sampleDayInTheLife: 'Syncing with infrastructure and mobile leads on a major API deprecation timeline, resolving team dependency roadblocks, and publishing weekly exec digest.',
    benchmarkCompanies: ['Google', 'Meta', 'Microsoft', 'Apple', 'Amazon']
  },
  {
    id: 'generative-ai-solutions-architect',
    socCode: '15-1299.08',
    title: 'Enterprise AI & GenAI Solutions Architect',
    category: 'Data & AI',
    description: 'Advises enterprise clients on designing, validating, and governing generative AI architectures, agentic workflows, and safe enterprise integrations.',
    medianSalaryUSD: 168000,
    salaryRange: { p10: 112000, p50: 168000, p90: 235000 },
    tenYearGrowthRate: 38,
    projectedOpeningsAnnual: 18200,
    automationRisk: 'Low',
    remoteFriendliness: 'High',
    educationTypical: "Bachelor's Degree",
    requiredSkills: [
      { name: 'Enterprise LLM Architectures (RAG, Fine-tuning)', category: 'Specialized Technical', importance: 5 },
      { name: 'Agentic Frameworks (LangGraph, CrewAI)', category: 'Specialized Technical', importance: 5 },
      { name: 'Security, Privacy & Responsible AI Guardrails', category: 'Core Technical', importance: 5 },
      { name: 'Cloud AI Services (Vertex AI, AWS Bedrock, Azure OpenAI)', category: 'Tooling', importance: 5 },
      { name: 'Executive Client Presentation & Consulting', category: 'Soft Skills', importance: 5 },
      { name: 'Vector DBs & Semantic Search (Pinecone, Qdrant, Chroma)', category: 'Core Technical', importance: 4 }
    ],
    responsibilities: [
      'Design enterprise RAG architectures incorporating hybrid keyword/vector search',
      'Establish safety guardrail layers preventing prompt injection and data leaks',
      'Calculate total cost of ownership (TCO) comparing managed LLMs vs. open models'
    ],
    topCertifications: [
      'Google Cloud Certified Professional Cloud Architect',
      'AWS Certified Generative AI Early Adopter'
    ],
    sampleDayInTheLife: 'Whiteboarding an enterprise multi-agent compliance pipeline with a Fortune 500 client, running semantic eval benchmarks on Vertex AI.',
    benchmarkCompanies: ['Google Cloud', 'Microsoft', 'AWS', 'Accenture', 'Boston Consulting Group']
  },
  {
    id: 'embedded-systems-iot-engineer',
    socCode: '17-2072.00',
    title: 'Embedded Firmware & IoT Engineer',
    category: 'Engineering & Tech',
    description: 'Writes optimized C/C++ microcode for microcontrollers, sensors, wearable devices, and connected hardware edge devices.',
    medianSalaryUSD: 122000,
    salaryRange: { p10: 78000, p50: 122000, p90: 178000 },
    tenYearGrowthRate: 15,
    projectedOpeningsAnnual: 12100,
    automationRisk: 'Low',
    remoteFriendliness: 'Low',
    educationTypical: "Bachelor's Degree",
    requiredSkills: [
      { name: 'Embedded C / C++', category: 'Core Technical', importance: 5 },
      { name: 'RTOS (FreeRTOS, Zephyr)', category: 'Specialized Technical', importance: 5 },
      { name: 'Serial Protocols (I2C, SPI, UART, CAN)', category: 'Core Technical', importance: 5 },
      { name: 'Oscilloscopes & Logic Analyzers', category: 'Tooling', importance: 4 },
      { name: 'Low-Power Hardware Design', category: 'Specialized Technical', importance: 4 },
      { name: 'BLE & Zigbee Wireless Protocols', category: 'Specialized Technical', importance: 3 }
    ],
    responsibilities: [
      'Write deterministic sensor drivers on ARM Cortex-M microcontrollers',
      'Optimize battery consumption profiles down to microamp deep sleep states',
      'Debug hardware timing issues using digital logic analyzers and JTAG probes'
    ],
    topCertifications: [
      'Arm Accredited Engineer (AAE)',
      'Embedded Linux Development (Linux Foundation)'
    ],
    sampleDayInTheLife: 'Tracing an I2C timing glitch on an oscilloscope, updating FreeRTOS task priorities for power efficiency, and flashing new bootloader firmware.',
    benchmarkCompanies: ['Qualcomm', 'Garmin', 'Texas Instruments', 'Apple', 'NXP Semiconductors']
  },
  {
    id: 'growth-marketing-data-engineer',
    socCode: '15-1252.00',
    title: 'Growth Marketing & MarTech Systems Engineer',
    category: 'Business & Finance Tech',
    description: 'Bridges marketing strategy and engineering by developing customer data platforms, attribution algorithms, and automated conversion experiments.',
    medianSalaryUSD: 118000,
    salaryRange: { p10: 74000, p50: 118000, p90: 172000 },
    tenYearGrowthRate: 21,
    projectedOpeningsAnnual: 14200,
    automationRisk: 'Low',
    remoteFriendliness: 'High',
    educationTypical: "Bachelor's Degree",
    requiredSkills: [
      { name: 'SQL & Data Modeling', category: 'Core Technical', importance: 5 },
      { name: 'Customer Data Platforms (Segment, RudderStack)', category: 'Tooling', importance: 5 },
      { name: 'Python & Marketing Automation APIs', category: 'Core Technical', importance: 4 },
      { name: 'Multi-Touch Attribution Modeling', category: 'Specialized Technical', importance: 4 },
      { name: 'SEO & Web Performance Metrics', category: 'Core Technical', importance: 3 },
      { name: 'Commercial Acumen & Funnel Optimization', category: 'Soft Skills', importance: 5 }
    ],
    responsibilities: [
      'Unify customer identities across web, mobile, and payment events using Segment',
      'Engineer reverse-ETL pipelines syncing analytical cohorts to ad platforms',
      'Implement multi-armed bandit testing for homepage landing variations'
    ],
    topCertifications: [
      'Google Analytics 4 Certification',
      'Segment Certified Administrator'
    ],
    sampleDayInTheLife: 'Debugging webhook drops between Stripe and HubSpot, building a churn propensity cohort in Snowflake, and reviewing referral campaign metrics.',
    benchmarkCompanies: ['Pinterest', 'Canva', 'Shopify', 'Grammarly', 'HubSpot']
  }
];
