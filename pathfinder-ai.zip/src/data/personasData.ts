import { UserProfile } from '../types/career';

export interface PersonaMeta {
  id: string;
  name: string;
  tagline: string;
  roleType: 'student' | 'job_seeker' | 'career_switcher';
  avatarInitials: string;
  avatarColor: string;
  bio: string;
  profile: UserProfile;
}

export const PRESET_PERSONAS: PersonaMeta[] = [
  {
    id: 'student-priya',
    name: 'Priya Sharma',
    tagline: 'Final-Year Computer Science & Statistics Student',
    roleType: 'student',
    avatarInitials: 'PS',
    avatarColor: 'bg-emerald-600',
    bio: 'Graduating next spring with strong math fundamentals, Python and basic ML coursework, looking for a high-growth career path with remote options.',
    profile: {
      id: 'persona-priya',
      fullName: 'Priya Sharma',
      personaType: 'student',
      education: {
        level: "Bachelor's Degree",
        field: 'Computer Science & Statistics',
        institution: 'University of Washington',
        graduationYear: 2026
      },
      experienceLevel: 'Entry-level (0-1 yrs)',
      currentTitle: 'Research Assistant & Student',
      skills: [
        'Python',
        'Data Structures & Algorithms',
        'Mathematics & Linear Algebra',
        'SQL & PostgreSQL',
        'Git & Version Control',
        'Problem Solving & Critical Thinking'
      ],
      interests: [
        'Machine Learning & AI',
        'Predictive Analytics',
        'Algorithmic Trading',
        'Open Source Software'
      ],
      personalityTraits: {
        analytical: 92,
        curiosity: 88,
        structured: 75,
        social: 60,
        riskTolerance: 55
      },
      quizAnswers: {
        q1: 'solve_math',
        q2: 'technical_code',
        q3: 'autonomous_work',
        q4: 'data_evidence'
      },
      goals: {
        targetRoleCategory: 'Data & AI',
        desiredSalaryMin: 115000,
        timelineMonths: 6,
        primaryMotivator: 'Tech Innovation'
      },
      constraints: {
        preferredWorkType: 'Remote',
        learningBudgetUSD: 500,
        hoursPerWeekAvailable: 18,
        location: 'Seattle, WA (Open to Remote)'
      }
    }
  },
  {
    id: 'job-seeker-marcus',
    name: 'Marcus Vance',
    tagline: 'Frontend Developer Seeking Full-Stack / Cloud Growth',
    roleType: 'job_seeker',
    avatarInitials: 'MV',
    avatarColor: 'bg-blue-600',
    bio: '3.5 years of React and JavaScript experience at a digital agency. Looking to transition into a high-paying Full Stack or Cloud DevOps engineering position.',
    profile: {
      id: 'persona-marcus',
      fullName: 'Marcus Vance',
      personaType: 'job_seeker',
      education: {
        level: "Bachelor's Degree",
        field: 'Information Systems',
        institution: 'Ohio State University',
        graduationYear: 2022
      },
      experienceLevel: 'Early Career (1-3 yrs)',
      currentTitle: 'Junior Frontend Developer',
      skills: [
        'JavaScript / TypeScript',
        'React / Next.js',
        'Tailwind CSS / UI Styling',
        'Git & Version Control',
        'REST APIs & GraphQL',
        'Agile Team Collaboration'
      ],
      interests: [
        'Cloud Architecture',
        'Microservices & Distributed Systems',
        'High-Scale Web Platforms',
        'Developer Tooling'
      ],
      personalityTraits: {
        analytical: 80,
        curiosity: 82,
        structured: 78,
        social: 72,
        riskTolerance: 65
      },
      quizAnswers: {
        q1: 'build_software',
        q2: 'technical_code',
        q3: 'team_sprint',
        q4: 'user_adoption'
      },
      goals: {
        targetRoleCategory: 'Engineering & Tech',
        desiredSalaryMin: 135000,
        timelineMonths: 3,
        primaryMotivator: 'Higher Salary'
      },
      constraints: {
        preferredWorkType: 'Hybrid',
        learningBudgetUSD: 1000,
        hoursPerWeekAvailable: 15,
        location: 'Chicago, IL (Hybrid / Remote)'
      }
    }
  },
  {
    id: 'career-switcher-elena',
    name: 'Elena Rostova',
    tagline: 'Digital Marketing Strategist Pivoting to AI Product Design / Management',
    roleType: 'career_switcher',
    avatarInitials: 'ER',
    avatarColor: 'bg-purple-600',
    bio: '6 years of experience driving brand engagement and content strategy. Enthusiastic about generative AI products, UX design systems, and product roadmaps.',
    profile: {
      id: 'persona-elena',
      fullName: 'Elena Rostova',
      personaType: 'career_switcher',
      education: {
        level: "Bachelor's Degree",
        field: 'Communications & Visual Media',
        institution: 'UT Austin',
        graduationYear: 2019
      },
      experienceLevel: 'Mid-level (3-7 yrs)',
      currentTitle: 'Senior Marketing Specialist',
      skills: [
        'Business Stakeholder Communication',
        'Empathy & Active Listening',
        'Visual Design, Color Theory & Typography',
        'Figma & Component Systems',
        'Product Discovery & User Research',
        'Cross-functional Leadership & Negotiation'
      ],
      interests: [
        'Design Systems & Interaction UX',
        'Generative AI Product Experience',
        'User Psychology & Usability Testing',
        'Tech Startup Strategy'
      ],
      personalityTraits: {
        analytical: 68,
        curiosity: 95,
        structured: 80,
        social: 90,
        riskTolerance: 70
      },
      quizAnswers: {
        q1: 'design_human_experience',
        q2: 'creative_strategy',
        q3: 'team_sprint',
        q4: 'user_adoption'
      },
      goals: {
        targetRoleCategory: 'Product & Design',
        desiredSalaryMin: 125000,
        timelineMonths: 6,
        primaryMotivator: 'Impact & Purpose'
      },
      constraints: {
        preferredWorkType: 'Remote',
        learningBudgetUSD: 1500,
        hoursPerWeekAvailable: 12,
        location: 'Austin, TX'
      }
    }
  }
];
