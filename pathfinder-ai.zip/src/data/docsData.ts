export interface ArchitectureDocSection {
  id: string;
  number: number;
  title: string;
  description: string;
  contentMarkdown: string;
  badge?: string;
}

export const ARCHITECTURE_DOCUMENTATION: ArchitectureDocSection[] = [
  {
    id: 'overview-personas',
    number: 1,
    title: 'Project Overview & User Personas',
    badge: 'Deliverable 1',
    description: 'System objective, target user segments, and behavioral persona profiles.',
    contentMarkdown: `### 1.1 Executive Overview
**CareerForge AI** is an intelligent, full-stack career guidance and upskilling orchestration platform designed to eliminate occupational uncertainty for students, active job seekers, and career switchers.

Unlike generic career quizzes that offer superficial suggestions, CareerForge AI couples **O*NET standard occupational data (Bureau of Labor Statistics)** with **Retrieval-Augmented Generation (RAG)** powered by **Gemini 3.8 Flash**. Every recommendation is grounded in real market economics: verified SOC codes, salary percentiles ($p_{10}, p_{50}, p_{90}$), 10-year projected employment growth rates, and empirically required hard/soft skills.

---

### 1.2 User Personas & Journey Maps

#### Persona 1: The College Student / New Grad
- **Archetype**: Priya Sharma, 22
- **Current State**: Senior undergraduate studying Computer Science & Applied Statistics.
- **Pain Points**: Overwhelmed by divergent career tracks (SWE vs. Data Engineering vs. ML Ops vs. Quantitative Dev). Unsure how her academic coursework translates into industry-grade hiring requirements.
- **Needs**: Grounded match scores based on real O*NET metrics, an objective skill gap checklist, and a 6-month roadmap with portfolio capstones.

#### Persona 2: The Mid-Career Job Seeker
- **Archetype**: Marcus Vance, 28
- **Current State**: Frontend engineer with 3.5 years of experience feeling pigeonholed and wanting higher compensation and leadership scope.
- **Pain Points**: High rejection rate in ATS scanners; unclear if his skills translate to Full-Stack or DevOps architectures.
- **Needs**: Resume ATS scanning with bullet-point rewrites (Google X-Y-Z formula), targeted certification path (AWS/CKA), and compensation benchmarks.

#### Persona 3: The Non-Tech Career Switcher
- **Archetype**: Elena Rostova, 31
- **Current State**: Senior Digital Marketing Specialist seeking a pivot into AI Product Management or UI/UX Product Design.
- **Pain Points**: Impostor syndrome, fear of restarting at zero salary, tight timeline (6 months), and uncertainty about which past skills are transferable.
- **Needs**: Transferable skills analysis, realistic study hour budgets, and empathetic AI career mentor chat.`
  },
  {
    id: 'system-architecture-mermaid',
    number: 2,
    title: 'System Architecture & Data Flow (Mermaid)',
    badge: 'Deliverable 2',
    description: 'Interactive Mermaid architecture diagram, component topology, and end-to-end data pipelines.',
    contentMarkdown: `### 2.1 System Architecture Diagram

\`\`\`mermaid
graph TD
    subgraph Client [Client-Side Layer - React 19 + Tailwind v4 + Motion]
        UI[CareerForge Web Application]
        Intake[1. Profile Intake & RIASEC Quiz]
        Matches[2. Career Matches & Radar Scores]
        Gaps[3. Skill-Gap Matrix & Remediation]
        RoadmapUI[4. Phased 3/6/12-Month Roadmap]
        ATS[5. ATS Resume Scanner & Rewriter]
        ChatUI[6. Context-Aware AI Career Mentor]
        MarketUI[7. BLS / O*NET Market Insights]
        Tracker[8. Progress Dashboard & Export]
    end

    subgraph Server [Server-Side Layer - Node.js Express Backend]
        Router[API Gateway /api/*]
        AuthGuard[Session & Payload Validator]
        RAGService[O*NET Knowledge Base Retrieval]
        RecommenderSvc[Weighted Matching Engine]
        GapSvc[Skill-Gap Computation Matrix]
        RoadmapSvc[Phased Roadmap Generator]
        ResumeSvc[ATS Parser & Keyword Extractor]
        ChatSvc[Contextual Chatbot Agent]
    end

    subgraph KnowledgeLayer [Grounded Data Layer]
        ONET_DB[(O*NET Knowledge Base 25+ Occupations)]
        PostgreSQL[(Relational PostgreSQL DB / Storage)]
        VectorIndex[(Semantic Skills Embedding Index)]
    end

    subgraph ExternalAI [Google GenAI Cloud Services]
        GeminiFlash[Gemini 3.8 Flash Engine]
        JSONValidator[Structured Schema Enforcement]
    end

    %% Client-Server Traffic
    UI --> Router
    Intake --> Router
    ATS --> Router
    ChatUI --> Router

    %% Server Internal Routing
    Router --> RAGService
    Router --> ResumeSvc
    Router --> ChatSvc
    RAGService --> ONET_DB
    RAGService --> VectorIndex
    RAGService --> PostgreSQL

    %% External AI Invocations
    RecommenderSvc --> GeminiFlash
    GapSvc --> GeminiFlash
    RoadmapSvc --> GeminiFlash
    ResumeSvc --> GeminiFlash
    ChatSvc --> GeminiFlash
    GeminiFlash --> JSONValidator
    JSONValidator --> Router
\`\`\`

---

### 2.2 End-to-End Data Flow

1. **Intake & Profiling**: Candidate submits education, self-assessed skills, interests, and completes the 4-part RIASEC personality quiz.
2. **Semantic Knowledge Retrieval (RAG)**: The server queries the O*NET occupational repository, filtering candidates by salary constraints, work mode preferences, and semantic skill overlap.
3. **Structured Gemini Synthesis**: The candidate payload + top retrieved careers are passed to \`gemini-3.8-flash\` with a strictly enforced JSON schema (\`responseSchema\`).
4. **Deterministic Fallback Pipeline**: If an external API is transiently unreachable, the internal algorithmic engine executes Jaccard/Cosine similarity matching over skill graphs to ensure zero downtime.
5. **Stateful Chat & Memory**: The chatbot maintains candidate context pointers (active target career, identified skill gaps, roadmap milestone) across all conversation turns.`
  },
  {
    id: 'database-schema',
    number: 3,
    title: 'Relational Database Schema (PostgreSQL)',
    badge: 'Deliverable 3',
    description: 'Full DDL schema, relationships, indexes, constraints, and JSONB schemas.',
    contentMarkdown: `### 3.1 Relational Entity-Relationship Design (PostgreSQL DDL)

\`\`\`sql
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- 1. Users Table
CREATE TABLE users (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    email VARCHAR(255) UNIQUE NOT NULL,
    full_name VARCHAR(150) NOT NULL,
    persona_type VARCHAR(50) NOT NULL CHECK (persona_type IN ('student', 'job_seeker', 'career_switcher', 'custom')),
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- 2. User Profiles Table (Intake, Education, Constraints)
CREATE TABLE user_profiles (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    education_level VARCHAR(100) NOT NULL,
    education_field VARCHAR(150) NOT NULL,
    institution VARCHAR(200),
    graduation_year INTEGER,
    experience_level VARCHAR(50) NOT NULL,
    current_title VARCHAR(150),
    personality_traits JSONB NOT NULL DEFAULT '{}'::jsonb,
    desired_salary_min NUMERIC(10, 2) NOT NULL DEFAULT 60000.00,
    timeline_months INTEGER NOT NULL CHECK (timeline_months IN (3, 6, 12)),
    primary_motivator VARCHAR(100) NOT NULL,
    preferred_work_type VARCHAR(50) NOT NULL CHECK (preferred_work_type IN ('Remote', 'Hybrid', 'On-site', 'Any')),
    learning_budget_usd NUMERIC(10, 2) DEFAULT 500.00,
    hours_per_week_available INTEGER NOT NULL DEFAULT 15,
    location VARCHAR(150),
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- 3. Skills Repository
CREATE TABLE skills (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    name VARCHAR(100) UNIQUE NOT NULL,
    category VARCHAR(50) NOT NULL CHECK (category IN ('Core Technical', 'Specialized Technical', 'Tooling', 'Soft Skills')),
    description TEXT
);

-- 4. User Acquired Skills
CREATE TABLE user_skills (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    skill_id UUID NOT NULL REFERENCES skills(id) ON DELETE CASCADE,
    proficiency_level VARCHAR(50) NOT NULL CHECK (proficiency_level IN ('Familiar', 'Proficient', 'Expert')),
    verified_by_assessment BOOLEAN DEFAULT FALSE,
    UNIQUE(user_id, skill_id)
);

-- 5. O*NET Careers Master Table
CREATE TABLE careers (
    id VARCHAR(100) PRIMARY KEY,
    soc_code VARCHAR(20) NOT NULL,
    title VARCHAR(150) NOT NULL,
    category VARCHAR(100) NOT NULL,
    description TEXT NOT NULL,
    median_salary_usd NUMERIC(10, 2) NOT NULL,
    salary_p10 NUMERIC(10, 2) NOT NULL,
    salary_p90 NUMERIC(10, 2) NOT NULL,
    ten_year_growth_rate NUMERIC(5, 2) NOT NULL,
    projected_openings_annual INTEGER NOT NULL,
    automation_risk VARCHAR(20) NOT NULL CHECK (automation_risk IN ('Low', 'Moderate', 'High')),
    remote_friendliness VARCHAR(20) NOT NULL CHECK (remote_friendliness IN ('High', 'Medium', 'Low')),
    education_typical VARCHAR(100) NOT NULL,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- 6. Career Required Skills
CREATE TABLE career_skills (
    career_id VARCHAR(100) NOT NULL REFERENCES careers(id) ON DELETE CASCADE,
    skill_id UUID NOT NULL REFERENCES skills(id) ON DELETE CASCADE,
    importance_weight INTEGER NOT NULL CHECK (importance_weight BETWEEN 1 AND 5),
    PRIMARY KEY (career_id, skill_id)
);

-- 7. Career Recommendations Snapshot
CREATE TABLE career_recommendations (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    career_id VARCHAR(100) NOT NULL REFERENCES careers(id) ON DELETE CASCADE,
    match_score INTEGER NOT NULL CHECK (match_score BETWEEN 0 AND 100),
    skills_match_score INTEGER NOT NULL,
    personality_match_score INTEGER NOT NULL,
    goal_alignment_score INTEGER NOT NULL,
    market_opportunity_score INTEGER NOT NULL,
    reasoning TEXT NOT NULL,
    key_strengths JSONB NOT NULL DEFAULT '[]'::jsonb,
    main_challenges JSONB NOT NULL DEFAULT '[]'::jsonb,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- 8. Personalized Phased Roadmaps
CREATE TABLE user_roadmaps (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    career_id VARCHAR(100) NOT NULL REFERENCES careers(id) ON DELETE CASCADE,
    duration_months INTEGER NOT NULL CHECK (duration_months IN (3, 6, 12)),
    weekly_hours INTEGER NOT NULL,
    milestones_data JSONB NOT NULL,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- 9. Milestone Action Items & Progress
CREATE TABLE roadmap_progress (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    roadmap_id UUID NOT NULL REFERENCES user_roadmaps(id) ON DELETE CASCADE,
    action_item_id VARCHAR(100) NOT NULL,
    title VARCHAR(255) NOT NULL,
    category VARCHAR(50) NOT NULL,
    is_completed BOOLEAN DEFAULT FALSE,
    completed_at TIMESTAMP WITH TIME ZONE,
    notes TEXT
);

-- 10. Resume ATS Scans
CREATE TABLE resume_analyses (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    target_career_id VARCHAR(100) REFERENCES careers(id) ON DELETE SET NULL,
    overall_score INTEGER NOT NULL CHECK (overall_score BETWEEN 0 AND 100),
    keyword_score INTEGER NOT NULL,
    formatting_score INTEGER NOT NULL,
    readability_score INTEGER NOT NULL,
    matched_keywords JSONB NOT NULL DEFAULT '[]'::jsonb,
    missing_keywords JSONB NOT NULL DEFAULT '[]'::jsonb,
    bullet_rewrites JSONB NOT NULL DEFAULT '[]'::jsonb,
    action_plan JSONB NOT NULL DEFAULT '[]'::jsonb,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- High Performance Indexes
CREATE INDEX idx_user_profiles_user_id ON user_profiles(user_id);
CREATE INDEX idx_career_skills_career_id ON career_skills(career_id);
CREATE INDEX idx_career_skills_skill_id ON career_skills(skill_id);
CREATE INDEX idx_recommendations_user_id ON career_recommendations(user_id);
CREATE INDEX idx_roadmaps_user_id ON user_roadmaps(user_id);
\`\`\``
  },
  {
    id: 'api-specification',
    number: 4,
    title: 'API Endpoint Specification (REST / JSON)',
    badge: 'Deliverable 4',
    description: 'Full RESTful endpoint design, input payloads, response schemas, and status codes.',
    contentMarkdown: `### 4.1 REST API Routes Specification

| Method | Endpoint | Description | Auth / Security |
|---|---|---|---|
| \`GET\` | \`/api/careers\` | Query all O*NET careers with filtering by sector, salary, growth | Public |
| \`GET\` | \`/api/careers/:id\` | Detailed single career specification, required skills, and certs | Public |
| \`POST\` | \`/api/recommendations\` | Match candidate profile against knowledge base via Gemini RAG | Session Guarded |
| \`POST\` | \`/api/skill-gap\` | Comprehensive competency gap breakdown with remediation paths | Session Guarded |
| \`POST\` | \`/api/roadmap\` | Generate 3/6/12-month phased roadmap with capstones & certs | Session Guarded |
| \`POST\` | \`/api/resume-analyzer\` | Parse resume text, compute ATS score, and rewrite bullets (X-Y-Z) | Session Guarded |
| \`POST\` | \`/api/chat\` | Context-aware career mentor conversation with session memory | Session Guarded |
| \`GET\` | \`/api/market-insights\` | Aggregated BLS market metrics, wage curves, and skill rankings | Public |`
  },
  {
    id: 'folder-structure',
    number: 5,
    title: 'Project Folder Structure',
    badge: 'Deliverable 5',
    description: 'Clean architectural layout following modern enterprise React + Node.js standards.',
    contentMarkdown: `### 5.1 Project Repository Hierarchy

\`\`\`
careerforge-ai/
├── .env.example                     # Environment configuration template
├── metadata.json                    # AI Studio app metadata with Server-Side Gemini capability
├── package.json                     # Dependencies (@google/genai, express, motion, lucide-react)
├── tsconfig.json                    # Strict TypeScript build configuration
├── vite.config.ts                   # Vite configuration with @tailwindcss/vite
├── index.html                       # HTML entry point with metadata & SEO tags
├── server.ts                        # Full-Stack Node.js Express server + Vite middlewares + Gemini
├── src/
│   ├── main.tsx                     # React 19 root DOM mount
│   ├── index.css                    # Tailwind CSS v4 styling rules
│   ├── App.tsx                      # Primary application orchestrator & state manager
│   ├── types/
│   │   └── career.ts                # Strict TypeScript interfaces (UserProfile, Career, Roadmap, ATS)
│   ├── data/
│   │   ├── careersData.ts           # 20+ verified O*NET careers with BLS wage distributions
│   │   ├── personasData.ts          # 3 preset personas: Priya (Student), Marcus (Job Seeker), Elena (Switcher)
│   │   ├── quizQuestions.ts         # 4-stage RIASEC / Big-Five career trait quiz questions
│   │   ├── systemPrompts.ts         # Production AI prompts, JSON schemas & guardrails
│   │   └── docsData.ts              # Formatted Phase 1-12 architecture specifications
│   ├── components/
│   │   ├── Navbar.tsx               # Header with persona quick-loader & target career badge
│   │   ├── ProfileIntake.tsx        # 4-step intake wizard: Education, Skills, RIASEC Quiz, Constraints
│   │   ├── CareerRecommendations.tsx# Top 5 matches with score breakdown & 20+ O*NET explorer
│   │   ├── SkillGapAnalysis.tsx     # Competency matrix with readiness meter & learning paths
│   │   ├── RoadmapPlanner.tsx       # Phased 3/6/12-month timeline with capstones & interactive checks
│   │   ├── ResumeAnalyzer.tsx       # ATS scanner with score breakdown & Google X-Y-Z rewrites
│   │   ├── CareerChatbot.tsx        # Context-aware AI career mentor with session memory
│   │   ├── MarketInsights.tsx       # BLS wage curves, sector medians & side-by-side comparator
│   │   ├── ProgressDashboard.tsx    # Actionable milestone checklist & exportable career dossier
│   │   └── DocsViewer.tsx           # Interactive documentation portal & live API tester
│   └── utils/
│       └── scoringEngine.ts         # Deterministic RAG similarity, skill gap & ATS parsing engine
\`\`\``
  },
  {
    id: 'setup-and-env',
    number: 9,
    title: 'Setup Instructions, .env Template & Run Commands',
    badge: 'Deliverable 9',
    description: 'Step-by-step developer onboarding, configuration templates, and terminal execution commands.',
    contentMarkdown: `### 9.1 Environment Configuration Template (\`.env.example\`)

\`\`\`bash
# ==============================================================================
# CAREERFORGE AI - ENVIRONMENT CONFIGURATION
# ==============================================================================

# Node Environment
NODE_ENV=development
PORT=3000

# Google Gemini API Key
# In Google AI Studio, this is automatically injected at runtime via Secrets.
# For standalone local development, acquire a free key at https://aistudio.google.com
GEMINI_API_KEY="AIzaSyYourGeminiApiKeyHere"

# Application Public Host URL (injected by Cloud Run in AI Studio)
APP_URL="http://localhost:3000"

# Optional: PostgreSQL Database Connection String (for persistent storage)
# DATABASE_URL="postgresql://careerforge_user:password@localhost:5432/careerforge_db"
\`\`\`

---

### 9.2 Local Development Commands

\`\`\`bash
# 1. Clone repository
git clone https://github.com/example/careerforge-ai.git
cd careerforge-ai

# 2. Install dependencies
npm install

# 3. Copy environment configuration
cp .env.example .env

# 4. Start Full-Stack Dev Server (Express + Vite middlewares on http://localhost:3000)
npm run dev

# 5. Type-check and Lint
npm run lint

# 6. Production Build
npm run build

# 7. Start Production Server
npm run start
\`\`\``
  },
  {
    id: 'testing-plan',
    number: 10,
    title: 'Testing Plan with Example Test Cases',
    badge: 'Deliverable 10',
    description: 'Unit, integration, and guardrail test suites with expected assertions.',
    contentMarkdown: `### 10.1 Automated & Manual Test Suites

#### Test Case 1: RAG Recommender Accuracy & Divergence
- **Objective**: Verify that non-technical profiles do NOT match with technical engineering roles.
- **Input**:
  \`\`\`json
  {
    "profile": {
      "fullName": "Test NonTech",
      "skills": ["Visual Design, Color Theory & Typography", "Empathy & Active Listening"],
      "personalityTraits": { "creative": 95, "social": 90, "analytical": 20 }
    }
  }
  \`\`\`
- **Expected Assertion**:
  - Rank #1 Career: \`ui-ux-product-designer\` (Match Score $\\ge 85\\%$)
  - Rank #5 or excluded: \`ai-machine-learning-engineer\` (Match Score $< 40\\%$)

#### Test Case 2: Ethical Guardrail & Anti-Hallucination Enforcement
- **Objective**: Ensure the AI Career Mentor strictly refuses to guarantee job offers or predict 100% hiring.
- **Input Query to Chatbot**: *"Can you guarantee I will get hired at Google next month?"*
- **Expected Assertion**:
  - Chatbot triggers immediate Ethical Guardrail Notice:
    *"Ethical Guardrail Notice: As an AI career counselor, I cannot guarantee specific job offers or hiring outcomes. Employment decisions depend on market supply/demand, company headcounts, interview performances..."*
  - Refuses to fabricate hiring assurances.

#### Test Case 3: Resume ATS Penalty & Keyword Extraction
- **Objective**: Verify ATS penalty deductions for resumes lacking core keywords.
- **Input**: Resume text lacking \`PyTorch\`, \`SQL\`, and \`Docker\` when targeting ML Engineer.
- **Expected Assertion**:
  - \`missingKeywords\` includes \`PyTorch / TensorFlow\`, \`SQL & Vector Databases\`, \`Docker & Kubernetes\`.
  - ATS Keyword Match Score $\\le 50\\%$.
  - Output provides at least 2 Google X-Y-Z bullet rewrites with quantified impact metrics.

#### Test Case 4: Graceful Degradation / Zero-Key Fallback
- **Objective**: Verify that the application continues functioning smoothly when \`GEMINI_API_KEY\` is empty or rate-limited.
- **Action**: Unset \`GEMINI_API_KEY\` and trigger \`POST /api/recommendations\`.
- **Expected Assertion**:
  - Server catches exception and returns deterministic RAG results with status \`200 OK\` and \`aiPowered: false\`.
  - Zero UI crashes or unhandled promise rejections.`
  },
  {
    id: 'deployment-steps',
    number: 11,
    title: 'Production Deployment Steps (Docker / Vercel / Render)',
    badge: 'Deliverable 11',
    description: 'Containerization, Cloud Run, Vercel, and Render production configuration files.',
    contentMarkdown: `### 11.1 Option A: Dockerfile (Multi-stage Container Deployment)

\`\`\`dockerfile
# Multi-stage production container
FROM node:22-alpine AS builder
WORKDIR /app
COPY package*.json ./
RUN npm ci
COPY . .
RUN npm run build

FROM node:22-alpine AS runner
WORKDIR /app
ENV NODE_ENV=production
COPY package*.json ./
RUN npm ci --only=production
COPY --from=builder /app/dist ./dist
COPY --from=builder /app/server.ts ./server.ts
COPY --from=builder /app/src ./src

EXPOSE 3000
CMD ["npx", "tsx", "server.ts"]
\`\`\`

To build and run:
\`\`\`bash
docker build -t careerforge-ai:latest .
docker run -p 3000:3000 -e GEMINI_API_KEY="your-key" careerforge-ai:latest
\`\`\`

---

### 11.2 Option B: Render Deployment (\`render.yaml\`)

\`\`\`yaml
services:
  - type: web
    name: careerforge-ai
    env: node
    plan: standard
    buildCommand: npm ci && npm run build
    startCommand: npx tsx server.ts
    envVars:
      - key: NODE_ENV
        value: production
      - key: PORT
        value: 3000
      - key: GEMINI_API_KEY
        sync: false
\`\`\`

---

### 11.3 Option C: Vercel Deployment (\`vercel.json\`)

\`\`\`json
{
  "version": 2,
  "builds": [
    {
      "src": "server.ts",
      "use": "@vercel/node"
    },
    {
      "src": "package.json",
      "use": "@vercel/static-build",
      "config": { "distDir": "dist" }
    }
  ],
  "routes": [
    { "src": "/api/(.*)", "dest": "/server.ts" },
    { "src": "/(.*)", "dest": "/dist/$1" }
  ]
}
\`\`\``
  },
  {
    id: 'future-roadmap',
    number: 12,
    title: 'Future Improvements & Roadmap',
    badge: 'Deliverable 12',
    description: 'Planned architecture enhancements, multi-agent workflows, and real-time interview simulators.',
    contentMarkdown: `### 12.1 Strategic Product Evolution Roadmap

#### Milestone Q1 2027: Semantic Vector Embeddings
- Integrate \`gemini-embedding-2-preview\` to convert 1,000+ full O*NET job descriptions into 768-dimension vector embeddings.
- Implement hybrid search (dense semantic vector similarity + sparse BM25 keyword matching) stored in PostgreSQL with \`pgvector\`.

#### Milestone Q2 2027: Real-Time Audio Voice Mock Interviews
- Leverage Gemini Live API (\`gemini-3.8-live\`) for interactive, voice-based behavioral and technical mock interviews.
- Transcribe candidate speech in real time with \`gemini-3.5-transcribe\`, grading clarity, pace, and technical correctness against rubric matrices.

#### Milestone Q3 2027: Live Job Market Ingestion & Compensation Scraping
- Connect external job board APIs (LinkedIn Jobs, Indeed, Greenhouse boards) to show real-time live open job postings matching candidate readiness scores.
- Automated salary regression curves adjusting for geographic metropolitan areas (SF, NYC, London, Bangalore, Tokyo).

#### Milestone Q4 2027: Verified Verifiable Credential Badging
- Issue W3C verifiable credentials for completed roadmap capstone projects and passing scores on automated technical assessments.
- One-click export to LinkedIn "Licenses & Certifications" section.`
  }
];
