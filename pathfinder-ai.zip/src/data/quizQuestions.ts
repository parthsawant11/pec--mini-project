export interface PersonalityQuestion {
  id: string;
  question: string;
  subtitle: string;
  dimension: 'thinking' | 'workstyle' | 'orientation' | 'drive';
  options: {
    id: string;
    label: string;
    description: string;
    traitWeights: {
      analytical?: number;
      creative?: number;
      social?: number;
      leadership?: number;
      structured?: number;
      technical?: number;
    };
  }[];
}

export const CAREER_QUIZ_QUESTIONS: PersonalityQuestion[] = [
  {
    id: 'core_problem_solving',
    question: 'When faced with a complex challenge at work, which activity energizes you most?',
    subtitle: 'This reveals your natural analytical vs creative instinct.',
    dimension: 'thinking',
    options: [
      {
        id: 'opt_algorithms',
        label: 'Dissecting logic, math, or complex algorithms',
        description: 'Writing code, tuning models, or diagnosing deep technical bugs.',
        traitWeights: { analytical: 30, technical: 30, structured: 15 }
      },
      {
        id: 'opt_visual_ux',
        label: 'Designing intuitive visual journeys & interfaces',
        description: 'Prototyping flows, visual storytelling, and user emotion.',
        traitWeights: { creative: 35, social: 15, analytical: 10 }
      },
      {
        id: 'opt_business_strategy',
        label: 'Connecting customer needs with business strategy',
        description: 'Interviewing stakeholders, drafting roadmaps, and prioritizing ROI.',
        traitWeights: { leadership: 30, social: 25, analytical: 15 }
      },
      {
        id: 'opt_systems_resilience',
        label: 'Hardening security, compliance, and infrastructure',
        description: 'Building bulletproof systems that withstand high load and attacks.',
        traitWeights: { structured: 30, technical: 25, analytical: 20 }
      }
    ]
  },
  {
    id: 'daily_work_environment',
    question: 'What type of daily focus block makes time fly for you?',
    subtitle: 'Assessing your optimal workplace focus dynamic.',
    dimension: 'workstyle',
    options: [
      {
        id: 'opt_deep_solo',
        label: 'Deep uninterrupted focus on intricate problems',
        description: 'Headphones on, solving challenging technical puzzles with autonomy.',
        traitWeights: { analytical: 25, technical: 25 }
      },
      {
        id: 'opt_collaborative_squad',
        label: 'Fast-paced whiteboard sessions and cross-functional syncs',
        description: 'Bouncing ideas with product managers, developers, and designers.',
        traitWeights: { social: 30, leadership: 20, creative: 15 }
      },
      {
        id: 'opt_experiments',
        label: 'Iterating on data experiments & hypothesis testing',
        description: 'Analyzing conversion funnels, A/B experiments, or benchmark metrics.',
        traitWeights: { analytical: 30, technical: 20, structured: 15 }
      },
      {
        id: 'opt_mentoring',
        label: 'Coaching team members and clearing organizational blockers',
        description: 'Facilitating retrospectives, negotiating deadlines, and enabling others.',
        traitWeights: { leadership: 35, social: 30 }
      }
    ]
  },
  {
    id: 'decision_making_style',
    question: 'How do you prefer to defend an important proposal?',
    subtitle: 'Defines how you build consensus and ground arguments.',
    dimension: 'orientation',
    options: [
      {
        id: 'opt_hard_data',
        label: 'With rigorous empirical data, charts & confidence intervals',
        description: 'Show me the metrics, statistical regressions, and logged numbers.',
        traitWeights: { analytical: 35, structured: 25 }
      },
      {
        id: 'opt_working_prototype',
        label: 'With a working, interactive proof-of-concept or demo',
        description: 'Code or prototype speaks louder than a hundred slide decks.',
        traitWeights: { technical: 30, creative: 20 }
      },
      {
        id: 'opt_user_empathy',
        label: 'With authentic user stories, pain points & empathy maps',
        description: 'Showing real human quotes, recordings, and emotional friction.',
        traitWeights: { social: 30, creative: 25 }
      },
      {
        id: 'opt_risk_framework',
        label: 'With threat models, worst-case scenarios & risk matrices',
        description: 'Anticipating failure modes before bad things happen.',
        traitWeights: { structured: 35, analytical: 20 }
      }
    ]
  },
  {
    id: 'career_legacy_drive',
    question: 'Looking ahead 5 years, what accomplishment would make you proudest?',
    subtitle: 'Helps align your core motivator with career trajectories.',
    dimension: 'drive',
    options: [
      {
        id: 'opt_pioneering_ai',
        label: 'Having built frontier AI models or world-scale backend infrastructure',
        description: 'Pushing the technological envelope and mastering deep craft.',
        traitWeights: { technical: 35, analytical: 25 }
      },
      {
        id: 'opt_beloved_product',
        label: 'Having shipped a product that millions of people love using daily',
        description: 'Seeing tangible human delight and seamless everyday utility.',
        traitWeights: { creative: 30, social: 25, leadership: 20 }
      },
      {
        id: 'opt_high_earning_autonomy',
        label: 'Achieving top-tier earning power and location independence',
        description: 'Financial freedom, remote work flexibility, and in-demand leverage.',
        traitWeights: { leadership: 25, structured: 20 }
      },
      {
        id: 'opt_critical_defense',
        label: 'Safeguarding critical public infrastructure or healthcare privacy',
        description: 'Protecting society from catastrophic cyber attacks or data misuse.',
        traitWeights: { structured: 30, social: 20, analytical: 20 }
      }
    ]
  }
];
